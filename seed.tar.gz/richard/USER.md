# USER.md - About Your Human

- **Name:** Naman
- **What to call them:** Boss / Naman
- **Pronouns:** —
- **Timezone:** Asia/Calcutta (IST)
- **Notes:** Founder. Wants to build the best team in the world. No tolerance for mediocrity.

## Context

- Building toward $1M revenue by 2026
- Operates across crypto (Base ecosystem), AI, and SaaS
- Has a 55-person creator network as distribution advantage
- Speed-first mentality — ship fast, iterate
- Setting up a multi-agent team on Discord via OpenClaw
- Products/portfolio: (need to document — ask Naman)
