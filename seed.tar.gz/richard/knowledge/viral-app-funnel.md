# Viral App → ClawDeploy Funnel

**Last Updated**: 2026-02-25

## Summary
Strategic conversion funnel where viral apps serve as acquisition channel for ClawDeploy subscriptions. Users who pay for viral apps see "This was built by AI agents in 3 days" pitch, converting at 20-30% to ClawDeploy.

## Status
Designed — Ready to implement with first viral app launch.

## Key Mechanics
- **Placement:** Post-paywall success screen (100% reach of paid users)
- **Hook:** "This app was built by AI agents in 3 days. Deploy the same team for $9/mo."
- **Landing:** clawdeploy.com/built-this (to be built)
- **Conversion Path:** Viral app user → Pays $3-5 → Sees pitch → 15-25% click → 20-30% convert to ClawDeploy

## Funnel Math (Per Viral App Launch)
- 100K social impressions → 5K app visitors → 2K active users
- 60-100 pay for viral app (3-5% conversion)
- 60-100 see ClawDeploy pitch (100% post-paywall)
- 9-25 visit landing page (15-25% CTR)
- **2-7 convert to ClawDeploy subscribers** (20-30%)

## Monthly Projections (4 Apps/Month)
- **Conservative:** 8 new subs/month ($72 MRR)
- **Optimistic:** 28 new subs/month ($252 MRR)
- **Annual Value (Blended):** $1,440-$5,040/month

## Strategic Value
1. **Social Proof Factory:** Each viral app is live demo of ClawDeploy capabilities
2. **Content Engine:** Weekly launch content for Monica's build-in-public narrative
3. **SEO/Brand:** "Built with ClawDeploy" backlinks from viral apps
4. **Credibility:** "We ship 1 app/week" positioning statement
5. **Learning Loop:** Real builds improve ClawDeploy product

## Resource Allocation
- **20% time investment** (automated agents)
- **Low-Medium revenue impact** (10-30 subs/mo)
- **High strategic impact** (proof-of-concept, brand, content)

## Success Metrics
- **Week 1:** ≥50 paid viral app users, ≥10 landing visits, ≥2 conversions
- **Month 1:** ≥8 ClawDeploy subs, ≥$72 MRR, ≥20% landing → signup conversion
- **Month 3:** ≥25 subs (cumulative), ≥$225 MRR, 10-15% of total ClawDeploy growth

## Related
[[ClawDeploy]], [[GlowUp AI]], [[Team]]

## History
### 2026-02-25
- Full funnel designed by Jared
- Conversion mechanics mapped: post-paywall pitch → landing page → signup
- Math validated: 2-7 subs per viral app launch
- Positioned as parallel engine (30% focus) vs primary B2B sales (70% focus)
- Implementation roadmap: Week 1 setup, Week 2-4 launch & iterate, Month 2 optimize
