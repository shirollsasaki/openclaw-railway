# GlowUp AI

**Last Updated**: 2026-02-25

## Summary
Viral web app where users upload selfies, get AI face analysis + glowed-up transformation. Hybrid model: viral acquisition + retention through coaching subscriptions. Launch target: March 7, 2026 (10 days from spec).

## Status
Pre-Build — Spec complete, awaiting boss approval to kick off Phase 1.

## Key Facts
- **Domain:** glowupai.com (to be registered)
- **Tech Stack:** Next.js 14, Vercel, OpenAI GPT-4o Vision, Replicate (SD XL), Lemon Squeezy
- **Revenue Model:** Free analysis + blurred preview → $4.99 unlock → $2.99/mo coaching
- **Build Timeline:** 10 days (5 phases: Foundation → AI Enhancement → Paywall → Polish → Launch)
- **Launch Date:** Friday, March 7, 2026
- **Projected Month 1 (Mid):** 5K visitors, 2K uploads, 400 unlocks ($1,996), 160 subs ($478 MRR)
- **API Costs:** ~$0.04/analysis (GPT-4o Vision $0.01 + Replicate $0.03)
- **Break-even:** 17 paid unlocks to cover API costs

## Strategic Rationale
- **Proves OpenClaw value:** "Built by AI agents in 3 days" is the marketing hook
- **Template for future wrappers:** StyleScore, VoiceGlow, PostureCheck can reuse architecture
- **Dual revenue:** One-time purchases + recurring subscriptions
- **Viral shareability:** Before/after screenshots drive organic growth
- **Web-first:** No app install friction, maximum reach

## Target Metrics
- **Week 1:** 1K visitors, 500 uploads, 75 unlocks ($500 revenue), 20+ social shares
- **Month 1:** 5K visitors, 2K uploads, 400 unlocks ($2.5K revenue), 100+ mentions
- **Kill Criteria (Day 30):** <1K visitors, <10% unlock rate, <$500 revenue, zero viral traction

## Related
[[ClawDeploy]], [[Team]], [[Viral App Funnel]]

## History
### 2026-02-25
- Full project spec created by Richard
- Tech stack finalized: Next.js 14 + Vercel + OpenAI + Replicate + Lemon Squeezy
- 5-phase build plan mapped (10 days total)
- Revenue model: $4.99 unlock + $2.99/mo coaching
- Launch target set: Friday, March 7, 2026
- Awaiting boss approval to start Phase 1 (Gilfoyle build kickoff)
