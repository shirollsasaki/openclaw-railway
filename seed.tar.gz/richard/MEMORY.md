# Memory

## Team
- Boss: Naman (@shirollsasaki) — Discord
- Team: Richard (founder), Jared (CMO), Erlich (BD), Gilfoyle (CTO), Monica (writer), Bighead (data), Dinesh (researcher)

## Products & Portfolio
- **ClawDeploy** (clawdeploy-web.vercel.app) — The product we ARE. Multi-agent AI team deployed to Discord in 60 seconds. 7 agents (Richard/CEO, Jared/CMO, Monica/Writer, Gilfoyle/CTO + more). Pre-wired collaboration. From $9/mo. **This is the thing we're building and selling.** We are the demo. Added 2026-02-19.

## Failed Experiments
- **$CLAWDEPLOY Token** — Launched Feb 23, 2026 on Base via Fluid DEX. Distribution failed (40% allocation not received). Social stopped immediately. **Fully abandoned same day.** Token exists on-chain but project terminated. If asked: "early experiment, moved on." Added 2026-02-23.
## APIs & Keys
- **KooSocial (X/Twitter API):** Host: `api.koosocial.com`, Key: `KOO_API_KEY=ks_4f504de0b636ac8f442c4bc0ab35e6763f72f16a22451abb88bebae4714fc29d`
- API contract mirrors Twitter241 on RapidAPI (search endpoint: `/api/v1/search`)
- Erlich already using it for lead mining; Big Head using it for competitor tracking & creator monitoring

## X/Twitter Posting — @CLIRichard

Richard has an automated X account: **@CLIRichard**

### Posting Workflow (runs after every morning brief)
1. During the morning brief, identify 1-2 signals worth tweeting
2. Send to @monica via sessions_send with this format:
   ```
   @monica — Tweet request for @CLIRichard.
   Signal: [the opportunity/trend]
   Angle: [build-in-public / trend commentary / team status]
   Tone: [CT-native, sharp, founder voice]
   Run the Banger Playbook. Post when ready.
   ```
3. Monica writes the tweet, scores it, then posts via the X API script
4. **NEVER post directly** — always route through Monica for quality

### What @CLIRichard posts:
- Build-in-public updates (what the team is working on)
- Trend commentary (hot takes on crypto, AI, SaaS signals)
- Replies and engagement on relevant conversations

### Posting script
Monica calls:
```
bash -c 'export $(grep -v "^#" /data/.openclaw/.env | grep -v "^$" | xargs) && node /data/.openclaw/scripts/x-post.mjs "tweet text"'
```

## Key Competitor: @laukiantonson
AI agent persona running DeFi ops. "Headcount zero" thesis. 5 clients @ $500/mo = $2.5K MRR. Runs on OpenClaw. Closest public comp to @CLIRichard. On x-research watchlist.

## Inspiration Sources
PH, YC Demo Days, Indie Hackers, Crunchbase, a16z, Mobbin, SaaSFrame. Full list: `knowledge/startup-inspiration-sources.md`

## Boss Preferences
- **Just execute — don't ask for approval on routine actions.** When a clear next step exists (route to Monica, ping an agent, post a tweet), do it. Only ask when it's genuinely ambiguous or high-stakes.
- **No product links/URLs in @CLIRichard tweets.** Build-in-public narrative only. No clawdeploy-web.vercel.app, no external URLs unless Naman explicitly says to include one.

## Key Decisions
- 2025-06-17: Naman asked Richard to set up org structure and workflows before team comes online
- 2026-02-18: @CLIRichard X account created. Richard→Monica→auto-post pipeline established.
- 2026-02-19: @laukiantonson identified as direct comp. Added to x-research watchlist. 5 clients @ $500/mo = $2.5K MRR from AI agent ops.

## Knowledge System
Read `knowledge/my-focus.md` before major tasks. After work, append findings with timestamp. Keep files under 2000 chars. Only write to YOUR knowledge/ directory. During EOD: extract significant entities (people with deals, tracked products, key competitors) — quality over quantity.
