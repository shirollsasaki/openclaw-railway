# ClawDeploy — Full Platform Build

## TL;DR

> **Quick Summary**: Build a managed hosting SaaS where anyone deploys pre-configured OpenClaw AI agent teams in minutes. Monorepo with Next.js frontend + Hono API backend + Docker runtime image. Railway for provisioning, Clerk for auth, Stripe for billing. Two templates at launch: Solo Assistant (1 agent, Telegram) and Marketing Team (7 agents, Discord).
> 
> **Deliverables**:
> - Marketing landing page with template showcase + pricing
> - Auth flow (Clerk — Google + GitHub)
> - Deploy flow (pick template → enter keys → one-click deploy)
> - User dashboard (instances, status, restart, delete)
> - Backend API (provisioning, instances, templates, billing)
> - Railway provisioning engine (programmatic Docker service creation)
> - Docker runtime image (OpenClaw + templates + skills + config injection)
> - Stripe billing (Solo $9/mo, Pro $99/mo — subscriptions, webhooks, plan enforcement)
> - Discord channel auto-creation during Marketing Team deploys
> - Health monitoring (periodic health checks on user instances)
> - Full TDD with vitest
> 
> **Estimated Effort**: Large (1-2 weeks, aggressive)
> **Parallel Execution**: YES — 5 waves
> **Critical Path**: Monorepo Setup → Docker Validation → DB + Auth → Provisioning Engine → Deploy UI → Integration Tests

---

## Context

### Original Request
Build ClawDeploy end-to-end — the platform, the website, everything. A managed hosting platform where anyone deploys a fully-configured OpenClaw AI agent team in clicks.

### Interview Summary
**Key Discussions**:
- Monorepo: `/apps/web` (Next.js 14) + `/apps/api` (Hono) + `/packages/shared`
- Design: Clean, friendly, Linear-style (light/dark toggle, purple/blue palette)
- Timeline: ASAP 1-2 weeks — market window is closing
- Template source: Use `shirollsasaki/openclaw-team` repo as-is for Marketing Team
- Testing: Full TDD with vitest
- Team tier ($49): CUT for V1 — launch with Solo ($9) + Pro ($99) only
- Discord channels: Auto-create 6 HQ channels via Discord API at deploy time

**Research Findings**:
- Railway API: GraphQL-only, Pro plan handles 100 projects × 100 services. ~$5/container/month. Use `graphql-request`. Private registry creds are UI-only — use public GHCR.
- OpenClaw: Single Node.js process, gateway on port 18789, ~150MB base + ~50MB/agent. Supports `${ENV_VAR}` substitution in config. Official Docker image exists.
- Competitors: 15+ competitors sell single-agent hosting. Nobody does multi-agent teams. SimpleClaw at $5-34/mo, OpenClaw Cloud at $9-79/mo.

### Metis Review
**Identified Gaps (addressed)**:
- Config syntax mismatch: Planning docs use `{{PLACEHOLDER}}` but actual openclaw.json uses `${ENV_VAR}`. Decision: Use `${ENV_VAR}` — OpenClaw resolves natively. Need to validate in Task 3.
- Team plan product gap: No 3-agent template for $49 tier. Decision: Cut Team tier for V1.
- Discord channel IDs: 14-15 form fields would kill UX. Decision: Auto-create channels via Discord API.
- Skill installation: External skills (x-research, x-writing-system, marketingskills) must be pre-installed in Docker image at build time, not runtime.
- Provisioning failure recovery: Must implement as state machine with compensating transactions.
- Secrets management: AES-256-GCM encryption, key stored as env var on Hono server, NOT in DB.
- Railway cost control: Hard spending limit kills all tenants. Build our own per-project metering.
- Double-click deploy: Idempotency keys on deploy/delete endpoints.

---

## Work Objectives

### Core Objective
Build and launch a managed hosting platform that lets users deploy pre-configured OpenClaw AI agent teams (1 or 7 agents) through a web UI with Stripe billing, in under 2 weeks.

### Concrete Deliverables
- `clawdeploy` monorepo on GitHub with `/apps/web`, `/apps/api`, `/packages/shared`
- Docker image `ghcr.io/shirollsasaki/openclaw-runtime:latest` published to GHCR
- Landing page deployed to Vercel
- Backend API deployed to Railway
- PostgreSQL database on Railway with users, instances, user_keys tables
- 2 functional templates: Solo Assistant + Marketing Team
- Stripe products + prices configured (Solo $9/mo, Pro $99/mo)
- Working end-to-end flow: signup → subscribe → deploy → agents come online

### Definition of Done
- [ ] User can sign up via Clerk (Google/GitHub)
- [ ] User can subscribe to Solo ($9) or Pro ($99) via Stripe
- [ ] User can deploy Solo Assistant template → agent responds on Telegram
- [ ] User can deploy Marketing Team template → 7 agents come online in Discord with 6 auto-created channels
- [ ] User can view instance status on dashboard
- [ ] User can restart and delete instances
- [ ] Plan enforcement works (Solo blocked from Marketing Team, instance limits enforced)
- [ ] All vitest tests pass
- [ ] Health monitoring shows up/down status

### Must Have
- Auth (Clerk) with Google + GitHub social login
- Stripe billing with hosted checkout + customer portal
- Railway provisioning with state machine + rollback on failure
- Docker image with OpenClaw + both templates + all skills pre-installed
- Config injection via `${ENV_VAR}` substitution (validate OpenClaw native support first)
- Discord channel auto-creation for Marketing Team deploys
- Deploy form with dynamic fields based on template manifest
- Dashboard with instance list, status badges, restart, delete
- Idempotency keys on deploy and delete endpoints
- User API key encryption (AES-256-GCM)
- Health check endpoint polling (60s interval)

### Must NOT Have (Guardrails)
- Custom template builder or editor
- Template marketplace
- Agent config editing or SOUL.md editing
- Custom domains per instance
- Log streaming or metrics dashboard
- Admin panel
- Email notifications
- Auto-restart failed instances (show status badge only)
- Interactive landing page configurator (static hero only)
- Custom payment UI (Stripe Checkout + Portal only)
- Team collaboration or RBAC
- Migration/export tools
- Backup/restore
- White-label/reseller features
- Playwright/E2E tests (unit + integration only via vitest)
- Documentation site (inline tooltips in deploy form only)

---

## Verification Strategy (MANDATORY)

> **ZERO HUMAN INTERVENTION** — ALL verification is agent-executed. No exceptions.

### Test Decision
- **Infrastructure exists**: NO (greenfield)
- **Automated tests**: TDD (RED → GREEN → REFACTOR)
- **Framework**: vitest
- **If TDD**: Each task follows RED (failing test) → GREEN (minimal impl) → REFACTOR

### QA Policy
Every task MUST include agent-executed QA scenarios.
Evidence saved to `.sisyphus/evidence/task-{N}-{scenario-slug}.{ext}`.

| Deliverable Type | Verification Tool | Method |
|------------------|-------------------|--------|
| Frontend/UI | Playwright (playwright skill) | Navigate, interact, assert DOM, screenshot |
| API/Backend | Bash (curl) | Send requests, assert status + response fields |
| Docker Image | Bash (docker) | Build, run, health check, measure startup |
| Library/Module | Bash (vitest) | Run test suite, assert all pass |

---

## Execution Strategy

### Parallel Execution Waves

```
Wave 1 (Start Immediately — foundation + scaffolding):
├── Task 1: Monorepo scaffolding + tooling [quick]
├── Task 2: Shared types + DB schema + migrations [quick]
├── Task 3: Docker image build + OpenClaw validation [deep]
├── Task 4: Solo Assistant template packaging [quick]
├── Task 5: Marketing Team template packaging [quick]
├── Task 6: Landing page (static, Linear-style) [visual-engineering]
└── Task 7: Stripe products + prices setup (test mode) [quick]

Wave 2 (After Wave 1 — core services, MAX PARALLEL):
├── Task 8: Clerk auth integration (frontend + backend) [unspecified-high]
├── Task 9: Railway API client + provisioning state machine [deep]
├── Task 10: Stripe billing service (checkout, webhooks, enforcement) [deep]
├── Task 11: Discord channel auto-creation service [unspecified-high]
├── Task 12: Template service (manifest loading, config generation) [unspecified-high]
├── Task 13: Health monitoring service [quick]
└── Task 14: User keys encryption service [quick]

Wave 3 (After Wave 2 — API routes + frontend pages):
├── Task 15: API routes — deploy + instances CRUD [deep]
├── Task 16: API routes — templates + billing [unspecified-high]
├── Task 17: Deploy flow UI (template picker → key input → deploy) [visual-engineering]
├── Task 18: Dashboard UI (instance list, status, actions) [visual-engineering]
├── Task 19: Instance detail page + billing page [visual-engineering]
└── Task 20: Setup guide content (inline tooltips + help modals) [quick]

Wave 4 (After Wave 3 — integration + polish):
├── Task 21: End-to-end integration tests [deep]
├── Task 22: Provisioning failure + rollback tests [deep]
├── Task 23: Error handling, loading states, edge cases [unspecified-high]
└── Task 24: Mobile responsive polish [visual-engineering]

Wave 5 (After Wave 4 — deploy + verify):
├── Task 25: Production deployment (Vercel + Railway) [unspecified-high]
├── Task 26: Docker image publish to GHCR [quick]
└── Task 27: Smoke test on production [deep]

Wave FINAL (After ALL tasks — independent review, 4 parallel):
├── Task F1: Plan compliance audit (oracle)
├── Task F2: Code quality review (unspecified-high)
├── Task F3: Real manual QA (unspecified-high)
└── Task F4: Scope fidelity check (deep)

Critical Path: Task 1 → Task 2 → Task 9 → Task 15 → Task 21 → Task 25 → F1-F4
Parallel Speedup: ~65% faster than sequential
Max Concurrent: 7 (Waves 1 & 2)
```

### Dependency Matrix

| Task | Depends On | Blocks | Wave |
|------|------------|--------|------|
| 1 | — | 2-7, 8-14 | 1 |
| 2 | 1 | 8, 9, 10, 12, 14, 15, 16 | 1 |
| 3 | 1 | 9, 25, 26 | 1 |
| 4 | 1 | 3, 12 | 1 |
| 5 | 1 | 3, 11, 12 | 1 |
| 6 | 1 | 24 | 1 |
| 7 | — | 10, 16 | 1 |
| 8 | 1, 2 | 15, 16, 17, 18, 19 | 2 |
| 9 | 2, 3 | 15, 21, 22 | 2 |
| 10 | 2, 7 | 16, 21 | 2 |
| 11 | 5 | 15 | 2 |
| 12 | 2, 4, 5 | 15, 16, 17 | 2 |
| 13 | 2 | 15, 21 | 2 |
| 14 | 2 | 15 | 2 |
| 15 | 8, 9, 11, 12, 13, 14 | 17, 21, 22 | 3 |
| 16 | 8, 10, 12 | 17, 19, 21 | 3 |
| 17 | 15, 16 | 21 | 3 |
| 18 | 8, 15 | 21 | 3 |
| 19 | 8, 16 | 21 | 3 |
| 20 | — | 17 | 3 |
| 21 | 15, 16, 17, 18, 19 | 25 | 4 |
| 22 | 9, 15 | 25 | 4 |
| 23 | 15, 16, 17, 18 | 25 | 4 |
| 24 | 6, 17, 18, 19 | 25 | 4 |
| 25 | 21, 22, 23, 24 | 27 | 5 |
| 26 | 3 | 25 | 5 |
| 27 | 25, 26 | F1-F4 | 5 |

### Agent Dispatch Summary

| Wave | # Parallel | Tasks → Agent Category |
|------|------------|----------------------|
| 1 | **7** | T1 → `quick`, T2 → `quick`, T3 → `deep`, T4 → `quick`, T5 → `quick`, T6 → `visual-engineering`, T7 → `quick` |
| 2 | **7** | T8 → `unspecified-high`, T9 → `deep`, T10 → `deep`, T11 → `unspecified-high`, T12 → `unspecified-high`, T13 → `quick`, T14 → `quick` |
| 3 | **6** | T15 → `deep`, T16 → `unspecified-high`, T17 → `visual-engineering`, T18 → `visual-engineering`, T19 → `visual-engineering`, T20 → `quick` |
| 4 | **4** | T21 → `deep`, T22 → `deep`, T23 → `unspecified-high`, T24 → `visual-engineering` |
| 5 | **3** | T25 → `unspecified-high`, T26 → `quick`, T27 → `deep` |
| FINAL | **4** | F1 → `oracle`, F2 → `unspecified-high`, F3 → `unspecified-high`, F4 → `deep` |

---

## TODOs

- [x] 1. Monorepo Scaffolding + Tooling

  **What to do**:
  - TDD: Write tests first for shared package exports, turbo config validation
  - Initialize monorepo with Turborepo: `apps/web` (Next.js 14, App Router, Tailwind, shadcn/ui), `apps/api` (Hono on Node.js), `packages/shared` (types, utils, constants)
  - Configure: TypeScript (strict), ESLint, Prettier, vitest (workspace config)
  - Set up `turbo.json` with build/test/lint pipelines
  - `packages/shared` exports: types, constants (plan tiers, template IDs), validation schemas (zod)
  - Add `.env.example` files for both apps
  - Ensure `turbo build` and `turbo test` both pass with placeholder tests
  - Init git repo, `.gitignore`, initial commit

  **Must NOT do**:
  - Install app-specific dependencies (Clerk, Stripe, etc.) — those go in their respective tasks
  - Write any business logic
  - Create deployment configs

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Standard scaffolding with well-known tooling, no complex logic
  - **Skills**: []
  - **Skills Evaluated but Omitted**:
    - `frontend-ui-ux`: Not needed for scaffolding

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 2-7)
  - **Blocks**: Tasks 2, 3, 4, 5, 6, 8-14
  - **Blocked By**: None (can start immediately)

  **References**:

  **Pattern References**:
  - Turborepo official starter: `npx create-turbo@latest` — use as baseline structure
  - `packages/shared/src/index.ts` — barrel export pattern for shared types

  **API/Type References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:51-64` — Tech stack table (Next.js 14, Hono, PostgreSQL, etc.)
  - `/data/.openclaw/richard/projects/clawdeploy/PROJECT.md:26-31` — Pricing tiers (Solo $9, Pro $99 — no Team tier in V1)

  **External References**:
  - Turborepo docs: https://turbo.build/repo/docs — workspace config, pipeline setup
  - Vitest workspace: https://vitest.dev/guide/workspace — monorepo test config

  **WHY Each Reference Matters**:
  - TECHNICAL_SCOPE.md tech stack ensures correct framework versions are installed
  - PROJECT.md pricing tiers → defines plan constants in shared package (solo/pro only, Team cut)

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test file: `packages/shared/src/__tests__/constants.test.ts` — validates plan tiers, template IDs exist
  - [ ] `turbo test` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Monorepo builds successfully
    Tool: Bash
    Preconditions: Fresh clone of repo
    Steps:
      1. Run `npm install` (or `pnpm install`) at repo root
      2. Run `turbo build`
      3. Check exit code
    Expected Result: Exit code 0, both apps/web and apps/api build outputs exist
    Failure Indicators: Non-zero exit code, missing build artifacts
    Evidence: .sisyphus/evidence/task-1-monorepo-build.txt

  Scenario: Test suite runs with vitest
    Tool: Bash
    Preconditions: Dependencies installed
    Steps:
      1. Run `turbo test`
      2. Check output for test count
    Expected Result: At least 1 test passes, exit code 0
    Failure Indicators: "no tests found" or non-zero exit
    Evidence: .sisyphus/evidence/task-1-test-suite.txt
  ```

  **Commit**: YES
  - Message: `chore: scaffold clawdeploy monorepo`
  - Files: entire repo structure
  - Pre-commit: `turbo build && turbo test`

- [ ] 2. Shared Types + DB Schema + Migrations

  **What to do**:
  - TDD: Write tests for type exports, schema validation, migration file existence
  - Define all shared TypeScript types in `packages/shared/src/types/`:
    - `User` (id, clerkId, email, stripeCustomerId, plan: 'free'|'solo'|'pro', createdAt, updatedAt)
    - `Instance` (id, userId, templateId, railwayProjectId, railwayServiceId, railwayEnvironmentId, status: 'pending'|'creating_project'|'creating_service'|'deploying'|'configuring'|'active'|'failed'|'deleting'|'deleted', region, plan, isHealthy, lastHealthCheck, createdAt, updatedAt)
    - `UserKey` (id, userId, instanceId, keyType, encryptedValue, createdAt)
    - `Template`, `TemplateManifest` types matching manifest.json structure
    - `ProvisioningState` enum for state machine
  - Define Zod validation schemas for API inputs (deploy request, key input)
  - Set up Drizzle ORM in `apps/api`:
    - Schema definitions matching types above
    - PostgreSQL connection config (env-based)
    - Migration files for users, instances, user_keys tables
  - Add `drizzle-kit` for migration generation
  - Write migration SQL matching TECHNICAL_SCOPE.md schema (with modifications: no 'team' plan, add provisioning state fields)

  **Must NOT do**:
  - Connect to a real database (use mocks in tests)
  - Implement any API routes
  - Add fields not in the schema above

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Type definitions and schema are well-specified in planning docs
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (after Task 1)
  - **Parallel Group**: Wave 1 (with Tasks 3-7)
  - **Blocks**: Tasks 8, 9, 10, 12, 14, 15, 16
  - **Blocked By**: Task 1

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:68-103` — Full DB schema SQL (users, instances, user_keys tables)

  **API/Type References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:86-92` — Instance status enum and fields
  - `/data/.openclaw/richard/projects/clawdeploy/TEMPLATES.md:159-191` — manifest.json structure (requiredKeys, requiredInputs, features)

  **External References**:
  - Drizzle ORM PostgreSQL: https://orm.drizzle.team/docs/get-started-postgresql
  - Zod: https://zod.dev — validation schemas

  **WHY Each Reference Matters**:
  - TECHNICAL_SCOPE.md schema is the source of truth BUT must be modified: remove 'team' from plan enum, add provisioning state fields (creating_project, creating_service, deploying, configuring) to instance status
  - TEMPLATES.md manifest structure defines the TypeScript types for template metadata

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test file: `packages/shared/src/__tests__/types.test.ts` — type imports resolve
  - [ ] Test file: `packages/shared/src/__tests__/schemas.test.ts` — Zod schemas validate good input, reject bad
  - [ ] Test file: `apps/api/src/__tests__/db/schema.test.ts` — Drizzle schema compiles
  - [ ] `turbo test` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Zod deploy request validation rejects invalid input
    Tool: Bash (vitest)
    Preconditions: Shared package built
    Steps:
      1. Run `vitest run packages/shared/src/__tests__/schemas.test.ts`
      2. Verify test cases: missing templateId rejected, invalid plan rejected, valid input accepted
    Expected Result: All validation tests pass
    Failure Indicators: Zod allows invalid input through
    Evidence: .sisyphus/evidence/task-2-schema-validation.txt

  Scenario: Migration SQL is syntactically valid
    Tool: Bash
    Preconditions: Drizzle schema defined
    Steps:
      1. Run `drizzle-kit generate` in apps/api
      2. Inspect generated SQL file exists and contains CREATE TABLE statements
    Expected Result: SQL file generated with users, instances, user_keys tables
    Failure Indicators: drizzle-kit errors, missing tables
    Evidence: .sisyphus/evidence/task-2-migration-gen.txt
  ```

  **Commit**: YES
  - Message: `feat(shared): add DB schema, types, and migrations`
  - Files: `packages/shared/src/types/`, `packages/shared/src/schemas/`, `apps/api/src/db/`
  - Pre-commit: `turbo test`

- [ ] 3. Docker Image Build + OpenClaw Validation

  **What to do**:
  - TDD: Write tests for entrypoint logic (template copy, env resolution, gateway start command)
  - **CRITICAL VALIDATION FIRST**: Before building anything, validate these assumptions:
    1. Does OpenClaw resolve `${ENV_VAR}` in openclaw.json natively? Test with a simple config + env var.
    2. Does OpenClaw expose a health endpoint on port 18789? Test with `curl localhost:18789/health` or `curl localhost:18789/openclaw`.
    3. Measure cold start time for 1-agent vs 7-agent configs.
  - Build `Dockerfile` for `openclaw-runtime`:
    - Base: `node:22-slim`
    - Install OpenClaw globally: `npm install -g openclaw@latest`
    - Pre-install ALL external skills at build time:
      - `x-research` (git clone from GitHub)
      - `x-writing-system` (git clone + `bun install` for dependencies)
      - `marketingskills` pack (25 skills)
      - Install `bun` in image for skill dependencies
    - Copy `templates/` directory (solo-assistant + marketing-team)
    - Copy `entrypoint.sh`
    - WORKDIR `/openclaw/workspace`, EXPOSE 18789
  - Write `entrypoint.sh`:
    - If OpenClaw resolves `${ENV_VAR}` natively: just copy template + `exec openclaw gateway --port 18789 --allow-unconfigured`
    - If NOT: write `inject-config.js` to replace `${VAR}` placeholders with env var values, then start gateway
    - Generate `OPENCLAW_GATEWAY_TOKEN` at startup if not provided
  - Write `inject-config.js` (fallback if native env resolution doesn't work):
    - Read openclaw.json, replace all `${...}` with process.env values, write back
  - Target: image size < 1GB, cold start < 90 seconds
  - Test locally: `docker build && docker run` with test env vars

  **Must NOT do**:
  - Push to GHCR yet (Task 26)
  - Configure Railway deployment
  - Use `{{PLACEHOLDER}}` syntax — use `${ENV_VAR}` matching actual openclaw.json

  **Recommended Agent Profile**:
  - **Category**: `deep`
    - Reason: Critical validation of platform assumptions + Docker multi-stage build + skill installation complexity
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (after Task 1, alongside Tasks 2, 4-7)
  - **Parallel Group**: Wave 1
  - **Blocks**: Tasks 9, 25, 26
  - **Blocked By**: Task 1 (needs monorepo structure), Tasks 4 & 5 (needs template dirs — but can start Docker work while templates are being packaged)

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:286-329` — Full Dockerfile + entrypoint.sh + inject-config.js pseudocode
  - `https://github.com/shirollsasaki/openclaw-team` → `setup.sh` — shows how skills are cloned and installed (git clone + bun install)
  - `https://github.com/shirollsasaki/openclaw-team` → `openclaw.json` — actual config with `${ENV_VAR}` syntax

  **External References**:
  - OpenClaw Docker docs: Check `openclaw/openclaw` repo README for Docker section
  - OpenClaw CLI: `openclaw gateway --help` for flags (--port, --allow-unconfigured, --daemon)

  **WHY Each Reference Matters**:
  - TECHNICAL_SCOPE.md Dockerfile is the blueprint but must be extended with skill installation
  - setup.sh from openclaw-team shows exact git clone URLs and install commands for each skill
  - The actual openclaw.json uses `${ENV_VAR}` syntax — this MUST be validated as working in Docker

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test file: `apps/api/src/__tests__/docker/entrypoint.test.ts` — validates template copy logic, env resolution
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Docker image builds successfully under 1GB
    Tool: Bash (docker)
    Preconditions: Dockerfile written, templates directory populated
    Steps:
      1. Run `docker build -t openclaw-runtime:test .`
      2. Run `docker images openclaw-runtime:test --format "{{.Size}}"`
    Expected Result: Build succeeds, image size < 1GB
    Failure Indicators: Build fails, image > 1GB
    Evidence: .sisyphus/evidence/task-3-docker-build.txt

  Scenario: OpenClaw gateway starts and health check responds
    Tool: Bash (docker)
    Preconditions: Image built
    Steps:
      1. Run `docker run -d --name health-test -p 18789:18789 -e TEMPLATE_ID=solo-assistant -e ANTHROPIC_API_KEY=sk-test openclaw-runtime:test`
      2. Wait 90 seconds
      3. Run `curl -f http://localhost:18789/health` OR `curl -f http://localhost:18789/openclaw`
      4. Check response
    Expected Result: HTTP 200 response from health endpoint
    Failure Indicators: Connection refused, 404, timeout after 90s
    Evidence: .sisyphus/evidence/task-3-health-check.txt

  Scenario: Environment variable substitution works in config
    Tool: Bash (docker)
    Preconditions: Image built
    Steps:
      1. Run container with `-e ANTHROPIC_API_KEY=test-key-123`
      2. Exec into container: `docker exec health-test cat /openclaw/workspace/openclaw.json`
      3. Verify `test-key-123` appears (not `${ANTHROPIC_API_KEY}`)
    Expected Result: Env var resolved in config file
    Failure Indicators: `${ANTHROPIC_API_KEY}` still present as literal string
    Evidence: .sisyphus/evidence/task-3-env-resolution.txt
  ```

  **Commit**: YES
  - Message: `feat(docker): openclaw-runtime image with validation`
  - Files: `Dockerfile`, `entrypoint.sh`, `inject-config.js`, validation test results
  - Pre-commit: `docker build -t openclaw-runtime:test .`

- [ ] 4. Solo Assistant Template Packaging

  **What to do**:
  - TDD: Write test validating manifest.json schema, required keys, template structure
  - Create `templates/solo-assistant/` directory:
    - `manifest.json`: id, name, description, version, tier ("solo"), agents count (1), channels (["telegram"]), requiredKeys ([anthropic, telegram_bot_token]), requiredInputs ([]), features list
    - `openclaw.json`: Single agent config with Telegram channel binding. Use `${ANTHROPIC_API_KEY}` and `${TELEGRAM_BOT_TOKEN}` for env substitution.
    - `agents/assistant/SOUL.md`: General purpose assistant persona (from TEMPLATES.md spec)
    - `agents/assistant/AGENTS.md`: Single agent, no collaboration needed
    - `agents/assistant/USER.md`: Generic user context placeholder
  - Validate manifest matches shared Zod schema from Task 2

  **Must NOT do**:
  - Add skills to Solo Assistant (keep it simple)
  - Add more than 1 agent
  - Add Discord support (Telegram only for Solo)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Straightforward template creation from existing spec
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 1-3, 5-7)
  - **Blocks**: Tasks 3, 12
  - **Blocked By**: Task 1

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TEMPLATES.md:1-46` — Full Solo Assistant spec (persona, SOUL.md content, required keys)
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:108-157` — Template directory structure

  **API/Type References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:160-191` — manifest.json schema example

  **WHY Each Reference Matters**:
  - TEMPLATES.md has the exact SOUL.md content to use
  - TECHNICAL_SCOPE.md manifest.json shows required structure that the deploy form will parse

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: manifest.json validates against TemplateManifest Zod schema
  - [ ] Test: openclaw.json contains `${ANTHROPIC_API_KEY}` and `${TELEGRAM_BOT_TOKEN}` placeholders
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Solo template manifest is valid
    Tool: Bash (vitest)
    Preconditions: Template files created, Zod schema from Task 2 available
    Steps:
      1. Run test that imports manifest.json and validates against TemplateManifest schema
      2. Assert tier is "solo", agents is 1, channels is ["telegram"]
      3. Assert requiredKeys has exactly 2 entries: anthropic + telegram_bot_token
    Expected Result: All assertions pass
    Failure Indicators: Schema validation error, wrong field values
    Evidence: .sisyphus/evidence/task-4-manifest-validation.txt

  Scenario: Template file structure is complete
    Tool: Bash
    Preconditions: Template directory created
    Steps:
      1. Check file exists: `templates/solo-assistant/manifest.json`
      2. Check file exists: `templates/solo-assistant/openclaw.json`
      3. Check file exists: `templates/solo-assistant/agents/assistant/SOUL.md`
    Expected Result: All 3 files exist and are non-empty
    Failure Indicators: Missing files
    Evidence: .sisyphus/evidence/task-4-structure-check.txt
  ```

  **Commit**: YES (groups with Task 5)
  - Message: `feat(templates): package solo-assistant and marketing-team`
  - Files: `templates/solo-assistant/`
  - Pre-commit: `vitest run`

- [ ] 5. Marketing Team Template Packaging

  **What to do**:
  - TDD: Write test validating manifest.json, all 7 agent configs exist, openclaw.json structure
  - Create `templates/marketing-team/` by copying configs from `shirollsasaki/openclaw-team` repo:
    - Copy all 7 agent directories (richard, jared, erlich, gilfoyle, monica, bighead, dinesh) with their SOUL.md, AGENTS.md, COLLABORATION_RULES.md, TASKS.md, TOOLS.md, HEARTBEAT.md, IDENTITY.md, USER.md, MEMORY.md
    - Copy `openclaw.json` with all agent bindings and Discord channel configs
    - Ensure all `${ENV_VAR}` placeholders use consistent naming: `${ANTHROPIC_API_KEY}`, `${DISCORD_RICHARD_TOKEN}`, `${DISCORD_JARED_TOKEN}`, ..., `${DISCORD_GUILD_ID}`
    - Channel IDs should use placeholders that will be replaced by auto-created channel IDs at deploy time
  - Create `manifest.json`:
    - tier: "pro", agents: 7, channels: ["discord"]
    - requiredKeys: 1 Anthropic key + 7 Discord bot tokens (8 total)
    - requiredInputs: 1 Discord Guild ID
    - features: list from TEMPLATES.md spec
  - Do NOT copy skills into template dir (skills are pre-installed in Docker image globally)

  **Must NOT do**:
  - Modify agent personas or SOUL.md content (use as-is)
  - Include skill source code in template (Docker image handles this)
  - Hardcode any channel IDs (use placeholders)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Mostly file copying and packaging from existing repo
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1
  - **Blocks**: Tasks 3, 11, 12
  - **Blocked By**: Task 1

  **References**:

  **Pattern References**:
  - `https://github.com/shirollsasaki/openclaw-team` — ENTIRE repo is the source. Clone and copy agent configs.
  - `/data/.openclaw/richard/projects/clawdeploy/TEMPLATES.md:49-114` — Marketing Team spec (agent roster, channels, collaboration rules, required keys)

  **API/Type References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:122-157` — marketing-team directory structure
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:160-191` — manifest.json with 8 requiredKeys

  **WHY Each Reference Matters**:
  - The openclaw-team repo IS the template — it contains battle-tested configs that run in production
  - TECHNICAL_SCOPE.md manifest shows the exact requiredKeys structure the deploy form will consume

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: manifest.json validates, tier is "pro", agents is 7
  - [ ] Test: All 7 agent directories exist with SOUL.md
  - [ ] Test: openclaw.json contains all 7 agent bindings
  - [ ] Test: requiredKeys has 8 entries (1 anthropic + 7 discord)
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: All 7 agents have required config files
    Tool: Bash
    Preconditions: Template packaged from openclaw-team repo
    Steps:
      1. For each agent in [richard, jared, erlich, gilfoyle, monica, bighead, dinesh]:
         Check exists: `templates/marketing-team/agents/{agent}/SOUL.md`
      2. Count total agent directories
    Expected Result: 7 agent directories, each with SOUL.md
    Failure Indicators: Missing agent directory or SOUL.md
    Evidence: .sisyphus/evidence/task-5-agent-check.txt

  Scenario: No hardcoded channel IDs in config
    Tool: Bash (grep)
    Preconditions: openclaw.json created
    Steps:
      1. Search `templates/marketing-team/openclaw.json` for any 18-digit numeric strings (Discord IDs)
      2. Verify only `${...}` placeholders exist for channel/guild references
    Expected Result: Zero hardcoded Discord IDs found
    Failure Indicators: Numeric Discord IDs in config
    Evidence: .sisyphus/evidence/task-5-no-hardcoded-ids.txt
  ```

  **Commit**: YES (groups with Task 4)
  - Message: `feat(templates): package solo-assistant and marketing-team`
  - Files: `templates/marketing-team/`
  - Pre-commit: `vitest run`

- [ ] 6. Landing Page (Static, Linear-Style)

  **What to do**:
  - TDD: Write component tests for key sections (hero renders, pricing table renders correct tiers)
  - Build landing page at `apps/web/app/page.tsx` with these sections:
    1. **Nav**: Logo + "Pricing" + "Docs" + [Sign In] CTA
    2. **Hero**: "Deploy your AI team in 60 seconds" + subheadline about pre-configured agent teams + [Get Started] CTA + trust signals ("No credit card for trial • Cancel anytime")
    3. **"Traditional vs ClawDeploy" comparison**: Side-by-side time breakdown (60 min manual vs <1 min). Reference SimpleClaw's proven pattern.
    4. **Template showcase**: 2 cards — Solo Assistant + Marketing Team. Each shows: agent count, channels, features list, price, [Deploy] CTA
    5. **How It Works**: 3-step flow (Choose template → Enter API keys → Deploy)
    6. **Pricing table**: 2 tiers only — Solo ($9/mo) + Pro ($99/mo). "Most Popular" badge on Pro. Feature comparison rows.
    7. **FAQ**: 5-6 collapsible questions (What is OpenClaw? What's BYOK? How do I get Discord bot tokens? Can I cancel? What channels are supported? Is my data secure?)
    8. **Footer CTA**: "Deploy your first AI team" + [Get Started]
  - Design system: Linear-style — clean, purple/blue accent, light background with dark mode toggle, Inter or similar font, rounded cards, subtle shadows
  - Use shadcn/ui components: Button, Card, Accordion (FAQ), Badge
  - Mobile responsive from the start
  - Static page — no API calls, no auth check

  **Must NOT do**:
  - Interactive deploy configurator in hero (too much scope)
  - Animated deploy demo
  - Blog or docs pages
  - Any backend integration
  - Team tier ($49) in pricing

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
    - Reason: Frontend page design requiring visual polish and responsive layout
  - **Skills**: [`frontend-ui-ux`]
    - `frontend-ui-ux`: Landing page needs strong visual design even without mockups

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1
  - **Blocks**: Task 24
  - **Blocked By**: Task 1

  **References**:

  **Pattern References**:
  - SimpleClaw landing page structure (from competitive research): hero with time comparison, 3-step deploy flow, pricing table
  - Vercel/Railway/Linear landing pages: clean, minimal, developer-focused aesthetic

  **API/Type References**:
  - `/data/.openclaw/richard/projects/clawdeploy/PROJECT.md:26-31` — Pricing tiers (Solo $9, Pro $99 — Team REMOVED)
  - `/data/.openclaw/richard/projects/clawdeploy/PROJECT.md:33-40` — Competitive positioning table (Them vs Us)
  - `/data/.openclaw/richard/projects/clawdeploy/TEMPLATES.md` — Template features for showcase cards
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:39-47` — Landing page section list

  **External References**:
  - shadcn/ui docs: https://ui.shadcn.com — component library
  - Tailwind CSS: https://tailwindcss.com/docs

  **WHY Each Reference Matters**:
  - PROJECT.md competitive table is the exact content for the "Them vs Us" section
  - TEMPLATES.md features lists go directly into template showcase cards
  - MVP_SPRINT.md section list is the original spec for what sections to include

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Hero component renders "Deploy your AI team" heading
  - [ ] Test: Pricing table renders exactly 2 tiers (Solo, Pro) with correct prices
  - [ ] Test: Template cards render 2 templates
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Landing page renders all sections
    Tool: Playwright (playwright skill)
    Preconditions: Next.js dev server running on localhost:3000
    Steps:
      1. Navigate to `http://localhost:3000`
      2. Assert h1 contains "Deploy your AI team"
      3. Scroll to pricing section — assert 2 pricing cards visible
      4. Assert "$9" and "$99" text present
      5. Assert no "$49" text (Team tier removed)
      6. Assert FAQ section has 5+ accordion items
      7. Take full-page screenshot
    Expected Result: All sections render, correct pricing, no Team tier
    Failure Indicators: Missing sections, wrong prices, Team tier visible
    Evidence: .sisyphus/evidence/task-6-landing-page.png

  Scenario: Landing page is mobile responsive
    Tool: Playwright (playwright skill)
    Preconditions: Dev server running
    Steps:
      1. Set viewport to 375×812 (iPhone)
      2. Navigate to `http://localhost:3000`
      3. Assert no horizontal scroll
      4. Assert nav collapses to hamburger menu or stacks
      5. Assert pricing cards stack vertically
      6. Take mobile screenshot
    Expected Result: Clean mobile layout, no overflow
    Failure Indicators: Horizontal scroll, overlapping elements
    Evidence: .sisyphus/evidence/task-6-mobile.png
  ```

  **Commit**: YES
  - Message: `feat(web): landing page`
  - Files: `apps/web/app/page.tsx`, `apps/web/components/landing/`
  - Pre-commit: `turbo build`

- [ ] 7. Stripe Products + Prices Setup (Test Mode)

  **What to do**:
  - TDD: Write test verifying Stripe product/price IDs are correctly exported as constants
  - Using Stripe CLI or Dashboard, create products and prices in TEST mode:
    - Product: "ClawDeploy Solo" — Price: $9/month recurring
    - Product: "ClawDeploy Pro" — Price: $99/month recurring
  - Store price IDs in `packages/shared/src/constants/stripe.ts` as exported constants
  - Write a test that imports these constants and verifies they match expected format (`price_*`)
  - Document the Stripe product setup in a `.env.example` entry: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_SOLO_PRICE_ID`, `STRIPE_PRO_PRICE_ID`
  - Install `stripe` npm package in `apps/api`

  **Must NOT do**:
  - Create real/live mode products (test mode only)
  - Build any billing logic (Task 10)
  - Configure webhooks yet (Task 10)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Simple Stripe setup + constant definitions
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1
  - **Blocks**: Tasks 10, 16
  - **Blocked By**: None

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:142-149` — Stripe products spec (Solo $9, Pro $99 — Team removed)

  **External References**:
  - Stripe CLI: `stripe products create`, `stripe prices create`
  - Stripe API docs: https://stripe.com/docs/api/products

  **WHY Each Reference Matters**:
  - MVP_SPRINT.md confirms exact pricing and product names to create

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: `STRIPE_SOLO_PRICE_ID` and `STRIPE_PRO_PRICE_ID` constants export correctly
  - [ ] Test: Both match `price_*` format
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Stripe products exist in test mode
    Tool: Bash (stripe CLI)
    Preconditions: Stripe CLI authenticated
    Steps:
      1. Run `stripe products list --limit 5`
      2. Assert "ClawDeploy Solo" and "ClawDeploy Pro" appear
      3. Run `stripe prices list --limit 5`
      4. Assert $9.00 and $99.00 monthly prices exist
    Expected Result: 2 products, 2 prices in test mode
    Failure Indicators: Products missing or wrong amounts
    Evidence: .sisyphus/evidence/task-7-stripe-products.txt
  ```

  **Commit**: YES
  - Message: `chore(stripe): configure products and prices`
  - Files: `packages/shared/src/constants/stripe.ts`, `.env.example`
  - Pre-commit: `vitest run`

- [ ] 8. Clerk Auth Integration (Frontend + Backend)

  **What to do**:
  - TDD: Write tests for auth middleware (valid token → userId extracted, invalid token → 401, missing token → 401)
  - **Frontend (apps/web)**:
    - Install `@clerk/nextjs`
    - Configure ClerkProvider in root layout
    - Add sign-in/sign-up pages at `/sign-in` and `/sign-up` (Clerk hosted components)
    - Add `middleware.ts` protecting `/dashboard`, `/deploy`, `/billing` routes
    - Add user menu in nav (avatar + dropdown with Sign Out)
    - Create `user.created` webhook endpoint to sync Clerk users to PostgreSQL
  - **Backend (apps/api)**:
    - Install `@hono/clerk-auth`
    - Add auth middleware using `CLERK_JWT_KEY` (static PEM) for networkless JWT verification
    - All API routes require valid Clerk session token except `/api/health`, `/api/templates`, `/api/billing/webhook`
    - Extract `userId` from verified token via `getAuth(c).userId`
    - Create user sync: on first API call, upsert user in DB from Clerk claims
  - **Cross-service auth flow**: Frontend `getToken()` → `Authorization: Bearer {token}` → Backend `@hono/clerk-auth` → `getAuth(c).userId`
  - Add `CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`, `CLERK_JWT_KEY` to `.env.example`

  **Must NOT do**:
  - Custom login UI (use Clerk components)
  - Email/password auth (Google + GitHub only)
  - Role-based access control
  - Team/organization features

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Cross-service auth integration spanning frontend + backend with JWT verification
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 9-14)
  - **Blocks**: Tasks 15, 16, 17, 18, 19
  - **Blocked By**: Tasks 1, 2

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:332-342` — Frontend pages list showing auth-protected routes
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:362-366` — Security: "Clerk handles auth. All API routes require valid session token."

  **External References**:
  - `@clerk/nextjs` docs: https://clerk.com/docs/quickstarts/nextjs
  - `@hono/clerk-auth` docs: https://github.com/honojs/middleware/tree/main/packages/clerk-auth
  - Clerk JWT verification: https://clerk.com/docs/references/backend/jwt-verification

  **WHY Each Reference Matters**:
  - TECHNICAL_SCOPE.md page list defines which routes need auth protection
  - `@hono/clerk-auth` is the official first-party Hono middleware — don't roll your own
  - `CLERK_JWT_KEY` (static PEM) avoids JWKS network call on every request — critical for latency

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Auth middleware returns 401 for missing Authorization header
  - [ ] Test: Auth middleware returns 401 for invalid JWT
  - [ ] Test: Auth middleware extracts userId from valid JWT
  - [ ] Test: Public routes (/api/health, /api/templates) work without auth
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Protected API route rejects unauthenticated request
    Tool: Bash (curl)
    Preconditions: API server running locally
    Steps:
      1. Run `curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/api/instances`
    Expected Result: HTTP 401
    Failure Indicators: 200 or 500
    Evidence: .sisyphus/evidence/task-8-auth-reject.txt

  Scenario: Public route works without auth
    Tool: Bash (curl)
    Preconditions: API server running
    Steps:
      1. Run `curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/api/health`
      2. Run `curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/api/templates`
    Expected Result: Both return HTTP 200
    Failure Indicators: 401 on public routes
    Evidence: .sisyphus/evidence/task-8-public-routes.txt
  ```

  **Commit**: YES
  - Message: `feat: clerk auth integration (frontend + backend)`
  - Files: `apps/web/middleware.ts`, `apps/web/app/(auth)/`, `apps/api/src/middleware/auth.ts`
  - Pre-commit: `turbo test`

- [ ] 9. Railway API Client + Provisioning State Machine

  **What to do**:
  - TDD: Write tests for EVERY state transition in the provisioning state machine, including ALL failure/rollback paths
  - Create `apps/api/src/services/railway.ts` — Railway GraphQL API client:
    - Use `graphql-request` library
    - Auth: Bearer token from `RAILWAY_API_TOKEN` env var
    - Endpoint: `https://backboard.railway.com/graphql/v2`
    - Methods: `createProject()`, `createService(projectId, imageName)`, `upsertVariables(serviceId, envId, vars, skipDeploys: true)`, `deploy(serviceId, envId)`, `getDeploymentStatus(deploymentId)`, `deleteService(serviceId)`, `deleteProject(projectId)`, `updateServiceInstance(serviceId, envId, healthcheckPath, region, sleepApplication: false)`
  - Create `apps/api/src/services/provisioning.ts` — State machine:
    - States: PENDING → CREATING_PROJECT → CREATING_SERVICE → SETTING_VARIABLES → DEPLOYING → CONFIGURING → ACTIVE | FAILED
    - Each transition: update DB status, call Railway API, handle errors
    - **Compensating transactions on failure**: If CREATING_SERVICE fails → delete project. If DEPLOYING fails → delete service + project. If CONFIGURING fails (health timeout) → mark failed, keep resources for debugging.
    - Timeout: 10 minutes max for entire provisioning flow
    - Idempotency: accept idempotencyKey, check DB for existing provision with same key
  - Create `apps/api/src/services/teardown.ts`:
    - Delete Railway service → delete Railway project → update DB status to 'deleted'
    - Retry logic: 3 attempts with exponential backoff
    - Soft-delete in DB first (status='deleting'), hard-delete Railway resources, then mark 'deleted'
  - Use `RAILWAY_WORKSPACE_ID` env var for workspace scoping

  **Must NOT do**:
  - Auto-restart failed instances
  - Build admin UI for managing Railway resources
  - Support multiple Railway workspaces
  - Implement per-project cost tracking (V2)

  **Recommended Agent Profile**:
  - **Category**: `deep`
    - Reason: Complex state machine with distributed transaction rollback — needs careful logic
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2
  - **Blocks**: Tasks 15, 21, 22
  - **Blocked By**: Tasks 2, 3

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:240-282` — Railway provisioning pseudocode (createProject → createService → setVariables → deploy → pollHealth)

  **External References**:
  - Railway GraphQL API: `https://backboard.railway.com/graphql/v2`
  - Railway GraphQL explorer: https://railway.com/graphiql
  - `graphql-request` npm: https://github.com/jasonkuhrt/graphql-request

  **WHY Each Reference Matters**:
  - TECHNICAL_SCOPE.md pseudocode is the happy path — but must be extended with compensating transactions
  - Railway research confirmed exact mutations: `projectCreate`, `serviceCreate`, `variableCollectionUpsert`, `serviceInstanceDeployV2`, `serviceInstanceUpdate`

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: PENDING → CREATING_PROJECT → CREATING_SERVICE → DEPLOYING → CONFIGURING → ACTIVE (happy path)
  - [ ] Test: CREATING_PROJECT failure → status FAILED, no orphaned resources
  - [ ] Test: CREATING_SERVICE failure → project deleted, status FAILED
  - [ ] Test: DEPLOYING failure → service + project deleted, status FAILED
  - [ ] Test: CONFIGURING timeout (>10min) → status FAILED
  - [ ] Test: Idempotency — duplicate provision request returns existing instance
  - [ ] Test: Teardown — service deleted → project deleted → DB status 'deleted'
  - [ ] Test: Teardown retry on Railway API error (3 attempts)
  - [ ] `vitest run` → PASS (all state machine tests)

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Happy path provisioning (mocked Railway)
    Tool: Bash (vitest)
    Preconditions: Railway API mocked via MSW or similar
    Steps:
      1. Run provisioning state machine with valid inputs
      2. Assert state transitions: PENDING → CREATING_PROJECT → CREATING_SERVICE → SETTING_VARIABLES → DEPLOYING → CONFIGURING → ACTIVE
      3. Assert each Railway mutation was called exactly once
      4. Assert DB instance status is 'active'
    Expected Result: All transitions succeed, final state is ACTIVE
    Failure Indicators: State skipped, Railway call missing, wrong DB status
    Evidence: .sisyphus/evidence/task-9-happy-path.txt

  Scenario: Failure rollback cleans up Railway resources
    Tool: Bash (vitest)
    Preconditions: Railway API mocked to fail at CREATING_SERVICE
    Steps:
      1. Run provisioning with mock that rejects serviceCreate
      2. Assert projectDelete was called (cleanup)
      3. Assert DB instance status is 'failed'
      4. Assert no orphaned Railway project
    Expected Result: Project cleaned up, status is FAILED
    Failure Indicators: Project not deleted, status stuck at CREATING_SERVICE
    Evidence: .sisyphus/evidence/task-9-rollback.txt
  ```

  **Commit**: YES
  - Message: `feat(api): railway provisioning engine with state machine`
  - Files: `apps/api/src/services/railway.ts`, `apps/api/src/services/provisioning.ts`, `apps/api/src/services/teardown.ts`
  - Pre-commit: `vitest run`

- [ ] 10. Stripe Billing Service (Checkout, Webhooks, Enforcement)

  **What to do**:
  - TDD: Write tests for checkout session creation, webhook event handling (all event types), plan enforcement logic
  - Create `apps/api/src/services/billing.ts`:
    - `createCheckoutSession(userId, plan)` → returns Stripe checkout URL. Uses Stripe hosted checkout.
    - `createPortalSession(userId)` → returns Stripe billing portal URL
    - `handleWebhookEvent(event)` — processes:
      - `checkout.session.completed` → update user plan in DB, associate stripeCustomerId
      - `invoice.payment_failed` → set user grace period (3 days)
      - `customer.subscription.deleted` → pause all user instances (update status)
      - `customer.subscription.updated` → update plan if changed
    - `getUserPlan(userId)` → returns current plan from DB
    - `enforcePlanLimits(userId, templateId)` → check:
      - No subscription → reject with 'subscription_required'
      - Solo plan + marketing-team template → reject with 'plan_upgrade_required'
      - Solo plan + existing instance → reject with 'instance_limit_reached'
      - Pro plan + 2 existing instances → reject with 'instance_limit_reached'
  - Webhook endpoint: `POST /api/billing/webhook`
    - Verify Stripe signature using `STRIPE_WEBHOOK_SECRET`
    - Return 200 within 30 seconds — process slow operations async
    - Idempotency: check event ID hasn't been processed before
  - **CRITICAL**: Check BOTH `status` AND `cancel_at_period_end` in all plan checks (Metis finding)

  **Must NOT do**:
  - Custom payment form (use Stripe Checkout)
  - Custom upgrade/downgrade UI (use Stripe Customer Portal)
  - Prorated billing logic (Stripe handles this)
  - Trial periods (V2)

  **Recommended Agent Profile**:
  - **Category**: `deep`
    - Reason: Billing logic is money-critical with multiple webhook event types and enforcement rules
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2
  - **Blocks**: Tasks 16, 21
  - **Blocked By**: Tasks 2, 7

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:142-160` — Stripe integration spec (products, webhook events, plan enforcement)
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:352-358` — Billing API routes

  **External References**:
  - Stripe Checkout quickstart: https://stripe.com/docs/checkout/quickstart
  - Stripe webhook handling: https://stripe.com/docs/webhooks
  - Stripe test clocks: https://stripe.com/docs/testing#test-clocks

  **WHY Each Reference Matters**:
  - MVP_SPRINT.md lists exact webhook events to handle and plan enforcement rules
  - Stripe test clocks enable lifecycle testing (trial→active→past_due→canceled) in vitest

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: `createCheckoutSession` returns valid Stripe URL for solo plan
  - [ ] Test: `createCheckoutSession` returns valid Stripe URL for pro plan
  - [ ] Test: `checkout.session.completed` webhook → user plan updated in DB
  - [ ] Test: `invoice.payment_failed` webhook → user gets grace period
  - [ ] Test: `customer.subscription.deleted` webhook → instances paused
  - [ ] Test: No subscription → deploy blocked with 'subscription_required'
  - [ ] Test: Solo plan → marketing-team blocked with 'plan_upgrade_required'
  - [ ] Test: Solo plan → second instance blocked with 'instance_limit_reached'
  - [ ] Test: Pro plan → third instance blocked with 'instance_limit_reached'
  - [ ] Test: `cancel_at_period_end: true` + `status: active` → treated as canceling
  - [ ] Test: Webhook signature verification rejects invalid signatures
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Stripe webhook signature validation
    Tool: Bash (vitest)
    Preconditions: Stripe webhook secret configured
    Steps:
      1. Send webhook event with invalid signature
      2. Assert 400 response
      3. Send webhook event with valid signature
      4. Assert 200 response and event processed
    Expected Result: Invalid signature rejected, valid signature processed
    Failure Indicators: Invalid signature accepted, or valid signature rejected
    Evidence: .sisyphus/evidence/task-10-webhook-sig.txt

  Scenario: Plan enforcement blocks unauthorized deploy
    Tool: Bash (vitest)
    Preconditions: User with solo plan in test DB
    Steps:
      1. Call `enforcePlanLimits(userId, 'marketing-team')`
      2. Assert throws 'plan_upgrade_required'
      3. Call `enforcePlanLimits(userId, 'solo-assistant')` (first instance)
      4. Assert passes
      5. Call `enforcePlanLimits(userId, 'solo-assistant')` (second instance)
      6. Assert throws 'instance_limit_reached'
    Expected Result: Correct enforcement for all scenarios
    Failure Indicators: Wrong template allowed, or valid deploy blocked
    Evidence: .sisyphus/evidence/task-10-plan-enforcement.txt
  ```

  **Commit**: YES
  - Message: `feat(api): stripe billing service`
  - Files: `apps/api/src/services/billing.ts`, `apps/api/src/routes/billing.ts`
  - Pre-commit: `vitest run`

- [ ] 11. Discord Channel Auto-Creation Service

  **What to do**:
  - TDD: Write tests for channel creation logic (6 channels created, correct names, correct category, error handling)
  - Create `apps/api/src/services/discord.ts`:
    - `autoCreateChannels(guildId, botToken)` → uses Discord REST API to:
      1. Create category "HQ" in the guild
      2. Create 6 text channels under HQ: #general, #strategy, #engineering, #content, #research, #bd
      3. Return mapping of channel names → channel IDs
    - Use one of the 7 bot tokens (Richard's, since he's in all channels) for API calls
    - Bot must have "Manage Channels" permission in the guild
    - Handle errors: bot not in guild (403), missing permissions (403), guild not found (404)
  - This service is called during the Marketing Team deploy flow BEFORE setting Railway env vars
  - The returned channel IDs are injected into the openclaw.json config as env vars
  - Add `DISCORD_API_BASE=https://discord.com/api/v10` to constants

  **Must NOT do**:
  - Set channel permissions per bot (V2 — all bots can see all channels for now)
  - Create voice channels
  - Manage server roles
  - Handle channel deletion on instance teardown (channels persist)

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Discord API integration with error handling, but well-scoped
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2
  - **Blocks**: Task 15
  - **Blocked By**: Task 5

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TEMPLATES.md:69-77` — Channel structure (HQ category + 6 channels)

  **External References**:
  - Discord API: POST `/guilds/{guild.id}/channels` — https://discord.com/developers/docs/resources/guild#create-guild-channel
  - Discord channel types: 0 = text, 4 = category

  **WHY Each Reference Matters**:
  - TEMPLATES.md channel structure defines exact channel names and hierarchy to auto-create

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Creates HQ category + 6 text channels (mocked Discord API)
  - [ ] Test: Returns channel ID mapping (`{ general: "123", strategy: "456", ... }`)
  - [ ] Test: Handles 403 (missing permissions) with clear error message
  - [ ] Test: Handles 404 (guild not found) with clear error message
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Channel creation returns correct mapping
    Tool: Bash (vitest)
    Preconditions: Discord API mocked
    Steps:
      1. Call `autoCreateChannels("mock-guild-id", "mock-bot-token")`
      2. Assert 7 Discord API calls made (1 category + 6 channels)
      3. Assert returned mapping has keys: general, strategy, engineering, content, research, bd
      4. Assert all values are string IDs
    Expected Result: 6 channel IDs returned in mapping
    Failure Indicators: Missing channels, wrong names, API not called
    Evidence: .sisyphus/evidence/task-11-channel-creation.txt

  Scenario: Missing permissions handled gracefully
    Tool: Bash (vitest)
    Preconditions: Discord API mocked to return 403
    Steps:
      1. Call `autoCreateChannels` with mock 403 response
      2. Assert throws error with message containing "permissions"
    Expected Result: Clear error about missing bot permissions
    Failure Indicators: Generic error, crash, or silent failure
    Evidence: .sisyphus/evidence/task-11-permission-error.txt
  ```

  **Commit**: YES
  - Message: `feat(api): discord channel auto-creation`
  - Files: `apps/api/src/services/discord.ts`
  - Pre-commit: `vitest run`

- [ ] 12. Template Service (Manifest Loading, Config Generation)

  **What to do**:
  - TDD: Write tests for manifest loading, template listing, config generation with variable substitution
  - Create `apps/api/src/services/templates.ts`:
    - `listTemplates()` → reads all `templates/*/manifest.json`, returns template list with metadata
    - `getTemplate(templateId)` → returns full manifest + features
    - `generateConfig(templateId, userKeys, userInputs, channelIds?)`:
      1. Read template's `openclaw.json`
      2. Create env var mapping from user-provided keys, inputs, and auto-created channel IDs
      3. Return the mapping as key-value pairs for Railway env var injection
      4. Validate all required keys from manifest are provided
    - `validateUserKeys(templateId, providedKeys)` → check all requiredKeys from manifest are present
  - Templates are read from filesystem (`/openclaw/templates/` in Docker, `templates/` locally)
  - Template configs use `${ENV_VAR}` — we DON'T process these. We pass them to Railway as env vars and let OpenClaw resolve them natively.

  **Must NOT do**:
  - Template editing or creation via API
  - Template marketplace features
  - Dynamic template discovery (filesystem scan is fine)
  - Process `${ENV_VAR}` substitution ourselves — Railway + OpenClaw handle this

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Template loading + config generation with validation logic
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2
  - **Blocks**: Tasks 15, 16, 17
  - **Blocked By**: Tasks 2, 4, 5

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:108-238` — Template system (directory structure, manifest.json, config injection pseudocode)

  **WHY Each Reference Matters**:
  - TECHNICAL_SCOPE.md template section defines the complete template system architecture. Key insight from Metis: we may NOT need inject-config.js if OpenClaw resolves `${ENV_VAR}` natively — just pass vars to Railway.

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: `listTemplates()` returns 2 templates (solo-assistant, marketing-team)
  - [ ] Test: `getTemplate('solo-assistant')` returns correct manifest
  - [ ] Test: `validateUserKeys('solo-assistant', {anthropic: "key", telegram: "token"})` → passes
  - [ ] Test: `validateUserKeys('solo-assistant', {})` → throws missing keys error
  - [ ] Test: `generateConfig('solo-assistant', keys)` → returns env var mapping
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Template listing returns both templates
    Tool: Bash (vitest)
    Preconditions: Template directories exist with manifest.json
    Steps:
      1. Call `listTemplates()`
      2. Assert length is 2
      3. Assert IDs are 'solo-assistant' and 'marketing-team'
      4. Assert tiers are 'solo' and 'pro' respectively
    Expected Result: Both templates listed with correct metadata
    Failure Indicators: Missing template, wrong tier
    Evidence: .sisyphus/evidence/task-12-template-list.txt

  Scenario: Config generation maps user keys to env vars
    Tool: Bash (vitest)
    Preconditions: Solo template exists
    Steps:
      1. Call `generateConfig('solo-assistant', { anthropic: 'sk-test', telegram_bot_token: 'bot:123' })`
      2. Assert returned mapping has ANTHROPIC_API_KEY: 'sk-test'
      3. Assert returned mapping has TELEGRAM_BOT_TOKEN: 'bot:123'
    Expected Result: Correct env var mapping generated
    Failure Indicators: Missing or misnamed env vars
    Evidence: .sisyphus/evidence/task-12-config-gen.txt
  ```

  **Commit**: YES
  - Message: `feat(api): template service`
  - Files: `apps/api/src/services/templates.ts`
  - Pre-commit: `vitest run`

- [ ] 13. Health Monitoring Service

  **What to do**:
  - TDD: Write tests for health check logic (healthy → update DB, unhealthy → update DB, unreachable → update DB)
  - Create `apps/api/src/services/health.ts`:
    - `checkInstanceHealth(instance)`:
      - Fetch `https://{railway-service-url}/health` (or `/openclaw`) with 10s timeout
      - If 200 → update `isHealthy: true`, `lastHealthCheck: now`
      - If non-200 or timeout → update `isHealthy: false`, `lastHealthCheck: now`
    - `runHealthChecks()`:
      - Query all instances with status 'active'
      - Run health checks in parallel (max 10 concurrent)
      - Log results
  - Register health check cron: every 60 seconds via `setInterval` or Hono scheduled handler
  - Store results in instances table (`isHealthy`, `lastHealthCheck` columns)

  **Must NOT do**:
  - Auto-restart unhealthy instances (V2)
  - Send notifications on health changes (V2)
  - Track consecutive failures or degraded state (V2)
  - Complex alerting logic

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Simple HTTP health check + DB update
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2
  - **Blocks**: Tasks 15, 21
  - **Blocked By**: Task 2

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:370-399` — Health check implementation (polling, handleUnhealthy)

  **WHY Each Reference Matters**:
  - TECHNICAL_SCOPE.md health check code is more complex than V1 needs — simplify to just healthy/unhealthy boolean

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Healthy instance → `isHealthy: true` in DB
  - [ ] Test: Unhealthy instance (non-200) → `isHealthy: false` in DB
  - [ ] Test: Unreachable instance (timeout) → `isHealthy: false` in DB
  - [ ] Test: `runHealthChecks` processes multiple instances in parallel
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Health check updates DB correctly
    Tool: Bash (vitest)
    Preconditions: Mock HTTP responses for instance URLs
    Steps:
      1. Mock instance URL returning 200
      2. Call `checkInstanceHealth(instance)`
      3. Assert DB updated with isHealthy=true
      4. Mock instance URL returning 500
      5. Call `checkInstanceHealth(instance)`
      6. Assert DB updated with isHealthy=false
    Expected Result: DB reflects health status accurately
    Failure Indicators: DB not updated, wrong status
    Evidence: .sisyphus/evidence/task-13-health-check.txt
  ```

  **Commit**: YES (groups with Task 14)
  - Message: `feat(api): health monitoring + key encryption`
  - Files: `apps/api/src/services/health.ts`
  - Pre-commit: `vitest run`

- [ ] 14. User Keys Encryption Service

  **What to do**:
  - TDD: Write tests for encrypt/decrypt roundtrip, different key types, error on wrong encryption key
  - Create `apps/api/src/services/encryption.ts`:
    - `encryptKey(plaintext)` → AES-256-GCM encrypt using `ENCRYPTION_KEY` env var. Returns base64-encoded `iv:ciphertext:authTag`.
    - `decryptKey(encrypted)` → parse base64, decrypt with `ENCRYPTION_KEY`. Returns plaintext.
    - Use Node.js native `crypto` module (no external deps)
  - Create `apps/api/src/services/user-keys.ts`:
    - `storeUserKeys(userId, instanceId, keys)` → encrypt each key, store in `user_keys` table
    - `retrieveUserKeys(instanceId)` → fetch from DB, decrypt, return as key-value mapping
    - `deleteUserKeys(instanceId)` → remove all keys for instance from DB
  - `ENCRYPTION_KEY` stored as env var on Hono server, NOT in PostgreSQL (Metis requirement)
  - Keys are stored for restart scenarios (need to re-inject env vars if Railway service is recreated)

  **Must NOT do**:
  - Key rotation logic (V2)
  - HSM or KMS integration
  - Audit logging of key access

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Standard AES-256-GCM pattern with Node.js crypto
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2
  - **Blocks**: Task 15
  - **Blocked By**: Task 2

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:94-102` — user_keys table schema
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:362-363` — "encrypted with AES-256-GCM before storing in DB"

  **WHY Each Reference Matters**:
  - Schema defines key_type values (anthropic, openai, discord_bot_1, etc.) and encrypted_value column
  - Security section mandates AES-256-GCM specifically

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Encrypt then decrypt returns original plaintext
  - [ ] Test: Different plaintexts produce different ciphertexts (IV uniqueness)
  - [ ] Test: Decrypt with wrong ENCRYPTION_KEY throws error
  - [ ] Test: `storeUserKeys` encrypts all keys before DB insert
  - [ ] Test: `retrieveUserKeys` decrypts all keys from DB
  - [ ] Test: `deleteUserKeys` removes all keys for instance
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Encryption roundtrip preserves data
    Tool: Bash (vitest)
    Preconditions: ENCRYPTION_KEY env var set
    Steps:
      1. Encrypt "sk-ant-api-key-test123"
      2. Assert result is base64 and contains 2 colons (iv:ciphertext:tag format)
      3. Decrypt the result
      4. Assert decrypted equals "sk-ant-api-key-test123"
    Expected Result: Perfect roundtrip
    Failure Indicators: Decryption fails, data mismatch
    Evidence: .sisyphus/evidence/task-14-encryption-roundtrip.txt

  Scenario: Wrong key fails decryption
    Tool: Bash (vitest)
    Preconditions: Two different ENCRYPTION_KEYs
    Steps:
      1. Encrypt with key A
      2. Attempt decrypt with key B
      3. Assert error thrown
    Expected Result: Decryption fails with auth error
    Failure Indicators: Decryption succeeds with wrong key
    Evidence: .sisyphus/evidence/task-14-wrong-key.txt
  ```

  **Commit**: YES (groups with Task 13)
  - Message: `feat(api): health monitoring + key encryption`
  - Files: `apps/api/src/services/encryption.ts`, `apps/api/src/services/user-keys.ts`
  - Pre-commit: `vitest run`

- [ ] 15. API Routes — Deploy + Instances CRUD

  **What to do**:
  - TDD: Write tests for each route handler (auth check, input validation, correct service calls, response shape)
  - Create Hono route handlers in `apps/api/src/routes/instances.ts`:
    - `POST /api/instances` (deploy):
      1. Auth: require Clerk session
      2. Validate input: templateId, config (user keys + inputs) via Zod schema
      3. Enforce plan limits (call billing.enforcePlanLimits)
      4. Idempotency: check `X-Idempotency-Key` header, return existing if found
      5. Store encrypted user keys (call user-keys.storeUserKeys)
      6. If Marketing Team: auto-create Discord channels (call discord.autoCreateChannels)
      7. Generate env var mapping (call templates.generateConfig with channel IDs)
      8. Start provisioning async (call provisioning.provision — don't await, return immediately)
      9. Return instance with status 'pending' and instance ID
    - `GET /api/instances` (list):
      1. Auth: require Clerk session
      2. Query DB for all instances belonging to userId
      3. Return list with status, templateId, isHealthy, createdAt
    - `GET /api/instances/:id` (detail):
      1. Auth: require Clerk session + verify ownership
      2. Return full instance detail including Railway service URL
    - `POST /api/instances/:id/restart`:
      1. Auth + ownership check
      2. Call Railway API to redeploy service
      3. Update DB status to 'deploying'
    - `DELETE /api/instances/:id`:
      1. Auth + ownership check
      2. Idempotency check
      3. Start teardown async (call teardown.teardown)
      4. Return immediately with status 'deleting'

  **Must NOT do**:
  - Instance log streaming
  - Instance configuration editing
  - Batch operations (deploy multiple)

  **Recommended Agent Profile**:
  - **Category**: `deep`
    - Reason: Orchestrates multiple services (auth, billing, encryption, discord, templates, provisioning) with complex error handling
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 16)
  - **Parallel Group**: Wave 3
  - **Blocks**: Tasks 17, 21, 22
  - **Blocked By**: Tasks 8, 9, 11, 12, 13, 14

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:345-358` — API routes list

  **WHY Each Reference Matters**:
  - TECHNICAL_SCOPE.md routes define the exact endpoints, but this task adds idempotency, async provisioning, and Discord channel creation not in the original spec

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: POST /api/instances — valid input → 201 with instance data
  - [ ] Test: POST /api/instances — missing templateId → 400
  - [ ] Test: POST /api/instances — no subscription → 403
  - [ ] Test: POST /api/instances — wrong plan for template → 403
  - [ ] Test: POST /api/instances — duplicate idempotency key → returns existing
  - [ ] Test: GET /api/instances — returns only user's instances
  - [ ] Test: GET /api/instances/:id — wrong user → 404
  - [ ] Test: DELETE /api/instances/:id — returns 200, status 'deleting'
  - [ ] Test: POST /api/instances/:id/restart — triggers redeployment
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Deploy endpoint creates instance and starts provisioning
    Tool: Bash (curl)
    Preconditions: API running, Railway/Discord APIs mocked, test user with pro plan
    Steps:
      1. POST /api/instances with valid marketing-team config and auth token
      2. Assert HTTP 201
      3. Assert response has `id`, `status: "pending"`, `templateId: "marketing-team"`
      4. GET /api/instances/{id}
      5. Assert instance exists and status is updating (pending → creating_project → ...)
    Expected Result: Instance created, provisioning started
    Failure Indicators: 400/500, missing instance, provisioning not started
    Evidence: .sisyphus/evidence/task-15-deploy-endpoint.txt

  Scenario: Ownership check prevents accessing other user's instances
    Tool: Bash (curl)
    Preconditions: Two test users, instance belongs to user A
    Steps:
      1. GET /api/instances/{user-a-instance-id} with user B's auth token
      2. Assert HTTP 404 (not 403 — don't leak existence)
    Expected Result: 404 Not Found
    Failure Indicators: 200 with another user's data
    Evidence: .sisyphus/evidence/task-15-ownership-check.txt
  ```

  **Commit**: YES
  - Message: `feat(api): deploy + instances CRUD routes`
  - Files: `apps/api/src/routes/instances.ts`
  - Pre-commit: `vitest run`

- [ ] 16. API Routes — Templates + Billing

  **What to do**:
  - TDD: Write tests for template listing/detail (public), billing routes (authenticated)
  - Create Hono route handlers in `apps/api/src/routes/templates.ts`:
    - `GET /api/templates` (public — no auth):
      - Call templates.listTemplates()
      - Return array of template metadata (id, name, description, tier, agents, channels, features)
    - `GET /api/templates/:id` (public — no auth):
      - Call templates.getTemplate(id)
      - Return full manifest including requiredKeys (labels only, not values) and requiredInputs
  - Create Hono route handlers in `apps/api/src/routes/billing.ts`:
    - `POST /api/billing/checkout` (auth required):
      - Accept: `{ plan: 'solo' | 'pro' }`
      - Call billing.createCheckoutSession(userId, plan)
      - Return: `{ url: "https://checkout.stripe.com/..." }`
    - `POST /api/billing/webhook` (NO auth — Stripe signature verified instead):
      - Verify Stripe signature
      - Call billing.handleWebhookEvent(event)
      - Return 200 immediately
    - `POST /api/billing/portal` (auth required):
      - Call billing.createPortalSession(userId)
      - Return: `{ url: "https://billing.stripe.com/..." }`
  - Create `apps/api/src/routes/health.ts`:
    - `GET /api/health` (public):
      - Return `{ status: "ok", timestamp: Date.now() }`

  **Must NOT do**:
  - Custom pricing page API (frontend uses static pricing)
  - Invoice listing or history API
  - Usage tracking API

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Multiple route handlers with mixed auth requirements
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Tasks 15, 17-20)
  - **Parallel Group**: Wave 3
  - **Blocks**: Tasks 17, 19, 21
  - **Blocked By**: Tasks 8, 10, 12

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:345-358` — All API routes

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: GET /api/templates — returns 2 templates, no auth required
  - [ ] Test: GET /api/templates/solo-assistant — returns manifest with requiredKeys
  - [ ] Test: GET /api/templates/nonexistent — returns 404
  - [ ] Test: POST /api/billing/checkout — returns Stripe checkout URL
  - [ ] Test: POST /api/billing/webhook — valid signature → 200
  - [ ] Test: POST /api/billing/portal — returns portal URL
  - [ ] Test: GET /api/health — returns 200 with status "ok"
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Template listing is publicly accessible
    Tool: Bash (curl)
    Preconditions: API running with templates loaded
    Steps:
      1. GET /api/templates (no auth header)
      2. Assert HTTP 200
      3. Assert response is array with 2 items
      4. Assert first item has id, name, tier, agents, channels, features
    Expected Result: Public template listing works
    Failure Indicators: 401, empty array, missing fields
    Evidence: .sisyphus/evidence/task-16-public-templates.txt

  Scenario: Billing checkout creates Stripe session
    Tool: Bash (curl)
    Preconditions: API running, Stripe test mode, authenticated user
    Steps:
      1. POST /api/billing/checkout with `{"plan": "pro"}` and auth header
      2. Assert HTTP 200
      3. Assert response has `url` starting with "https://checkout.stripe.com"
    Expected Result: Valid Stripe checkout URL returned
    Failure Indicators: Missing URL, Stripe error
    Evidence: .sisyphus/evidence/task-16-checkout.txt
  ```

  **Commit**: YES
  - Message: `feat(api): templates + billing routes`
  - Files: `apps/api/src/routes/templates.ts`, `apps/api/src/routes/billing.ts`, `apps/api/src/routes/health.ts`
  - Pre-commit: `vitest run`

- [ ] 17. Deploy Flow UI (Template Picker → Key Input → Deploy)

  **What to do**:
  - TDD: Write component tests for template cards, key input form validation, deploy button states
  - Build deploy flow pages in `apps/web`:
    - `/deploy` — Template picker page:
      - Fetch templates from `GET /api/templates`
      - Display template cards: name, description, agent count, channel icons, tier badge, features list
      - Click card → navigate to `/deploy/[templateId]`
    - `/deploy/[templateId]` — Template detail + configuration form:
      - Fetch template detail from `GET /api/templates/:id`
      - Show template name, full description, features
      - Dynamic form generated from `manifest.requiredKeys` + `manifest.requiredInputs`:
        - Each key gets a password input field with label and hint text
        - Each input gets a text field with label and hint
        - Anthropic API key field has "Get from console.anthropic.com" helper link
        - Discord bot token fields have "How to create Discord bots" helper link (opens modal from Task 20)
      - Client-side validation: all required fields filled
      - [Deploy] button:
        - Disabled until all fields filled
        - On click: POST /api/instances with auth token
        - Loading state with spinner + "Deploying your AI team..."
        - On success: redirect to `/instance/[id]` (instance detail page)
        - On error: show error message (subscription_required → link to pricing, plan_upgrade_required → link to billing)
    - Plan gate: if user has no subscription, show pricing CTA instead of deploy form

  **Must NOT do**:
  - API key validation against provider (just format check)
  - Template customization (edit agent names, etc.)
  - Save draft / resume deploy later
  - Interactive model picker

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
    - Reason: Multi-step UI flow with dynamic form generation and loading states
  - **Skills**: [`frontend-ui-ux`]
    - `frontend-ui-ux`: Deploy flow is the core UX — must feel polished and trustworthy

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Tasks 18-20)
  - **Parallel Group**: Wave 3
  - **Blocks**: Task 21
  - **Blocked By**: Tasks 15, 16

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:89-105` — Deploy page UI spec
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:160-191` — manifest.json structure (requiredKeys with hints)

  **WHY Each Reference Matters**:
  - MVP_SPRINT.md deploy page spec defines exact UI elements and flow
  - manifest.json structure drives dynamic form generation — each requiredKey has label + hint for the input field

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Template picker renders 2 template cards
  - [ ] Test: Deploy form renders correct number of input fields for solo-assistant (2 fields)
  - [ ] Test: Deploy form renders correct number of input fields for marketing-team (9 fields)
  - [ ] Test: Deploy button disabled when fields empty
  - [ ] Test: Deploy button enabled when all fields filled
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Template picker shows both templates
    Tool: Playwright (playwright skill)
    Preconditions: Web app + API running, templates loaded
    Steps:
      1. Navigate to `http://localhost:3000/deploy` (authenticated)
      2. Assert 2 template cards visible
      3. Assert "Solo Assistant" card shows "1 agent" and "$9/mo"
      4. Assert "Marketing Team" card shows "7 agents" and "$99/mo"
      5. Click "Marketing Team" card
      6. Assert URL changes to `/deploy/marketing-team`
      7. Take screenshot
    Expected Result: Both templates shown with correct details, navigation works
    Failure Indicators: Missing templates, wrong details, navigation broken
    Evidence: .sisyphus/evidence/task-17-template-picker.png

  Scenario: Deploy form validates and submits
    Tool: Playwright (playwright skill)
    Preconditions: Web app running, user authenticated with pro plan
    Steps:
      1. Navigate to `/deploy/solo-assistant`
      2. Assert "Deploy" button is disabled
      3. Fill "Anthropic API Key" input with "sk-ant-test"
      4. Fill "Telegram Bot Token" input with "bot:test"
      5. Assert "Deploy" button is now enabled
      6. Click "Deploy"
      7. Assert loading spinner appears with "Deploying" text
      8. Take screenshot of loading state
    Expected Result: Form validates, submit triggers deploy
    Failure Indicators: Button not disabled initially, submit without validation
    Evidence: .sisyphus/evidence/task-17-deploy-form.png
  ```

  **Commit**: YES
  - Message: `feat(web): deploy flow UI`
  - Files: `apps/web/app/deploy/`, `apps/web/components/deploy/`
  - Pre-commit: `turbo build`

- [ ] 18. Dashboard UI (Instance List, Status, Actions)

  **What to do**:
  - TDD: Write component tests for instance card states (provisioning, active, failed, deleting), action buttons
  - Build dashboard page at `apps/web/app/dashboard/page.tsx`:
    - Fetch instances from `GET /api/instances` with auth
    - **Empty state**: If no instances, show "Deploy your first AI team" CTA linking to `/deploy`
    - **Instance cards** (for each instance):
      - Template name + icon
      - Status badge: green "Running" | yellow "Provisioning" | red "Failed" | gray "Deleting"
      - Health indicator: green dot (healthy) | red dot (unhealthy) — only shown when status is 'active'
      - Created date (relative: "2 hours ago")
      - Agent count
      - Action buttons: [View Details] [Restart] [Delete]
    - **Restart button**: confirmation dialog → POST /api/instances/:id/restart → optimistic UI update
    - **Delete button**: confirmation dialog ("Are you sure? This will permanently delete your instance.") → DELETE /api/instances/:id → remove from list
    - **Auto-refresh**: poll `GET /api/instances` every 10 seconds while any instance is in 'provisioning' or 'deploying' state. Stop polling when all instances are 'active' or 'failed'.

  **Must NOT do**:
  - Instance log viewer
  - Usage/analytics display
  - Sorting or filtering (only 1-2 instances expected per user)

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
    - Reason: Dashboard with real-time status updates and interactive actions
  - **Skills**: [`frontend-ui-ux`]

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Tasks 17, 19, 20)
  - **Parallel Group**: Wave 3
  - **Blocks**: Task 21
  - **Blocked By**: Tasks 8, 15

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:96-104` — Dashboard spec

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Empty state renders deploy CTA when no instances
  - [ ] Test: Instance card shows correct status badge for each state
  - [ ] Test: Delete button shows confirmation dialog
  - [ ] Test: Health dot renders green for healthy, red for unhealthy
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Dashboard shows instance with correct status
    Tool: Playwright (playwright skill)
    Preconditions: Web + API running, user has 1 active instance
    Steps:
      1. Navigate to `/dashboard` (authenticated)
      2. Assert at least 1 instance card visible
      3. Assert status badge shows "Running" (green)
      4. Assert health dot is green
      5. Assert [Restart] and [Delete] buttons are visible
      6. Take screenshot
    Expected Result: Instance card renders with correct status and actions
    Failure Indicators: Missing card, wrong status, missing buttons
    Evidence: .sisyphus/evidence/task-18-dashboard.png

  Scenario: Empty state shows deploy CTA
    Tool: Playwright (playwright skill)
    Preconditions: Web + API running, user has 0 instances
    Steps:
      1. Navigate to `/dashboard` (authenticated)
      2. Assert text "Deploy your first AI team" is visible
      3. Assert CTA button links to `/deploy`
    Expected Result: Empty state with clear action
    Failure Indicators: Blank page, no CTA
    Evidence: .sisyphus/evidence/task-18-empty-state.png
  ```

  **Commit**: YES
  - Message: `feat(web): dashboard UI`
  - Files: `apps/web/app/dashboard/`
  - Pre-commit: `turbo build`

- [ ] 19. Instance Detail Page + Billing Page

  **What to do**:
  - TDD: Write component tests for instance detail display, billing page CTA
  - **Instance detail page** at `apps/web/app/instance/[id]/page.tsx`:
    - Fetch from `GET /api/instances/:id`
    - Display: template name, status (large badge), health status, Railway service URL (when active), created date, agent count, channel type
    - Action buttons: [Restart] with confirmation, [Delete] with confirmation
    - Auto-refresh every 5 seconds while provisioning
    - If status is 'failed': show error message and [Retry Deploy] button
  - **Billing page** at `apps/web/app/billing/page.tsx`:
    - Show current plan (Free / Solo / Pro) with badge
    - If free: show pricing cards with [Subscribe] CTAs → POST /api/billing/checkout → redirect to Stripe
    - If subscribed: show [Manage Subscription] button → POST /api/billing/portal → redirect to Stripe portal
    - Show plan features and limits

  **Must NOT do**:
  - Invoice history display
  - Usage metrics
  - Custom plan change UI (use Stripe portal)

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
    - Reason: Detail page with real-time status + billing page with Stripe integration
  - **Skills**: [`frontend-ui-ux`]

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3
  - **Blocks**: Task 21
  - **Blocked By**: Tasks 8, 16

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:332-342` — Page list (instance detail, billing)
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:147-149` — Billing portal spec

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Instance detail renders template name and status
  - [ ] Test: Billing page shows current plan
  - [ ] Test: Free user sees pricing cards with subscribe CTAs
  - [ ] Test: Subscribed user sees "Manage Subscription" button
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Instance detail shows correct information
    Tool: Playwright (playwright skill)
    Preconditions: Web + API running, user has active instance
    Steps:
      1. Navigate to `/instance/{id}` (authenticated)
      2. Assert template name visible
      3. Assert status badge shows "Running"
      4. Assert [Restart] and [Delete] buttons visible
      5. Take screenshot
    Expected Result: All instance details rendered correctly
    Failure Indicators: Missing fields, wrong status
    Evidence: .sisyphus/evidence/task-19-instance-detail.png

  Scenario: Billing page redirects to Stripe
    Tool: Playwright (playwright skill)
    Preconditions: Web + API running, user on free plan
    Steps:
      1. Navigate to `/billing` (authenticated)
      2. Assert "Free" plan badge visible
      3. Assert pricing cards for Solo and Pro visible
      4. Click "Subscribe" on Solo
      5. Assert redirect URL contains "checkout.stripe.com"
    Expected Result: Stripe checkout redirect works
    Failure Indicators: No redirect, error on click
    Evidence: .sisyphus/evidence/task-19-billing.png
  ```

  **Commit**: YES
  - Message: `feat(web): instance detail + billing pages`
  - Files: `apps/web/app/instance/`, `apps/web/app/billing/`
  - Pre-commit: `turbo build`

- [ ] 20. Setup Guide Content (Inline Tooltips + Help Modals)

  **What to do**:
  - Create reusable help modal components in `apps/web/components/guides/`:
    - **"How to create Discord bots"** modal:
      1. Go to discord.dev/applications
      2. Create 7 applications (one per agent name)
      3. For each: Bot tab → create bot → copy token → enable Message Content Intent
      4. Invite all bots to your server with admin permissions
      5. Include screenshots or step illustrations
    - **"How to get your Anthropic API key"** modal:
      1. Go to console.anthropic.com
      2. Navigate to API Keys
      3. Create new key
      4. Copy and paste into deploy form
    - **"How to get your Discord Server ID"** modal:
      1. Enable Developer Mode in Discord settings
      2. Right-click server → Copy Server ID
  - Add tooltip/info icons next to each field in the deploy form (Task 17) that open the relevant guide modal
  - Content should be concise, step-by-step, with numbered lists

  **Must NOT do**:
  - Full docs site or knowledge base
  - Video tutorials
  - Search functionality
  - Screenshots from external services (text descriptions only — screenshots change)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Static content creation with simple modal components
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3
  - **Blocks**: Task 17 (provides help modals for deploy form)
  - **Blocked By**: None (content can be written independently)

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TEMPLATES.md:106-113` — Discord bot setup steps
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:157-158` — "Setup guide page: How to create Discord bots"

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Discord bot guide modal renders with 5+ steps
  - [ ] Test: Anthropic key guide modal renders
  - [ ] Test: Guild ID guide modal renders
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Help modal opens from deploy form
    Tool: Playwright (playwright skill)
    Preconditions: Web running, on deploy form page
    Steps:
      1. Navigate to `/deploy/marketing-team`
      2. Find info icon next to "Discord Bot Token (Richard)" field
      3. Click the info icon
      4. Assert modal opens with "How to create Discord bots" title
      5. Assert modal contains numbered steps
      6. Close modal
      7. Take screenshot of modal
    Expected Result: Modal opens with clear setup instructions
    Failure Indicators: No modal, empty content, broken layout
    Evidence: .sisyphus/evidence/task-20-help-modal.png
  ```

  **Commit**: YES
  - Message: `feat(web): setup guide tooltips`
  - Files: `apps/web/components/guides/`
  - Pre-commit: `turbo build`

- [ ] 21. End-to-End Integration Tests

  **What to do**:
  - TDD: Write full integration test suite covering the critical path end-to-end
  - Create `apps/api/src/__tests__/integration/`:
    - **Auth integration**: Clerk JWT verification works with real JWT structure (use test tokens)
    - **Deploy flow integration** (mocked Railway + Discord + Stripe):
      1. Create user (simulate Clerk webhook)
      2. Simulate `checkout.session.completed` webhook → plan set to 'solo'
      3. POST /api/instances with solo-assistant config → 201
      4. Verify provisioning state machine runs: PENDING → CREATING_PROJECT → ... → ACTIVE
      5. GET /api/instances → instance appears in list
      6. GET /api/instances/:id → correct details
      7. POST /api/instances/:id/restart → 200
      8. DELETE /api/instances/:id → 200, status 'deleting'
      9. Verify teardown: Railway service deleted, Railway project deleted, DB updated to 'deleted'
    - **Marketing Team deploy integration** (includes Discord channel creation):
      1. Subscribe user to pro plan
      2. Deploy marketing-team template with 7 bot tokens + guild ID
      3. Verify Discord.autoCreateChannels was called with correct guild ID
      4. Verify Railway env vars include all 7 bot tokens + 6 channel IDs
    - **Plan enforcement integration**:
      1. Solo user → deploy solo-assistant → success
      2. Solo user → deploy second solo-assistant → 403 (instance_limit_reached)
      3. Solo user → deploy marketing-team → 403 (plan_upgrade_required)
    - **Billing webhook integration** (use `stripe trigger` for event shapes):
      1. `checkout.session.completed` → user plan updated
      2. `customer.subscription.deleted` → instances paused
      3. `invoice.payment_failed` → grace period set
  - Use in-memory PostgreSQL (`pg-mem`) for test DB
  - Use MSW (Mock Service Worker) or `nock` for mocking Railway GraphQL, Discord REST, Stripe

  **Must NOT do**:
  - Real Railway/Stripe/Discord API calls in tests
  - UI/browser tests (Playwright is only for Wave 3-4 QA scenarios)
  - Database migrations in test setup — use `pg-mem` schema

  **Recommended Agent Profile**:
  - **Category**: `deep`
    - Reason: Complex integration test suite covering multiple services and state machines
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 22)
  - **Parallel Group**: Wave 4
  - **Blocks**: Task 25
  - **Blocked By**: Tasks 15, 16, 17, 18, 19

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:240-282` — Provisioning flow (happy path)
  - Task 9 state machine tests — integration tests extend these with full API layer

  **External References**:
  - `pg-mem`: https://github.com/oguimbal/pg-mem — in-memory PostgreSQL
  - MSW: https://mswjs.io — API mocking
  - Stripe CLI: `stripe trigger checkout.session.completed` — generates real event shapes

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Full deploy + teardown lifecycle (solo-assistant)
  - [ ] Test: Full deploy lifecycle (marketing-team) with channel auto-creation
  - [ ] Test: All 3 plan enforcement scenarios
  - [ ] Test: All 3 Stripe webhook events
  - [ ] Test: Auth fails gracefully for all protected routes
  - [ ] `vitest run` → PASS (all integration tests)

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Integration test suite passes completely
    Tool: Bash (vitest)
    Preconditions: All Wave 1-3 tasks complete
    Steps:
      1. Run `vitest run apps/api/src/__tests__/integration/`
      2. Assert 0 failing tests
      3. Assert coverage includes all state machine transitions
    Expected Result: All integration tests pass
    Failure Indicators: Any test failure
    Evidence: .sisyphus/evidence/task-21-integration-tests.txt
  ```

  **Commit**: YES (groups with Task 22)
  - Message: `test: end-to-end integration + rollback tests`
  - Files: `apps/api/src/__tests__/integration/`
  - Pre-commit: `vitest run`

- [ ] 22. Provisioning Failure + Rollback Tests

  **What to do**:
  - TDD: Write exhaustive failure scenario tests for the provisioning state machine
  - Create `apps/api/src/__tests__/integration/provisioning-failures.test.ts`:
    - **Railway API failures at each step**:
      - `createProject` throws → no Railway resources created, DB status 'failed'
      - `createService` throws → `deleteProject` called, DB status 'failed'
      - `upsertVariables` throws → `deleteService` + `deleteProject` called, DB status 'failed'
      - `deploy` throws → `deleteService` + `deleteProject` called, DB status 'failed'
      - Health check timeout (mock time passing) → DB status 'failed', Railway resources preserved for debugging
    - **Retry behavior**:
      - Railway API rate-limited (429) → retry with exponential backoff, max 3 attempts
      - Railway API 5xx → retry once, then fail
    - **Teardown failures**:
      - `deleteService` fails → retry 3 times → mark for manual cleanup, DB soft-deleted
      - `deleteProject` fails → same retry behavior
    - **Discord channel creation failures**:
      - Bot not in guild → deploy fails with clear error before Railway provisioning starts
      - Missing permissions → deploy fails with clear error
    - **Concurrent deploy prevention**:
      - Two simultaneous deploys with same idempotency key → second returns first instance
      - Two simultaneous deploys with different keys from same user (plan limit) → second rejected

  **Recommended Agent Profile**:
  - **Category**: `deep`
    - Reason: Exhaustive failure scenario coverage requires careful test setup
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 21)
  - **Parallel Group**: Wave 4
  - **Blocks**: Task 25
  - **Blocked By**: Tasks 9, 15

  **References**:

  **Pattern References**:
  - Task 9 state machine (compensating transactions) — these tests verify that implementation
  - Metis review: E1-E11 edge cases table — map each to a test case

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: createProject failure → no orphaned resources
  - [ ] Test: createService failure → project deleted
  - [ ] Test: deploy failure → service + project deleted
  - [ ] Test: health timeout → status 'failed', resources kept
  - [ ] Test: 429 rate limit → retry backoff → eventually succeeds
  - [ ] Test: teardown retry on failure (3 attempts)
  - [ ] Test: Discord 403 → deploy fails before Railway provisioning
  - [ ] Test: Duplicate idempotency key → returns existing instance
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: All rollback paths clean up Railway resources
    Tool: Bash (vitest)
    Preconditions: Railway API mock that fails at each step
    Steps:
      1. For each failure point (createProject, createService, deploy):
         Run provisioning with mock failure at that step
         Assert corresponding cleanup calls were made
         Assert DB status is 'failed'
         Assert no remaining Railway mocked resources
    Expected Result: All 3 failure scenarios cleanly roll back
    Failure Indicators: Cleanup not called, status not updated, orphaned resources
    Evidence: .sisyphus/evidence/task-22-rollback-tests.txt
  ```

  **Commit**: YES (groups with Task 21)
  - Message: `test: end-to-end integration + rollback tests`
  - Files: `apps/api/src/__tests__/integration/provisioning-failures.test.ts`
  - Pre-commit: `vitest run`

- [ ] 23. Error Handling, Loading States, Edge Cases

  **What to do**:
  - Audit ALL API routes for consistent error responses: `{ error: string, code: string }` shape
  - Audit ALL frontend pages for loading states and error boundaries:
    - Deploy form: loading spinner while deploying, error message on failure with actionable guidance
    - Dashboard: skeleton loading while fetching instances
    - Instance detail: "Loading..." while fetching, "Instance not found" for 404
    - Billing page: loading while fetching plan
  - Add Next.js error boundaries (`error.tsx`) for each route segment
  - Add Hono global error handler middleware for unhandled errors → 500 with structured response
  - Handle specific frontend error codes:
    - `subscription_required` → show pricing CTA
    - `plan_upgrade_required` → show upgrade CTA with billing link
    - `instance_limit_reached` → show "Max instances reached" message
  - Add double-click protection on all form submit buttons (disable on first click, re-enable on error)
  - Handle instance status `failed` in dashboard: show red badge + "Retry" button
  - Handle Railway timeout (>10 min in provisioning): show "Deploy taking too long" message with retry option

  **Must NOT do**:
  - Toast notifications library (use inline error messages only)
  - Global error reporting service (V2)
  - Retry logic in frontend (just show error with manual retry button)

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Cross-cutting concern touching many files in both apps
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Tasks 22, 24)
  - **Parallel Group**: Wave 4
  - **Blocks**: Task 25
  - **Blocked By**: Tasks 15, 16, 17, 18

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:401-410` — Error handling table
  - Metis review: E1-E11 edge cases — map each to a UI/API handling pattern

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Global error handler returns `{ error, code }` for unhandled errors
  - [ ] Test: All route handlers return consistent error shape
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Deploy error shows actionable message
    Tool: Playwright (playwright skill)
    Preconditions: API mocked to return plan_upgrade_required
    Steps:
      1. Navigate to `/deploy/marketing-team` as solo user
      2. Fill form and click Deploy
      3. Assert error message appears: "This template requires the Pro plan"
      4. Assert "Upgrade to Pro" link is visible linking to /billing
      5. Assert Deploy button is re-enabled
      6. Take screenshot
    Expected Result: Clear error with upgrade path
    Failure Indicators: Generic error, no CTA, button stays disabled
    Evidence: .sisyphus/evidence/task-23-deploy-error.png

  Scenario: Double-click prevented on deploy
    Tool: Playwright (playwright skill)
    Preconditions: Deploy form filled, slow API response mocked
    Steps:
      1. Click Deploy button
      2. Immediately click Deploy button again
      3. Assert only 1 API request was made (check network log)
    Expected Result: Only 1 deploy request sent
    Failure Indicators: 2 requests sent
    Evidence: .sisyphus/evidence/task-23-double-click.txt
  ```

  **Commit**: YES
  - Message: `fix: error handling, loading states, mobile responsive`
  - Files: `apps/api/src/middleware/error.ts`, `apps/web/app/**/error.tsx`, various component updates
  - Pre-commit: `turbo test`

- [ ] 24. Mobile Responsive Polish

  **What to do**:
  - Audit all pages at 375px (iPhone SE), 768px (tablet), 1280px (desktop)
  - Fix any layout issues:
    - Landing page: nav collapses, pricing cards stack, template cards stack
    - Deploy form: input fields full-width on mobile, help tooltips accessible on touch
    - Dashboard: instance cards stack vertically, action buttons remain accessible
    - Instance detail: status badge prominent on mobile
    - Billing page: pricing cards stack on mobile
  - Ensure all interactive elements have minimum 44×44px touch target
  - Test dark mode toggle works on all pages
  - Check that all text has sufficient contrast ratio (WCAG AA minimum)
  - Fix any `text-overflow` or truncation issues on small screens

  **Must NOT do**:
  - Native mobile app
  - PWA features
  - Offline support
  - Complex gesture interactions

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
    - Reason: Responsive layout fixes across multiple pages
  - **Skills**: [`frontend-ui-ux`]

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Tasks 21-23)
  - **Parallel Group**: Wave 4
  - **Blocks**: Task 25
  - **Blocked By**: Tasks 6, 17, 18, 19

  **References**:

  **Pattern References**:
  - Tailwind responsive prefixes: `sm:`, `md:`, `lg:` — use throughout
  - shadcn/ui components handle most responsive behavior natively

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test: Landing page hero renders at 375px without overflow
  - [ ] `vitest run` → PASS

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: All pages pass mobile layout check
    Tool: Playwright (playwright skill)
    Preconditions: Web app running
    Steps:
      1. Set viewport to 375×812
      2. Visit /, /deploy, /dashboard, /billing
      3. For each page: assert no horizontal scroll (scrollWidth <= 375)
      4. Assert all buttons are at least 44px tall
      5. Take screenshots of each page
    Expected Result: No overflow, usable touch targets
    Failure Indicators: Horizontal scroll on any page
    Evidence: .sisyphus/evidence/task-24-mobile-{page}.png
  ```

  **Commit**: YES (groups with Task 23)
  - Message: `fix: error handling, loading states, mobile responsive`
  - Files: Various Tailwind class updates across `apps/web`
  - Pre-commit: `turbo build`

- [ ] 25. Production Deployment (Vercel + Railway)

  **What to do**:
  - **Frontend (Vercel)**:
    - Connect GitHub repo to Vercel
    - Set build command: `turbo build --filter=web`
    - Set env vars: `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`, `NEXT_PUBLIC_API_URL` (Railway API URL)
    - Set custom domain if available (clawdeploy.com or chosen domain)
    - Verify build succeeds and site is live
  - **Backend (Railway)**:
    - Create Railway service from GitHub repo (apps/api)
    - Set start command: `node dist/index.js` (or `tsx src/index.ts`)
    - Provision PostgreSQL on Railway (same project)
    - Run DB migrations: `drizzle-kit push` or migration script
    - Set ALL env vars: `DATABASE_URL`, `CLERK_SECRET_KEY`, `CLERK_JWT_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_SOLO_PRICE_ID`, `STRIPE_PRO_PRICE_ID`, `RAILWAY_API_TOKEN`, `RAILWAY_WORKSPACE_ID`, `ENCRYPTION_KEY`, `CORS_ORIGIN` (Vercel URL)
    - Set Railway custom domain for API if desired
  - **Stripe production setup**:
    - Register webhook endpoint: `https://api.clawdeploy.com/api/billing/webhook` (or Railway URL)
    - Configure webhook to listen for: `checkout.session.completed`, `invoice.payment_failed`, `customer.subscription.deleted`, `customer.subscription.updated`
    - Copy `STRIPE_WEBHOOK_SECRET` from Stripe dashboard → set on Railway
    - Promote Stripe products from test to live mode (or recreate in live mode)
  - **Clerk production setup**:
    - Switch Clerk instance from development to production mode
    - Configure Google OAuth app credentials (production)
    - Configure GitHub OAuth app credentials (production)
    - Set production URLs in Clerk dashboard
  - **Docker image**: Tag and push to GHCR (Task 26 dependency — coordinate)
  - **CORS**: Set `CORS_ORIGIN` env var on API to match Vercel frontend URL
  - **Health check**: Verify `https://{api-url}/api/health` returns 200 after deploy

  **Must NOT do**:
  - Custom deployment pipeline / CI (GitHub Actions) — V2
  - Blue-green deployment
  - Auto-scaling config
  - Custom SSL (Railway/Vercel handle this)

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Multi-service production deployment coordination
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 26)
  - **Parallel Group**: Wave 5
  - **Blocks**: Task 27
  - **Blocked By**: Tasks 21, 22, 23, 24

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:36-50` — Day 1-2 setup tasks (Vercel, Railway, Clerk, Stripe setup)
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:51-64` — Tech stack hosting decisions

  **Acceptance Criteria**:

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Production API health check passes
    Tool: Bash (curl)
    Preconditions: Railway deployment complete
    Steps:
      1. curl -s -o /dev/null -w "%{http_code}" https://{api-url}/api/health
    Expected Result: HTTP 200
    Failure Indicators: Non-200, connection refused
    Evidence: .sisyphus/evidence/task-25-api-health.txt

  Scenario: Production frontend loads
    Tool: Bash (curl)
    Preconditions: Vercel deployment complete
    Steps:
      1. curl -s https://{frontend-url} | grep "Deploy your AI team"
    Expected Result: Match found
    Failure Indicators: No match, connection error
    Evidence: .sisyphus/evidence/task-25-frontend-live.txt

  Scenario: Stripe webhook registered and reachable
    Tool: Bash (stripe CLI)
    Preconditions: Stripe webhook configured
    Steps:
      1. stripe trigger checkout.session.completed --api-key {live-key}
      2. Check Stripe dashboard for webhook delivery
    Expected Result: 200 delivery logged in Stripe dashboard
    Failure Indicators: Delivery failure, timeout
    Evidence: .sisyphus/evidence/task-25-webhook-delivery.txt
  ```

  **Commit**: YES
  - Message: `chore: production deployment (Vercel + Railway)`
  - Files: `.env.production.example`, deployment notes

- [ ] 26. Docker Image Publish to GHCR

  **What to do**:
  - Tag Docker image: `ghcr.io/shirollsasaki/openclaw-runtime:latest` + `ghcr.io/shirollsasaki/openclaw-runtime:{git-sha}`
  - Authenticate to GHCR: `echo $GHCR_TOKEN | docker login ghcr.io -u shirollsasaki --password-stdin`
  - Push both tags: `docker push ghcr.io/shirollsasaki/openclaw-runtime:latest`
  - Verify pull works: `docker pull ghcr.io/shirollsasaki/openclaw-runtime:latest` from a fresh context
  - Set GHCR package visibility to **public** (so Railway can pull without credentials — avoids the UI-only private registry gotcha from research)
  - Update Railway provisioning service (Task 9) constant: `DOCKER_IMAGE = 'ghcr.io/shirollsasaki/openclaw-runtime:latest'`
  - Verify the image on GHCR starts and health check responds (re-run Task 3 QA scenarios against the published image)

  **Must NOT do**:
  - Private GHCR image (Railway can't pull private images without UI-only credentials setup)
  - Multiple image variants per template (one image handles all templates via env vars)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Docker tag + push + verify
  - **Skills**: [`git-master`]
    - `git-master`: Needed for git SHA tagging

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 25)
  - **Parallel Group**: Wave 5
  - **Blocks**: Task 27
  - **Blocked By**: Task 3

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/TECHNICAL_SCOPE.md:286-299` — Dockerfile spec
  - Railway research: "Private registry credentials are UI-only → use public GHCR image"

  **External References**:
  - GHCR docs: https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry

  **Acceptance Criteria**:

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Public GHCR image pulls and runs
    Tool: Bash (docker)
    Preconditions: Image pushed to GHCR
    Steps:
      1. docker pull ghcr.io/shirollsasaki/openclaw-runtime:latest (from fresh context, no local cache)
      2. Run container with test env vars
      3. curl -f http://localhost:18789/health
    Expected Result: Pull succeeds, health check responds 200
    Failure Indicators: Pull auth error, health check fails
    Evidence: .sisyphus/evidence/task-26-ghcr-pull.txt
  ```

  **Commit**: YES
  - Message: `chore: publish openclaw-runtime image to GHCR`

- [ ] 27. Production Smoke Test

  **What to do**:
  - Execute a complete end-to-end smoke test against the production environment:
    1. **Sign up**: Navigate to production frontend, click "Get Started", sign up via Google or GitHub through Clerk
    2. **Subscribe**: Navigate to /billing, subscribe to Solo plan via Stripe test card (4242 4242 4242 4242)
    3. **Deploy Solo**: Navigate to /deploy, pick Solo Assistant, enter a real Anthropic API key (test key) and Telegram bot token, click Deploy
    4. **Verify provisioning**: Watch dashboard, confirm status moves from Provisioning → Running within 5 minutes
    5. **Verify agent**: Send a Telegram message to the deployed bot, confirm it responds
    6. **Restart**: Click Restart on dashboard, confirm instance recovers
    7. **Delete**: Click Delete on dashboard, confirm instance is removed and Railway service is cleaned up
    8. **Marketing Team**: Subscribe to Pro, deploy Marketing Team, verify 6 Discord channels auto-created, verify all 7 agents come online
  - Document any issues found and fix before marking task complete
  - Capture evidence (screenshots, curl outputs) for all steps

  **Must NOT do**:
  - Load testing or performance benchmarking
  - Security penetration testing
  - Multi-user concurrency testing

  **Recommended Agent Profile**:
  - **Category**: `deep`
    - Reason: Full production smoke test requires careful orchestration and real external services
  - **Skills**: [`playwright`]
    - `playwright`: Browser automation for UI flow verification

  **Parallelization**:
  - **Can Run In Parallel**: NO — requires Tasks 25 + 26 complete
  - **Parallel Group**: Sequential after Wave 5
  - **Blocks**: F1-F4 (Final Verification Wave)
  - **Blocked By**: Tasks 25, 26

  **References**:

  **Pattern References**:
  - `/data/.openclaw/richard/projects/clawdeploy/MVP_SPRINT.md:99-105` — End-to-end test checklist

  **Acceptance Criteria**:

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Solo Assistant full lifecycle on production
    Tool: Playwright (playwright skill) + Bash
    Preconditions: Production deployed, real Anthropic API key + Telegram bot token available
    Steps:
      1. Sign up via Google OAuth on production site
      2. Subscribe to Solo plan (Stripe test card 4242...)
      3. Deploy Solo Assistant with real credentials
      4. Poll dashboard until status "Running" (timeout: 5 min)
      5. Send "/help" to Telegram bot
      6. Assert bot replies within 30 seconds
      7. Click Restart → wait 2 min → assert status returns to Running
      8. Click Delete → confirm → wait 1 min → assert instance removed from dashboard
    Expected Result: Full lifecycle works on production
    Failure Indicators: Any step fails or times out
    Evidence: .sisyphus/evidence/task-27-solo-lifecycle.png

  Scenario: Marketing Team deploys with auto-created channels
    Tool: Playwright (playwright skill) + Bash
    Preconditions: Pro plan subscribed, 7 Discord bot tokens + guild ID ready
    Steps:
      1. Deploy Marketing Team template with all credentials
      2. Poll dashboard until status "Running" (timeout: 10 min)
      3. Check Discord server — assert HQ category exists
      4. Assert 6 channels exist: #general, #strategy, #engineering, #content, #research, #bd
      5. Send "@Richard hello" in #general
      6. Assert Richard responds within 60 seconds
    Expected Result: 7 agents online, 6 channels auto-created, agents respond
    Failure Indicators: Timeout, missing channels, agents don't respond
    Evidence: .sisyphus/evidence/task-27-marketing-team.png
  ```

  **Commit**: YES
  - Message: `test: production smoke test`

---

## Final Verification Wave (MANDATORY — after ALL implementation tasks)

> 4 review agents run in PARALLEL. ALL must APPROVE. Rejection → fix → re-run.

- [ ] F1. **Plan Compliance Audit** — `oracle`
  Read the plan end-to-end. For each "Must Have": verify implementation exists (read file, curl endpoint, run command). For each "Must NOT Have": search codebase for forbidden patterns — reject with file:line if found. Check evidence files exist in .sisyphus/evidence/. Compare deliverables against plan.
  Output: `Must Have [N/N] | Must NOT Have [N/N] | Tasks [N/N] | VERDICT: APPROVE/REJECT`

- [ ] F2. **Code Quality Review** — `unspecified-high`
  Run `tsc --noEmit` + linter + `vitest run`. Review all changed files for: `as any`/`@ts-ignore`, empty catches, console.log in prod, commented-out code, unused imports. Check AI slop: excessive comments, over-abstraction, generic names (data/result/item/temp).
  Output: `Build [PASS/FAIL] | Lint [PASS/FAIL] | Tests [N pass/N fail] | Files [N clean/N issues] | VERDICT`

- [ ] F3. **Real Manual QA** — `unspecified-high` (+ `playwright` skill for UI)
  Start from clean state. Execute EVERY QA scenario from EVERY task — follow exact steps, capture evidence. Test cross-task integration (features working together, not isolation). Test edge cases: empty state, invalid input, rapid actions. Save to `.sisyphus/evidence/final-qa/`.
  Output: `Scenarios [N/N pass] | Integration [N/N] | Edge Cases [N tested] | VERDICT`

- [ ] F4. **Scope Fidelity Check** — `deep`
  For each task: read "What to do", read actual diff (git log/diff). Verify 1:1 — everything in spec was built (no missing), nothing beyond spec was built (no creep). Check "Must NOT do" compliance. Detect cross-task contamination: Task N touching Task M's files. Flag unaccounted changes.
  Output: `Tasks [N/N compliant] | Contamination [CLEAN/N issues] | Unaccounted [CLEAN/N files] | VERDICT`

---

## Commit Strategy

| After Task(s) | Message | Verification |
|------------|---------|--------------|
| 1 | `chore: scaffold clawdeploy monorepo` | `turbo build` passes |
| 2 | `feat(shared): add DB schema, types, and migrations` | `vitest run` passes in shared |
| 3 | `feat(docker): openclaw-runtime image with validation` | `docker build` succeeds |
| 4, 5 | `feat(templates): package solo-assistant and marketing-team` | templates validate against manifest schema |
| 6 | `feat(web): landing page` | `turbo build` passes |
| 7 | `chore(stripe): configure products and prices` | stripe CLI confirms products |
| 8 | `feat: clerk auth integration (frontend + backend)` | `vitest run` passes |
| 9 | `feat(api): railway provisioning engine with state machine` | `vitest run` passes |
| 10 | `feat(api): stripe billing service` | `vitest run` passes |
| 11 | `feat(api): discord channel auto-creation` | `vitest run` passes |
| 12 | `feat(api): template service` | `vitest run` passes |
| 13, 14 | `feat(api): health monitoring + key encryption` | `vitest run` passes |
| 15 | `feat(api): deploy + instances CRUD routes` | `vitest run` passes |
| 16 | `feat(api): templates + billing routes` | `vitest run` passes |
| 17 | `feat(web): deploy flow UI` | `turbo build` passes |
| 18 | `feat(web): dashboard UI` | `turbo build` passes |
| 19 | `feat(web): instance detail + billing pages` | `turbo build` passes |
| 20 | `feat(web): setup guide tooltips` | `turbo build` passes |
| 21, 22 | `test: end-to-end integration + rollback tests` | `vitest run` passes |
| 23, 24 | `fix: error handling, loading states, mobile responsive` | `turbo build` passes |
| 25, 26 | `chore: production deployment + GHCR publish` | production health check passes |
| 27 | `test: production smoke test` | all smoke tests pass |

---

## Success Criteria

### Verification Commands
```bash
# Monorepo builds
turbo build                          # Expected: all apps build successfully

# All tests pass
turbo test                           # Expected: all vitest suites pass

# Docker image builds and runs
docker build -t openclaw-runtime .   # Expected: succeeds, < 1GB
docker run -d -p 18789:18789 ...     # Expected: health check responds 200

# API health
curl https://api.clawdeploy.com/api/health  # Expected: 200 OK

# Frontend loads
curl -s https://clawdeploy.com | grep "Deploy your AI team"  # Expected: match

# Stripe webhook
stripe trigger checkout.session.completed  # Expected: webhook processed
```

### Final Checklist
- [ ] All "Must Have" items present and functional
- [ ] All "Must NOT Have" items absent from codebase
- [ ] All vitest tests pass (`turbo test`)
- [ ] Docker image builds and starts successfully
- [ ] Landing page loads on Vercel
- [ ] API responds on Railway
- [ ] Stripe billing flow works end-to-end
- [ ] Solo Assistant deploys and agent responds on Telegram
- [ ] Marketing Team deploys, channels auto-created, 7 agents respond on Discord
- [ ] Dashboard shows correct instance status
- [ ] Plan enforcement blocks unauthorized deploys
