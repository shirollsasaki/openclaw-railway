# Draft: ClawDeploy Platform — Full Build

## Requirements (confirmed from existing docs)
- Managed hosting platform for OpenClaw agent teams
- One-click deployment: pick template → enter keys → deploy
- BYOK model (users provide their own Anthropic/OpenAI keys)
- Stripe billing: Solo $9/mo, Team $49/mo, Pro $99/mo
- 2 MVP templates: Solo Assistant (Telegram), Marketing Team (7 agents, Discord)
- Dashboard: list instances, status, restart, delete
- Health monitoring for user instances

## Technical Decisions (from TECHNICAL_SCOPE.md)
- Frontend: Next.js 14 + Tailwind + shadcn/ui on Vercel
- Auth: Clerk (Google + GitHub)
- Backend: Node.js + Hono on Railway
- Database: PostgreSQL on Railway
- Provisioning: Railway API (programmatic Docker service creation)
- Containers: Docker (OpenClaw runtime per user)
- Billing: Stripe subscriptions + webhooks
- Docker image: ghcr.io/clawdeploy/openclaw-runtime:latest

## Existing Assets
- GitHub repo: shirollsasaki/openclaw-team (109 files, all 7 agent configs)
  - This IS the Marketing Team template, ready to package
- 5 detailed planning docs in richard/projects/clawdeploy/
- Creator network of 55 people for soft launch
- Live OpenClaw setup running locally as reference

## User Decisions (from interview)
- [x] Monorepo (Recommended): /apps/web + /apps/api + /packages/shared
- [x] Has Railway account already
- [x] Design: Clean, friendly (Linear-style) — light/dark, purple/blue palette
- [x] Timeline: ASAP 1-2 weeks — market window closing
- [x] Template source: Use openclaw-team repo as-is (battle-tested)

## Open Questions
- [ ] Domain name — clawdeploy.com acquired? Or different name?
- [ ] Vercel + Stripe accounts — need to set up?

## Scope Boundaries
- INCLUDE: Landing page, auth, deploy flow, dashboard, billing, Docker image, 2 templates, health monitoring, setup guides
- EXCLUDE (per MVP_SPRINT.md): Custom template builder, marketplace, auto Discord bot wizard, migration tools, team collab, usage analytics, log viewer, custom domains, backup/restore, white-label

## Research Findings (completed)

### Railway API — VALIDATED ✅
- GraphQL-only API at `https://backboard.railway.com/graphql/v2`
- Full provisioning flow works: projectCreate → serviceCreate (with Docker image) → variableCollectionUpsert → serviceInstanceDeployV2
- Docker image deployment: YES — `source: { image: "ghcr.io/..." }` supported
- Auth: Workspace token (Bearer header) — best for multi-tenant provisioning
- Pro plan: 10,000 req/hour, 100 services/project, 100 projects/workspace
- Pricing: ~$5/container/month (0.5GB RAM + 0.25 vCPU)
- Pattern: 1 Railway project per user tenant (recommended by Railway)
- No official SDK — use graphql-request
- GOTCHA: Private registry credentials are UI-only (use public GHCR image)
- GOTCHA: Project creation rate-limited to ~2/min (queue for scale)
- GOTCHA: sleepApplication must be disabled on Pro plan

### OpenClaw Architecture — KEY FINDINGS
- Single Node.js process runs ALL agents via gateway
- Gateway starts WebSocket server on port 18789 + HTTP for control UI
- Install: `npm i -g openclaw` (requires Node 22+)
- Config: openclaw.json (JSON5) with agents list + channel bindings
- Multi-agent: ONE gateway process, agents routed via bindings rules
- Memory: ~150MB base + ~50MB per agent (7 agents ≈ 500MB)
- Health: Gateway exposes HTTP on its port (can be used for health checks)
- Docker: Official image exists at openclaw/openclaw:latest
- Env substitution supported: `${VAR_NAME}` in config values
- gateway.mode=local must be set, or use --allow-unconfigured

### Competitive Landscape — KEY INSIGHTS
- SimpleClaw.org: $5-10/mo, 1 agent, Telegram-only. $17-20K MRR but creator listed for sale — damaged trust
- SimpleClaw.shop: $34/mo flat, BYOK, SSH access, single plan
- OpenClaw Cloud: $9-79/mo, most sophisticated competitor (Firecracker VMs, credits, RBAC)
- ~15+ competitors total — ALL sell single-agent commodity hosting
- NOBODY sells multi-agent teams with collaboration rules
- Best landing page pattern: Interactive configurator in hero + "Traditional vs Us" time comparison
- Pricing pattern: 3 visible tiers + Enterprise
- Both SimpleClaws use hero-embedded deploy configurator (pick model → channel → go)
