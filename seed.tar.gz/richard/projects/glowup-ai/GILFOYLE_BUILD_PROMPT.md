# GlowUp AI — Build Prompt for Gilfoyle (Web App)

**Project:** GlowUp AI Web App  
**Timeline:** 10 days (March 7 launch)  
**Owner:** Gilfoyle  
**Context:** See `/projects/glowup-ai/PROJECT.md` for full scope

---

## 🎯 WHAT YOU'RE BUILDING

A viral web app that:
1. Accepts selfie uploads
2. Analyzes face features (GPT-4o Vision) → scores 5 metrics
3. Generates a "glowed-up" transformation (Replicate Stable Diffusion)
4. Shows blurred preview, gates full reveal behind $4.99 paywall
5. Offers weekly coaching subscription ($2.99/mo)

**Core tech:** Next.js 14 + Vercel + OpenAI Vision + Replicate + Lemon Squeezy + Vercel Postgres

---

## 🏗️ ARCHITECTURE OVERVIEW

```
User visits glowupai.com
    ↓
Next.js landing page with upload component
    ↓
Server Action: Upload to R2/Blob → analyze with GPT-4o → generate glow-up with Replicate
    ↓
Store in Postgres (scores, images, locked status)
    ↓
Results page: scores + blurred preview
    ↓
"Unlock $4.99" → Lemon Squeezy checkout
    ↓
Webhook → mark unlocked → show full results
```

---

## 📋 BUILD PHASES (10 DAYS)

### PHASE 1: FOUNDATION (Days 1-3)

**Goal:** User can upload photo, see face scores

#### Day 1: Next.js Scaffold

```bash
# Initialize project
npx create-next-app@latest glowup-ai --typescript --tailwind --app
cd glowup-ai
npm install @vercel/postgres @vercel/blob openai replicate

# File structure
/glowup-ai
  ├── app/
  │   ├── page.tsx              # Landing page
  │   ├── upload/
  │   │   └── page.tsx          # Upload flow
  │   ├── results/[id]/
  │   │   └── page.tsx          # Results page
  │   ├── api/
  │   │   ├── analyze/
  │   │   │   └── route.ts      # Face analysis endpoint
  │   │   └── webhook/
  │   │       └── route.ts      # Lemon Squeezy webhook
  │   └── actions.ts            # Server Actions
  ├── components/
  │   ├── UploadZone.tsx
  │   ├── ScoresDisplay.tsx
  │   ├── GlowUpPreview.tsx
  │   └── PaywallButton.tsx
  ├── lib/
  │   ├── vision.ts             # OpenAI Vision
  │   ├── generate.ts           # Replicate
  │   ├── payments.ts           # Lemon Squeezy
  │   └── db.ts                 # Database
  └── .env.local
```

**Tasks:**
- [ ] Create Next.js app
- [ ] Set up Tailwind CSS
- [ ] Install shadcn/ui components
- [ ] Create basic landing page

**Landing Page (`app/page.tsx`):**
```tsx
export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-pink-100 to-purple-100">
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-6xl font-bold text-center mb-4">
          Discover Your <span className="text-pink-600">Glow-Up</span> Potential
        </h1>
        <p className="text-xl text-center text-gray-600 mb-8">
          Upload a selfie. Get AI analysis + see your transformed self.
        </p>
        
        {/* Example before/after images */}
        <div className="grid grid-cols-3 gap-4 mb-12">
          {/* TODO: Add example transformations */}
        </div>
        
        <div className="flex justify-center">
          <Link href="/upload">
            <Button size="lg" className="text-xl px-12 py-6">
              Upload Your Selfie ✨
            </Button>
          </Link>
        </div>
      </div>
    </main>
  );
}
```

---

#### Day 2: Upload Flow + Storage

**Tasks:**
- [ ] Build upload component (drag-drop + camera)
- [ ] Set up Vercel Blob or Cloudflare R2
- [ ] Server Action: upload image → get URL
- [ ] Database schema + setup

**Upload Component (`components/UploadZone.tsx`):**
```tsx
'use client';

import { useState } from 'react';
import { uploadImage } from '@/app/actions';

export function UploadZone() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile));
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    
    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    
    const result = await uploadImage(formData);
    // Redirect to results page
    window.location.href = `/results/${result.id}`;
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="border-4 border-dashed border-gray-300 rounded-lg p-12 text-center">
        {preview ? (
          <div>
            <img src={preview} alt="Preview" className="mx-auto max-w-md rounded-lg mb-4" />
            <Button onClick={handleUpload} disabled={uploading}>
              {uploading ? 'Analyzing...' : 'Analyze My Face ✨'}
            </Button>
          </div>
        ) : (
          <div>
            <input
              type="file"
              accept="image/*"
              capture="user"
              onChange={handleFileChange}
              className="hidden"
              id="file-upload"
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <div className="text-6xl mb-4">📸</div>
              <p className="text-xl mb-2">Click to upload or take a selfie</p>
              <p className="text-gray-500">JPG, PNG, or HEIC • Max 10MB</p>
            </label>
          </div>
        )}
      </div>
    </div>
  );
}
```

**Server Action (`app/actions.ts`):**
```ts
'use server';

import { put } from '@vercel/blob';
import { sql } from '@vercel/postgres';
import { analyzeFace } from '@/lib/vision';
import { generateGlowUp } from '@/lib/generate';

export async function uploadImage(formData: FormData) {
  const file = formData.get('file') as File;
  
  // Upload to Blob storage
  const blob = await put(file.name, file, { access: 'public' });
  
  // Analyze face
  const scores = await analyzeFace(blob.url);
  
  // Generate glow-up
  const glowupUrl = await generateGlowUp(blob.url, scores);
  
  // Store in database
  const result = await sql`
    INSERT INTO analyses (original_image_url, glowup_image_url, scores, unlocked)
    VALUES (${blob.url}, ${glowupUrl}, ${JSON.stringify(scores)}, false)
    RETURNING id
  `;
  
  return { id: result.rows[0].id };
}
```

**Database Schema:**
```sql
CREATE TABLE analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  original_image_url TEXT NOT NULL,
  glowup_image_url TEXT,
  scores JSONB,
  advice TEXT,
  unlocked BOOLEAN DEFAULT FALSE,
  payment_id TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  analysis_id UUID REFERENCES analyses(id),
  email TEXT,
  amount DECIMAL,
  status TEXT DEFAULT 'pending',
  lemon_squeezy_id TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

#### Day 3: GPT-4o Vision Integration

**Tasks:**
- [ ] Get OpenAI API key
- [ ] Write face analysis function
- [ ] Test prompt engineering
- [ ] Return consistent scores

**Vision Module (`lib/vision.ts`):**
```ts
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function analyzeFace(imageUrl: string) {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'text',
            text: `Analyze this face photo and score these features from 1-10:
            - Jawline definition
            - Skin clarity
            - Facial symmetry
            - Eye area (brightness, no dark circles)
            - Smile
            
            Return ONLY valid JSON:
            {
              "jawline": 7.5,
              "skin": 8.2,
              "symmetry": 7.9,
              "eyes": 6.4,
              "smile": 8.1,
              "overall": 7.6
            }`,
          },
          {
            type: 'image_url',
            image_url: { url: imageUrl },
          },
        ],
      },
    ],
  });

  const result = response.choices[0].message.content;
  return JSON.parse(result!);
}
```

---

### PHASE 2: GLOW-UP GENERATION (Days 4-5)

**Goal:** Generate realistic face transformations

#### Day 4: Replicate Integration

**Tasks:**
- [ ] Get Replicate API key
- [ ] Test Stable Diffusion XL for faces
- [ ] Prompt engineering
- [ ] Handle async generation

**Image Generation (`lib/generate.ts`):**
```ts
import Replicate from 'replicate';

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN,
});

export async function generateGlowUp(originalUrl: string, scores: any) {
  const output = await replicate.run(
    'stability-ai/sdxl:39ed52f2a78e934b3ba6e2a89f5b1c712de7dfea535525255b1aa35c5565e08b',
    {
      input: {
        image: originalUrl,
        prompt: `Professional headshot, enhanced face, clear glowing skin, defined jawline, bright eyes, symmetric features, natural studio lighting, high quality photograph, subtle enhancement`,
        negative_prompt: `cartoon, anime, painting, sketch, distorted, deformed, ugly, extra fingers, bad anatomy, unrealistic, overprocessed`,
        num_inference_steps: 40,
        guidance_scale: 7.5,
        strength: 0.35, // Subtle enhancement
      },
    }
  );

  return output[0] as string;
}
```

---

#### Day 5: Results Page

**Tasks:**
- [ ] Build results page
- [ ] Show scores with progress bars
- [ ] Display blurred glow-up preview
- [ ] Paywall button

**Results Page (`app/results/[id]/page.tsx`):**
```tsx
import { sql } from '@vercel/postgres';
import { ScoresDisplay } from '@/components/ScoresDisplay';
import { GlowUpPreview } from '@/components/GlowUpPreview';
import { PaywallButton } from '@/components/PaywallButton';

export default async function ResultsPage({ params }: { params: { id: string } }) {
  const result = await sql`
    SELECT * FROM analyses WHERE id = ${params.id}
  `;
  
  const analysis = result.rows[0];
  const scores = analysis.scores as any;

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold text-center mb-8">
        Your GlowUp Score: {scores.overall}/10
      </h1>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Feature Breakdown</h2>
          <ScoresDisplay scores={scores} />
        </div>
        
        <div>
          <h2 className="text-2xl font-semibold mb-4">Your Transformation</h2>
          <GlowUpPreview
            originalUrl={analysis.original_image_url}
            glowupUrl={analysis.glowup_image_url}
            unlocked={analysis.unlocked}
          />
          
          {!analysis.unlocked && (
            <PaywallButton analysisId={params.id} />
          )}
        </div>
      </div>
    </div>
  );
}
```

**Blurred Preview Component:**
```tsx
export function GlowUpPreview({ originalUrl, glowupUrl, unlocked }: Props) {
  return (
    <div className="relative">
      <img
        src={glowupUrl}
        alt="Glow-up"
        className={unlocked ? '' : 'blur-xl'}
      />
      
      {!unlocked && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-white/90 p-8 rounded-lg text-center">
            <Lock className="w-16 h-16 mx-auto mb-4 text-pink-600" />
            <p className="text-xl font-semibold">Unlock to see your transformation</p>
          </div>
        </div>
      )}
    </div>
  );
}
```

---

### PHASE 3: PAYWALL (Days 6-7)

**Goal:** Monetization working end-to-end

#### Day 6: Lemon Squeezy Setup

**Tasks:**
- [ ] Create Lemon Squeezy account
- [ ] Create product ($4.99 "GlowUp Unlock")
- [ ] Get API keys + webhook secret
- [ ] Build checkout flow

**Payment Module (`lib/payments.ts`):**
```ts
export async function createCheckout(analysisId: string) {
  const checkoutUrl = `https://glowupai.lemonsqueezy.com/checkout/buy/[PRODUCT_ID]?checkout[custom][analysis_id]=${analysisId}`;
  
  return checkoutUrl;
}
```

**Paywall Button:**
```tsx
'use client';

import { createCheckout } from '@/lib/payments';

export function PaywallButton({ analysisId }: { analysisId: string }) {
  const handleUnlock = async () => {
    const checkoutUrl = await createCheckout(analysisId);
    window.location.href = checkoutUrl;
  };

  return (
    <Button
      size="lg"
      onClick={handleUnlock}
      className="w-full mt-4 text-xl py-6"
    >
      Unlock Full Results - $4.99
    </Button>
  );
}
```

---

#### Day 7: Webhook Handler

**Tasks:**
- [ ] Set up webhook endpoint
- [ ] Verify Lemon Squeezy signature
- [ ] Mark analysis as unlocked
- [ ] Redirect user to unlocked results

**Webhook (`app/api/webhook/route.ts`):**
```ts
import { sql } from '@vercel/postgres';
import crypto from 'crypto';

export async function POST(req: Request) {
  const body = await req.text();
  const signature = req.headers.get('x-signature');
  
  // Verify signature
  const hash = crypto
    .createHmac('sha256', process.env.LEMON_SQUEEZY_WEBHOOK_SECRET!)
    .update(body)
    .digest('hex');
    
  if (signature !== hash) {
    return new Response('Invalid signature', { status: 401 });
  }
  
  const event = JSON.parse(body);
  
  if (event.meta.event_name === 'order_created') {
    const analysisId = event.meta.custom_data.analysis_id;
    
    // Mark as unlocked
    await sql`
      UPDATE analyses
      SET unlocked = true
      WHERE id = ${analysisId}
    `;
    
    // Record payment
    await sql`
      INSERT INTO payments (analysis_id, amount, status, lemon_squeezy_id)
      VALUES (${analysisId}, ${event.data.attributes.total}, 'completed', ${event.data.id})
    `;
  }
  
  return new Response('OK', { status: 200 });
}
```

---

### PHASE 4: POLISH (Days 8-9)

**Goal:** Production-ready UX

#### Day 8: UI Polish

**Tasks:**
- [ ] Mobile responsive (test on devices)
- [ ] Loading states (animated)
- [ ] Error handling
- [ ] Share functionality
- [ ] Social meta tags

**Loading Component:**
```tsx
export function AnalyzingLoader() {
  return (
    <div className="text-center py-16">
      <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-pink-600 mx-auto mb-8"></div>
      <h2 className="text-2xl font-semibold mb-2">Analyzing your face...</h2>
      <p className="text-gray-600">This takes about 20 seconds ✨</p>
    </div>
  );
}
```

---

#### Day 9: Moderation + Performance

**Tasks:**
- [ ] OpenAI moderation API (NSFW filter)
- [ ] Image optimization
- [ ] Rate limiting
- [ ] Analytics setup

**Moderation:**
```ts
export async function moderateImage(imageUrl: string) {
  const response = await openai.moderations.create({
    input: imageUrl,
  });

  if (response.results[0].flagged) {
    throw new Error('Image violates content policy');
  }
}
```

---

### PHASE 5: LAUNCH PREP (Day 10)

**Goal:** Ready for public launch

**Tasks:**
- [ ] Alpha test with 20 users
- [ ] Fix critical bugs
- [ ] Set up domain (glowupai.com)
- [ ] Deploy to Vercel production
- [ ] Write ProductHunt post
- [ ] Prepare demo content

**Deployment:**
```bash
# Connect to Vercel
vercel

# Set environment variables
vercel env add OPENAI_API_KEY
vercel env add REPLICATE_API_TOKEN
vercel env add LEMON_SQUEEZY_WEBHOOK_SECRET

# Deploy to production
vercel --prod
```

---

## 🧪 TESTING CHECKLIST

**Before launch, test:**

- [ ] Upload works on mobile Safari
- [ ] Upload works on Chrome desktop
- [ ] Face analysis returns consistent scores
- [ ] Glow-up images look realistic
- [ ] Payment flow completes (test mode)
- [ ] Webhook unlocks content
- [ ] Share button works
- [ ] Page loads < 2 seconds
- [ ] Works on 3G connection
- [ ] NSFW filter blocks inappropriate images

---

## 🚨 BLOCKERS & ESCALATION

**Ping Richard immediately if:**

1. OpenAI Vision scores are inconsistent
2. Replicate outputs look bad (artifacts, distortions)
3. Lemon Squeezy webhook not firing
4. Can't finish in 10 days

**Fallback options:**
- Vision issues → Use Claude Vision or GPT-4o-mini
- Replicate slow → Use Flux Schnell
- Webhook issues → Manual unlock for alpha
- Time crunch → Cut subscription feature

---

## 📊 SUCCESS CRITERIA

**By Day 10:**
- ✅ App live at glowupai.com
- ✅ Upload → analysis → glow-up works
- ✅ Payment flow works
- ✅ 20 alpha users tested it
- ✅ No critical bugs

---

## 🎯 LAUNCH DELIVERABLES

**What Boss sees March 7:**
1. Live URL: glowupai.com
2. Demo video (you using it)
3. 5 user testimonials
4. Analytics dashboard
5. GitHub repo

**Go build. 10 days. Launch Friday.** 🚀
