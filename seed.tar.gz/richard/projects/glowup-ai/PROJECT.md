# GlowUp AI — Web App Project

**Status:** Pre-Build  
**Owner:** Gilfoyle (Engineering)  
**Launch Target:** March 7, 2026 (10 days)  
**Type:** Hybrid (Viral Web App + OpenClaw Backend)

---

## 🎯 CONCEPT

**What it is:**  
A viral web app where you upload a selfie, get AI face analysis + a "glowed-up" transformation, with actionable improvement advice.

**User experience:**
1. Visit glowupai.com
2. Upload selfie (or take photo with camera)
3. Get instant face analysis (scores for jawline, skin, symmetry, etc.)
4. See blurred preview of glowed-up version
5. Pay $4.99 to unlock full glow-up + detailed report
6. Optional: Subscribe for weekly coaching ($2.99/mo)

**Revenue model:**
- Free: Basic face analysis + scores (blurred glow-up preview)
- $4.99 one-time: Unlock glowed-up photo + full report
- $2.99/mo: Weekly check-ins, progress tracking, personalized coaching

---

## 🎪 WHY THIS WINS

**Combines viral + retention:**
- ✅ Viral shareability (before/after screenshots, share links)
- ✅ Real retention (ongoing coaching)
- ✅ Dual revenue (one-time + subscription)
- ✅ User-generated marketing (people share their glow-ups)
- ✅ Zero friction (no Discord/app install required)

**Easier to build than traditional viral app:**
- ✅ Single web app (not mobile app development)
- ✅ OpenClaw handles AI orchestration
- ✅ Template for future viral wrappers

**Strategic fit:**
- ✅ Proves OpenClaw agent value (not just speed)
- ✅ Template for StyleScore, VoiceGlow, PostureCheck
- ✅ Web-first = maximum reach

---

## 🏗️ TECHNICAL ARCHITECTURE

### Tech Stack

```yaml
Frontend/Backend:  Next.js 14 (App Router)
Hosting:           Vercel
Face Analysis:     OpenAI GPT-4o Vision API
Image Generation:  Replicate (Stable Diffusion XL or Flux)
Payments:          Lemon Squeezy
Database:          Vercel Postgres or Supabase
File Storage:      Cloudflare R2 or Vercel Blob
OpenClaw:          Backend agent orchestration (optional)
Styling:           Tailwind CSS + shadcn/ui
Analytics:         Vercel Analytics
```

**Why this stack:**
- **Next.js 14:** Server Actions = no separate API, fast iteration
- **Vercel:** Zero-config deploy, edge network, preview URLs
- **OpenAI Vision:** $0.01/image, fast, accurate
- **Replicate:** $0.02-0.05/image, high-quality transformations
- **Lemon Squeezy:** Merchant of Record (handles global tax), simple webhooks

---

### System Flow

```
User visits glowupai.com
    ↓
Uploads selfie (or takes photo)
    ↓
Next.js Server Action uploads to R2/Blob
    ↓
Calls OpenAI GPT-4o Vision → face analysis
    ↓
Calls Replicate → generates glow-up image
    ↓
Stores in database (original, glow-up, scores, locked=true)
    ↓
Shows user: Scores + blurred glow-up preview
    ↓
"Unlock for $4.99" button (Lemon Squeezy checkout)
    ↓
User pays → Webhook fires → marks result as unlocked
    ↓
User sees full glow-up + detailed report
    ↓
Follow-up modal: "Want weekly coaching? $2.99/mo"
```

---

## 📋 FEATURES & SCOPE

### MVP (Week 1) — MUST HAVE

**Core Flow:**
- ✅ Landing page with upload button
- ✅ Camera capture or file upload
- ✅ Face analysis (5-7 scored features: jawline, skin, symmetry, eyes, smile)
- ✅ Glowed-up image generation
- ✅ Paywall ($4.99 to unlock glow-up + full report)
- ✅ Actionable advice (skincare, grooming, posture tips)
- ✅ Share button (screenshot before/after)

**Tech Requirements:**
- ✅ Next.js app with file upload
- ✅ Server Actions for image processing
- ✅ GPT-4o Vision integration
- ✅ Replicate Stable Diffusion integration
- ✅ Lemon Squeezy one-time payment
- ✅ Database (users, analyses, payments)
- ✅ Mobile responsive

### NICE TO HAVE (Week 2+)

**Retention Features:**
- ⏳ Weekly coaching subscription ($2.99/mo)
- ⏳ Progress tracking (upload new selfies, compare to baseline)
- ⏳ Personalized routines (skincare schedule, workout plan)
- ⏳ Achievement system ("Jawline improved +1.2 points!")
- ⏳ Email reminders

**Virality Features:**
- ⏳ Auto-generated share cards (before/after comparison)
- ⏳ Referral system ("Invite 3 friends, get 1 free analysis")
- ⏳ Leaderboard (top glow-ups this week)
- ⏳ Social meta tags (OG images for Twitter/LinkedIn shares)

**Platform Expansion:**
- ⏳ WhatsApp bot integration
- ⏳ SMS upload (MMS)
- ⏳ Mobile app wrapper

### OUT OF SCOPE (Month 2+)

- ❌ User accounts initially (use session-based, email optional)
- ❌ Social features (comments, likes, follows)
- ❌ Advanced editing (manual touch-ups, filters)
- ❌ Video analysis (photos only)
- ❌ Body analysis (face only for MVP)

---

## 🎨 USER FLOWS

### Flow 1: First-Time User (Free Tier)

1. **Land on homepage:**
   - Hero: "Discover Your Glow-Up Potential"
   - CTA: "Upload a Selfie" (big button)
   - Examples: 3-4 before/after transformations

2. **Upload photo:**
   - Drag-drop or click to upload
   - Or: Take photo with camera (mobile)
   - Preview: Shows uploaded image

3. **Processing:**
   - Loading screen: "Analyzing your face... ✨"
   - Progress bar (fake or real)
   - Takes 15-30 seconds

4. **Results (Free Tier):**
   ```
   Your GlowUp Score: 7.2/10
   
   Feature Breakdown:
   💪 Jawline:    6.8/10  ▓▓▓▓▓▓▓░░░
   ✨ Skin:       7.5/10  ▓▓▓▓▓▓▓▓░░
   ⚖️ Symmetry:   7.9/10  ▓▓▓▓▓▓▓▓░░
   👁️ Eyes:       6.4/10  ▓▓▓▓▓▓░░░░
   😊 Smile:      7.8/10  ▓▓▓▓▓▓▓▓░░
   
   [BLURRED PREVIEW OF GLOW-UP IMAGE]
   
   See your full transformation →
   [Unlock for $4.99] button
   ```

### Flow 2: Paid Unlock (One-Time)

5. **Click "Unlock for $4.99"**
6. **Lemon Squeezy checkout** (overlay or redirect)
7. **Payment confirmed** → redirect back to results page
8. **Show full glow-up:**
   - Side-by-side comparison (before/after)
   - Detailed breakdown:
     ```
     Your GlowUp Transformation
     
     What Changed:
     • Skin clarity improved +2 points
     • Jawline definition enhanced
     • Under-eye circles reduced
     • Slight facial symmetry correction
     
     How to Make It Real:
     
     SKINCARE (Daily):
     - Morning: Vitamin C serum + SPF 50
     - Evening: Retinol + hyaluronic acid
     - Weekly: Exfoliate 2x
     
     GROOMING:
     - Get eyebrows shaped (arch lift)
     - Consider subtle beard trim (angular jawline)
     - Upgrade haircut (ask for textured crop)
     
     LIFESTYLE:
     - Sleep 7-8 hours (reduces eye bags)
     - Hydrate 3L water/day (skin glow)
     - Cut sugar (reduces inflammation)
     
     POSTURE:
     - Chin slightly forward (jawline definition)
     - Shoulders back (confidence boost)
     ```

9. **Share prompt:**
   - "Share your glow-up" button
   - Generates shareable image card
   - Copy link to share

10. **Subscription upsell modal:**
    ```
    Want Weekly Check-Ins?
    
    Track your progress with:
    ✅ Weekly coaching
    ✅ Progress photos
    ✅ Personalized adjustments
    
    $2.99/month
    [Start Weekly Coaching]
    ```

### Flow 3: Subscription (Weekly Coaching)

11. **User subscribes** ($2.99/mo)
12. **Dashboard unlocks:**
    - Upload new photos weekly
    - Progress tracking graph
    - Updated advice based on improvements
13. **Weekly email reminders:**
    ```
    Week 2 Check-In 📊
    
    Upload a new photo to track your progress!
    
    Last week's plan:
    ✅ Started Vitamin C serum
    ⏳ Eyebrow appointment pending
    ❌ Still not hitting 7hr sleep
    
    [Upload New Photo]
    ```

---

## 💰 REVENUE MODEL

### Pricing Tiers

| Tier | Price | What's Included |
|------|-------|-----------------|
| **Free** | $0 | Basic face scores (5 metrics)<br>Blurred glow-up preview<br>Teaser advice |
| **Unlock** | $4.99 one-time | Full glowed-up photo<br>Detailed report<br>Actionable routines<br>Shareable image |
| **Coaching** | $2.99/month | Weekly check-ins<br>Progress tracking<br>Personalized adjustments<br>Priority support |

### Revenue Projections (Month 1)

**Conservative Scenario:**
- 1,000 visitors (ProductHunt launch + organic)
- 50% upload photo = 500 analyses
- 15% unlock ($4.99) = 75 unlocks = **$374**
- 5% subscribe ($2.99/mo) = 25 subs = **$75/mo MRR**
- **Total Month 1:** $374 one-time + $75 MRR

**Mid Scenario:**
- 5,000 visitors (some viral traction on Twitter/TikTok)
- 40% upload = 2,000 analyses
- 20% unlock = 400 unlocks = **$1,996**
- 8% subscribe = 160 subs = **$478/mo MRR**
- **Total Month 1:** $1,996 one-time + $478 MRR

**Optimistic Scenario:**
- 25,000 visitors (goes viral)
- 40% upload = 10,000 analyses
- 25% unlock = 2,500 unlocks = **$12,475**
- 12% subscribe = 1,200 subs = **$3,588/mo MRR**
- **Total Month 1:** $12,475 one-time + $3,588 MRR

**LTV Assumptions:**
- One-time users: $4.99
- Subscribers: $2.99 × 6 months avg = $17.94
- Blended LTV: $8-12

---

## 📅 BUILD PHASES

### Phase 1: Foundation (Days 1-3)

**Goal:** Core upload + analysis working

- [ ] Next.js scaffold + Tailwind setup
- [ ] Landing page with upload component
- [ ] File upload handler (Server Action)
- [ ] Image storage (R2/Blob)
- [ ] GPT-4o Vision integration
- [ ] Database schema (users, analyses)
- [ ] Basic results page (show scores)

**Deliverable:** User can upload photo, see scores

---

### Phase 2: AI Enhancement (Days 4-5)

**Goal:** Glow-up generation works

- [ ] Replicate Stable Diffusion integration
- [ ] Prompt engineering for realistic enhancements
- [ ] Before/after side-by-side display
- [ ] Quality filters (reject bad outputs, retry logic)
- [ ] Test with 20+ diverse faces

**Deliverable:** Glow-up transformations look good

---

### Phase 3: Paywall (Days 6-7)

**Goal:** Monetization live

- [ ] Lemon Squeezy product setup
- [ ] Payment flow (checkout overlay or redirect)
- [ ] Webhook handler (unlock after payment)
- [ ] Blur effect for locked content
- [ ] Database: track payment status
- [ ] Success page (show full results after payment)

**Deliverable:** Users can pay and unlock

---

### Phase 4: Polish (Days 8-9)

**Goal:** Production-ready UX

- [ ] Mobile responsive (test on iPhone, Android)
- [ ] Loading states (animated, not just spinners)
- [ ] Error handling (bad photos, API failures)
- [ ] Share functionality (generate image card)
- [ ] Social meta tags (OG images, Twitter cards)
- [ ] Analytics (track conversions, drop-off)
- [ ] NSFW filter (OpenAI moderation API)

**Deliverable:** App feels polished

---

### Phase 5: Launch Prep (Day 10)

**Goal:** Public launch ready

- [ ] Alpha test with 20 users
- [ ] Bug fixes from alpha
- [ ] Deploy to production (glowupai.com)
- [ ] Set up domain + SSL
- [ ] Prepare demo content (screenshots, videos)
- [ ] Write ProductHunt launch post
- [ ] Launch checklist complete

**Deliverable:** Ready to launch Friday March 7

---

## 🧪 TESTING CHECKLIST

### Face Analysis Quality
- [ ] Scores consistent across similar photos
- [ ] Works on diverse skin tones, ages, genders
- [ ] Handles poor lighting, angles, accessories
- [ ] Rejects inappropriate content (NSFW, minors)

### Glow-Up Image Quality
- [ ] Enhancements look realistic
- [ ] Preserves identity (still recognizable)
- [ ] No artifacts (weird eyes, extra fingers)
- [ ] Consistent quality across face types

### Payment Flow
- [ ] Checkout loads correctly
- [ ] Webhook fires reliably
- [ ] Content unlocks immediately
- [ ] Works on mobile

### Performance
- [ ] Page loads < 2 seconds
- [ ] Analysis completes < 30 seconds
- [ ] Works on 3G connection
- [ ] No memory leaks

---

## ⚠️ RISKS & MITIGATIONS

### Risk 1: Image Quality Inconsistent
**Impact:** Users don't pay if glow-up looks bad  
**Mitigation:**
- Test 100+ photos before launch
- Add quality scoring (auto-reject bad outputs)
- Offer free retry if user unhappy
- Manual review first 50 paid unlocks

### Risk 2: Offensive Content
**Impact:** Brand damage, legal issues  
**Mitigation:**
- OpenAI moderation API (filter NSFW)
- Age detection (reject minors)
- Clear ToS (users must be 18+, own photo rights)
- Report button

### Risk 3: Low Conversion Rate
**Impact:** Revenue below projections  
**Mitigation:**
- A/B test pricing ($3.99 vs $4.99 vs $5.99)
- Improve preview (show partial unblurred sections)
- Add urgency ("24-hour launch price")
- Social proof ("2,847 glow-ups generated today")

### Risk 4: API Costs Too High
**Impact:** Unprofitable at scale  
**Mitigation:**
- Monitor costs daily
- Break-even: Need 15%+ unlock rate
- Switch to cheaper models if needed (GPT-4o-mini, Flux Schnell)

### Risk 5: Viral Traffic Spike
**Impact:** Server crashes, API rate limits  
**Mitigation:**
- Vercel auto-scales
- Queue system for API calls
- Rate limiting per IP
- Upgrade OpenAI tier proactively

---

## 📊 SUCCESS METRICS

### Week 1 (Launch → Day 7)
- 🎯 **1,000 visitors**
- 🎯 **500 uploads** (50% conversion)
- 🎯 **75 paid unlocks** (15%)
- 🎯 **$500 revenue**
- 🎯 **20+ social shares**

### Month 1 (Day 30)
- 🎯 **5,000 visitors**
- 🎯 **2,000 uploads**
- 🎯 **400 unlocks** (20%)
- 🎯 **$2,500 revenue**
- 🎯 **100+ social mentions**

### Kill Criteria (Day 30)
- ❌ < 1,000 total visitors
- ❌ < 10% unlock rate
- ❌ < $500 total revenue
- ❌ Zero viral traction

**If kill criteria hit:** Pivot to pure Research Agent wrapper

---

## 🚀 LAUNCH PLAN

### Pre-Launch (Days 1-9)
- Build in private
- Alpha test with 20 hand-picked users
- Collect testimonials + before/after examples
- Prep launch content (demo videos, screenshots)

### Launch Day (Friday March 7)

**ProductHunt:**
- Launch at 12:01 AM PT
- Coordinate alpha users for upvotes
- Respond to every comment

**Twitter:**
- Founder thread: "I built an AI that shows your glow-up potential. Upload a selfie, get scored + transformation. Here's mine →"
- Post before/after comparison
- Demo video (30s)

**Reddit:**
- r/InternetIsBeautiful
- r/SideProject
- r/Entrepreneur
- r/SkincareAddiction (if allowed)

**TikTok/Instagram:**
- Post demo video (Monica handles)
- Use trending audio
- Hook: "POV: You finally see what you'd look like glowed up"

### Post-Launch (Days 11-30)
- Daily: Monitor analytics, fix bugs
- Every 3 days: Twitter thread with user results
- Weekly: Metrics update
- Iterate based on feedback

---

## 🔧 TECHNICAL DETAILS

### Database Schema

```sql
CREATE TABLE analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id TEXT NOT NULL,
  original_image_url TEXT NOT NULL,
  glowup_image_url TEXT,
  scores JSONB,
  advice TEXT,
  unlocked BOOLEAN DEFAULT FALSE,
  payment_id TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  analysis_id UUID REFERENCES analyses(id),
  email TEXT,
  amount DECIMAL,
  status TEXT DEFAULT 'pending',
  lemon_squeezy_id TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  lemon_squeezy_id TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### API Cost Estimate

**Per Analysis:**
- GPT-4o Vision (face analysis): $0.01
- Replicate SD XL (glow-up): $0.03
- Total: ~$0.04

**At 2,000 analyses/month:**
- API costs: $80/month
- Need 17 paid unlocks to break even
- Target: 400 unlocks (20%) = $1,996 revenue
- Gross margin: 96% ($1,916 profit)

---

## 🎯 NEXT STEPS

**Immediate (Today):**
1. Create GitHub repo: `glowup-ai`
2. Set up Vercel project
3. Get API keys: OpenAI, Replicate, Lemon Squeezy
4. Register domain: glowupai.com

**Tomorrow:**
- Start Phase 1 (Days 1-3): Core upload + analysis
- @monica: Write alpha recruitment post
- @jared: Recruit 20 alpha users

**End of Week:**
- Phase 2-3 complete (glow-up generation + paywall)
- Alpha test running

**Launch Friday March 7:**
- Public launch (ProductHunt, Twitter, Reddit)
- Track metrics daily
- Iterate based on feedback

---

**Project approved. Ready to build.** 🚀
