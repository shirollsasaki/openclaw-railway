# Standard Operating Workflows

## Workflow 1: Opportunity Pipeline
```
SCOUT → SCORE → PRESENT → APPROVE → RESEARCH → SYNTHESIZE → EXECUTE
  R        R        R        Boss       D→R        R          Team
```

## Workflow 2: Content/Marketing Push
```
STRATEGY → BRIEF → COPY → REVIEW → PUBLISH
   J         J       M      J        J
```

## Workflow 3: Technical Build
```
FEASIBILITY → SCOPE → BUILD → SHIP
     G          G       G      G+J(launch)
```

## Workflow 4: BD/Partnership
```
IDENTIFY → EVALUATE → PROPOSAL → NEGOTIATE → CLOSE
    R         E          E          E         E+Boss
```

## Workflow 5: Morning Routine (Richard)
1. Scan PH, HN, crypto Twitter, ClawHub
2. Identify 2-3 signals
3. Quick-score each
4. Post morning brief to group
5. Flag anything above 30 for boss attention

## Workflow 6: 4-Hour Team Check
1. Query all agent sessions for activity
2. Surface blockers
3. Flag resource usage
4. List completed deliverables
5. Recommend next priority
6. Post dashboard to group
