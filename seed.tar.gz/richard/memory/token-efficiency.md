# Token Efficiency Structure

## Model Tiers (Decided 2025-02-17)

### Tier 1 — Strategic (Opus)
- **Richard** — Strategy, scoring, orchestration decisions
- **Gilfoyle** — Architecture, complex code, feasibility analysis

### Tier 2 — Execution (Sonnet)
- **Dinesh** — Research, competitor analysis, market intel
- **Erlich** — BD outreach, deal evaluation, scraping
- **Jared** — GTM strategy, content planning, marketing
- **Monica** — Copywriting, content creation
- **Big Head** — Data pulls, scraping, summarization

## Rules
1. Never run scraping/data tasks on Opus
2. Research (web search + synthesis) runs fine on Sonnet
3. Only use Opus when task requires deep reasoning or complex multi-step logic
4. Erlich's API scraping was burning 74k tokens on Opus — moved to Sonnet (5x cheaper)
