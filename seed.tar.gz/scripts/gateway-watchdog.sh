#!/bin/bash
# OpenClaw Gateway Watchdog
# Detects Discord WebSocket reconnect storms (code 1005) and auto-restarts.
# Run via launchd every 2 minutes.

LOG="$HOME/.openclaw/logs/gateway.log"
WATCHDOG_LOG="$HOME/.openclaw/logs/watchdog.log"
THRESHOLD=5          # 5+ code 1005 disconnects in recent window = storm
WINDOW_SECONDS=30    # Look at last 30 seconds of logs

timestamp() { date "+%Y-%m-%d %H:%M:%S"; }

# Count code 1005 disconnects in the last WINDOW_SECONDS seconds
if [ ! -f "$LOG" ]; then
  exit 0
fi

cutoff=$(date -v-${WINDOW_SECONDS}S "+%Y-%m-%dT%H:%M:%S" 2>/dev/null || date -d "-${WINDOW_SECONDS} seconds" "+%Y-%m-%dT%H:%M:%S" 2>/dev/null)

# Get recent 1005 disconnects from last 100 lines (fast, avoids reading entire log)
storm_count=$(tail -100 "$LOG" | grep "closed with code 1005" | while read line; do
  # Extract timestamp from log line (format: 2026-02-24T16:32:42.308Z)
  ts=$(echo "$line" | grep -o "^[0-9T:.Z-]*" | cut -c1-19)
  if [ -n "$ts" ] && [ "$ts" \> "$cutoff" ]; then
    echo "hit"
  fi
done | wc -l)

storm_count=$(echo "$storm_count" | tr -d ' ')

if [ "$storm_count" -ge "$THRESHOLD" ]; then
  echo "$(timestamp) STORM DETECTED: $storm_count code-1005 disconnects in ${WINDOW_SECONDS}s. Killing gateway." >> "$WATCHDOG_LOG"
  
  # Kill the gateway process — launchd will auto-restart it fresh
  pkill -9 -f "openclaw.*gateway" 2>/dev/null
  
  # Also clear any stale resume state
  rm -f "$HOME/.openclaw/gateway.*.lock" 2>/dev/null
  
  echo "$(timestamp) Gateway killed. launchd will restart fresh." >> "$WATCHDOG_LOG"
else
  # Uncomment for debug:
  # echo "$(timestamp) OK (storm_count=$storm_count)" >> "$WATCHDOG_LOG"
  :
fi
