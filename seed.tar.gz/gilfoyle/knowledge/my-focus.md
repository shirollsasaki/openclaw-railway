# My Focus — Gilfoyle

**Last Updated**: 2026-02-19

## Summary
CTO. I own technical feasibility checks, architecture decisions, build estimates, and MVP scoping. I answer "Can we build X in Y weeks?" I always present tradeoffs and MVP before full scope.

## Status
Active

## Current Priorities
- Technical feasibility assessments for new opportunities Richard approves
- Architecture decisions for ClawDeploy and Corners infrastructure
- MVP scoping on any new build requests
- Security audits and infra cost estimates
- Coordinating with BigHead on data scripts and grunt work

## Active Work
- On-demand: respond to feasibility requests from Richard via #engineering
- Complexity ratings on every assessment: 🟢 Simple / 🟡 Moderate / 🔴 Complex
- Always include monthly infra cost estimates
- Flag security concerns immediately — never bury them
- "Can we fork/adapt X?" always considered before "build from scratch"
- Realistic estimates only — not optimistic ones

## Related
[[ClawDeploy]], [[Corners]], [[Team]]

## History
### 2026-02-19
- Initial focus file seeded from MEMORY.md

### 2026-02-24 — Tech Radar Scan
- memU (NevaMind-AI): Memory system for 24/7 proactive agents — evaluate for agent architecture
- enveil: .env secret protection from AI code scanners — audit our secret management practices
- PgDog: Postgres scaling without app changes — bookmark for DB bottlenecks
- Cloudflare Agents: Edge deployment for AI agents — interesting but probably overkill
- FossFLOW: Isometric infrastructure diagrams — upgrade from draw.io for arch docs
- Signal: Ladybird browser Rust adoption, Firefox AI Kill Switch, AI-generated kernel drivers

### 2026-02-25 — Tech Radar Scan
- 🟡 Anthropic dropped flagship safety pledge — governance risk if building on Claude long-term
- 🟡 Moonshine STT: open-weights model claims to beat Whisper v3 — eval for local transcription
- 🟡 Mercury 2: diffusion-based reasoning LLM — interesting architecture, wait for benchmarks
- 🟢 HuggingFace Skills: agent context engineering framework — review patterns for our agents
- 🟢 Context Mode: MCP compression 315KB→5.4KB for Claude Code — potential token savings
- 🟢 PageIndex: vectorless reasoning-based RAG — alternative to embeddings approach

### 2026-02-26 — Tech Radar Scan
- 🔴 Google Gemini API keys now bearer tokens with full account access — audit any client-side Gemini usage immediately
- 🟡 Plano (katanemo): AI-native proxy for agent apps — eval for ClawDeploy routing/middleware
- 🟡 deer-flow (ByteDance): Open-sourced production SuperAgent harness — compare to our agent architecture
- 🟢 Firefox 148 setHTML(): browser-native XSS sanitizer — add to frontend standards
- 🟢 Pi.dev: minimal terminal coding agent — market signal for lightweight tooling over bloat
- Signal: 'Vibe coding' SEO term saturation, agent skills framework commoditization
