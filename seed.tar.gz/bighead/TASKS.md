# Tasks — Big Head (Data/Intern)

## Active

## Pending
- [ ] Data pulls as requested by team

## Done
