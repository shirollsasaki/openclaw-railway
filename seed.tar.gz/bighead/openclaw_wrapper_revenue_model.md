# OpenClaw Wrapper Revenue Model
## Product Strategy: Agent-First, Direct-to-Subscription

**Model Date:** 2026-02-25  
**Pricing:**
- Single Agent: $9/month
- Full Team (8 agents): $99/month

---

## 1. USER ACQUISITION PER WRAPPER LAUNCH

### Assumptions by Scenario

| Metric | Conservative | Mid | Optimistic |
|--------|-------------|-----|------------|
| **Launch Month Signups** | 150 | 400 | 800 |
| **Month 2+ Growth Rate** | 5% MoM | 15% MoM | 25% MoM |
| **Channel Mix** | Organic search, HN | + Twitter, niche communities | + Product Hunt, partnerships |
| **Free Tier Retention** | 40% after 30 days | 55% | 70% |

**Rationale:**
- **Conservative:** Niche developer tool, minimal marketing, word-of-mouth only
- **Mid:** Active community engagement, regular Twitter presence, decent SEO
- **Optimistic:** Strong launch execution, influencer endorsements, viral Product Hunt

---

## 2. CONVERSION RATES (Free → Paid)

### SaaS Benchmark Analysis

| Type | Industry Benchmark | Applied to Wrappers |
|------|-------------------|---------------------|
| **Freemium SaaS (General)** | 2-5% | 3% (conservative) |
| **Developer Tools** | 4-8% | 5% (mid) |
| **AI/Automation Tools (2025-26)** | 6-12% | 8% (optimistic) |

**Additional Factors:**
- **Team upsell rate:** 20% of paid users upgrade from $9 → $99 (mid scenario)
- **Conversion timeline:** 60-day average (most convert within 30-90 days)
- **Churn:** 5% monthly (competitive for AI tools)

**Source Logic:** 
- DevTools (GitHub Copilot, Cursor) see 5-8% conversion
- AI productivity tools (Jasper, Copy.ai) hit 8-12% with strong value prop
- Direct-to-paid model (no freemium friction) boosts conversion vs traditional SaaS

---

## 3. MONTHLY RUN RATE — 4 WRAPPERS IN MONTH 1

### Scenario: MID (Most Realistic)

**Month 1: Launch 4 Wrappers**

| Wrapper | Month 1 Signups | Month 2 Active Users | Month 2 Paid (5%) | Month 3 Paid (5%) |
|---------|----------------|---------------------|-------------------|-------------------|
| Research Agent | 400 | 460 (15% growth) | 23 | 26 |
| Content Factory | 400 | 460 | 23 | 26 |
| Data Analyst | 400 | 460 | 23 | 26 |
| Social Monitor | 400 | 460 | 23 | 26 |
| **TOTAL** | **1,600** | **1,840** | **92** | **104** |

**Month 3 Revenue Breakdown:**
- 104 paid users × 80% on $9 plan = 83 × $9 = **$747**
- 104 paid users × 20% on $99 plan = 21 × $99 = **$2,079**
- **Total MRR Month 3: $2,826**

**Month 6 Projection (15% MoM growth):**
- Total active users: ~3,700
- Paid conversions (5%): 185 users
- Revenue: 148 × $9 + 37 × $99 = **$4,995 MRR**

---

## 4. PATH TO $1M/YEAR ($83,333 MRR)

### Three Paths Analyzed

#### **Path A: Wrapper Volume Strategy**
- **Target:** 15-20 wrappers by month 12
- **Avg users per wrapper:** 500 active (month 12)
- **Total user base:** 10,000 active free users
- **Conversion at 5%:** 500 paid users
- **Revenue:** 400 × $9 + 100 × $99 = **$13,500 MRR**
- **Gap to $1M/year:** Still need 6x scale → **NOT VIABLE in Year 1**

#### **Path B: Higher Conversion Focus**
- **Target:** 8 wrappers, but optimize conversion to 8%
- **User base (month 12):** 6,000 active free users
- **Paid (8%):** 480 users
- **Revenue:** 360 × $9 + 120 × $99 = **$15,120 MRR**
- **Gap:** Still 5.5x short → **NOT VIABLE**

#### **Path C: Enterprise Team Pivot**
- **Shift:** Focus on $99 team plan adoption
- **Target:** 200 wrappers launches over 12 months (aggressive)
- **OR:** Partner with 500 small agencies/studios
- **Team plan adoption:** 850 teams × $99 = **$84,150 MRR**
- **Path:** ✅ **VIABLE** — requires B2B sales motion + integrations

---

## 5. YEAR 1 FINANCIAL PROJECTION

### Mid Scenario (15% MoM growth, 5% conversion, 20% team upsell)

| Month | New Wrappers | Cumulative Free Users | Paid Users | MRR | ARR |
|-------|-------------|----------------------|-----------|-----|-----|
| 1 | 4 | 1,600 | 0 | $0 | $0 |
| 2 | 2 | 2,760 | 55 | $792 | $9,504 |
| 3 | 2 | 4,374 | 110 | $2,826 | $33,912 |
| 4 | 1 | 5,430 | 170 | $4,386 | $52,632 |
| 5 | 1 | 6,745 | 235 | $6,063 | $72,756 |
| 6 | 2 | 9,257 | 320 | $8,256 | $99,072 |
| 7 | 1 | 10,945 | 415 | $10,701 | $128,412 |
| 8 | 1 | 12,987 | 520 | $13,416 | $160,992 |
| 9 | 2 | 16,926 | 680 | $17,550 | $210,600 |
| 10 | 1 | 19,864 | 850 | $21,945 | $263,340 |
| 11 | 1 | 23,344 | 1,040 | $26,832 | $321,984 |
| 12 | 2 | 28,845 | 1,285 | $33,165 | **$397,980** |

**Year 1 End State:**
- Total wrappers launched: 20
- Active free users: 28,845
- Paid subscribers: 1,285
- MRR: $33,165
- **ARR: $397,980**

**Gap to $1M:** 2.5x short. Would need:
- 3x conversion rate (15% instead of 5%) — unrealistic
- OR 3x user acquisition per wrapper
- OR pivot to enterprise/team sales

---

## 6. COMPARISON: WRAPPER STRATEGY vs. VIRAL APPS MODEL

| Dimension | Viral Apps Model | OpenClaw Wrapper Model | Winner |
|-----------|-----------------|----------------------|--------|
| **Launch Speed** | 1-2 weeks per app | 3-5 days per wrapper | ✅ Wrappers |
| **User Acquisition** | 5K-50K per launch (viral) | 150-800 per launch (niche) | ❌ Viral Apps |
| **Conversion Rate** | 0.5-2% (impulse downloads) | 5-8% (committed users) | ✅ Wrappers |
| **Retention** | 10-20% week 1 | 55-70% month 1 | ✅ Wrappers |
| **LTV** | $9-15 (one-time or 1-2 months) | $54-180 (6-12 months avg) | ✅ Wrappers |
| **CAC** | $2-5 (organic viral) | $15-30 (content marketing) | ❌ Viral Apps |
| **Time to $10K MRR** | 6-9 months (if viral hits) | 7-8 months (steady growth) | ≈ Tie |
| **Time to $100K MRR** | 12-18 months (multiple hits) | 18-24 months (scale challenge) | ❌ Viral Apps |
| **Scalability** | Hit-driven, unpredictable | Linear, repeatable | ✅ Wrappers |
| **Competitive Moat** | Weak (easy to copy) | Strong (OpenClaw ecosystem) | ✅ Wrappers |
| **Downside Risk** | High (flop = $0) | Low (each wrapper adds value) | ✅ Wrappers |
| **Upside Potential** | Very high (one hit = $500K) | Capped without enterprise | ❌ Viral Apps |

### Key Insights

**Viral Apps Win If:**
- You can consistently create viral hooks
- App store optimization is mastered
- You're okay with hit-driven economics
- Short-term cash injection needed

**Wrapper Strategy Wins If:**
- Building OpenClaw ecosystem is strategic priority
- Sustainable, predictable revenue preferred
- Developer/prosumer audience is your niche
- Long-term moat matters

**Hybrid Approach:**
- Use viral apps as **user acquisition funnels** for wrappers
- "Try our viral app → Unlock more with OpenClaw wrapper subscription"
- Example: Viral social media tool → Research Agent upsell

---

## EXECUTIVE SUMMARY

### The Numbers (Mid Scenario, Year 1)
- **4 wrappers in Month 1 → $2,826 MRR by Month 3**
- **20 wrappers by Month 12 → $33,165 MRR ($398K ARR)**
- **Path to $1M/year:** Requires 2.5x scale OR enterprise pivot

### Recommendation
**Do NOT rely on wrappers alone for $1M Year 1.** Instead:

1. **Launch 12-15 wrappers** (proven value, community building)
2. **Add ClawDeploy Enterprise tier** ($299-999/month for teams)
3. **Hybrid model:** Use viral apps as acquisition funnel → wrapper conversions
4. **Target:** $600K ARR from wrappers + $400K from enterprise = **$1M**

### Critical Success Factors
- **Conversion rate:** Must hit 6-8% (not 3%)
- **Team plan adoption:** 25-30% of paid users (not 20%)
- **Growth rate:** Maintain 15%+ MoM (requires consistent launches + marketing)
- **Enterprise motion:** B2B sales for $99+ plans unlocks upside

---

**Model Confidence:** 75% (based on SaaS benchmarks, AI tool adoption trends)  
**Biggest Risk:** User acquisition per wrapper may be lower than 400 without strong distribution  
**Biggest Opportunity:** Enterprise teams could 3-5x revenue with same user base

