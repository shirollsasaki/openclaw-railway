"""
Check recent transactions on the wallet
"""
import asyncio
from web3 import AsyncWeb3
from datetime import datetime

async def check():
    w3 = AsyncWeb3(AsyncWeb3.AsyncHTTPProvider("https://mainnet.base.org"))
    wallet = "0xB57dDA84e58a31F8527354D19edD73D0c4B164B0"
    
    print("Checking recent transactions...")
    print()
    
    # Get current balance
    usdc_address = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
    usdc_abi = [{"constant":True,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"type":"function"}]
    usdc = w3.eth.contract(address=usdc_address, abi=usdc_abi)
    usdc_balance = await usdc.functions.balanceOf(wallet).call()
    usdc_amount = usdc_balance / 1e6
    
    print(f"Current USDC balance: ${usdc_amount:.2f}")
    print()
    
    # Get ETH balance
    eth_balance = await w3.eth.get_balance(wallet)
    eth_amount = eth_balance / 1e18
    print(f"Current ETH balance: {eth_amount:.6f} ETH")
    print()
    
    # Get latest block
    latest_block = await w3.eth.block_number
    print(f"Latest block: {latest_block}")
    print()
    
    print("Recent activity (last 50 blocks):")
    print()
    
    # Check last 50 blocks for transactions
    from_block = latest_block - 50
    
    # Get USDC transfer events
    transfer_topic = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
    
    try:
        logs = await w3.eth.get_logs({
            'fromBlock': from_block,
            'toBlock': 'latest',
            'address': usdc_address,
            'topics': [
                transfer_topic,
                None,  # from
                w3.to_hex(int(wallet, 16).to_bytes(32, 'big'))  # to our wallet
            ]
        })
        
        print(f"Incoming USDC transfers (last 50 blocks): {len(logs)}")
        for log in logs:
            amount = int(log['data'], 16) / 1e6
            tx_hash = log['transactionHash'].hex()
            print(f"  + ${amount:.2f} USDC (tx: {tx_hash})")
        print()
        
        # Outgoing transfers
        logs_out = await w3.eth.get_logs({
            'fromBlock': from_block,
            'toBlock': 'latest',
            'address': usdc_address,
            'topics': [
                transfer_topic,
                w3.to_hex(int(wallet, 16).to_bytes(32, 'big')),  # from our wallet
                None  # to
            ]
        })
        
        print(f"Outgoing USDC transfers (last 50 blocks): {len(logs_out)}")
        for log in logs_out:
            amount = int(log['data'], 16) / 1e6
            to_addr = "0x" + log['topics'][2].hex()[-40:]
            tx_hash = log['transactionHash'].hex()
            print(f"  - ${amount:.2f} USDC → {to_addr} (tx: {tx_hash})")
        
    except Exception as e:
        print(f"Error checking logs: {e}")
    
    print()
    print("="*70)
    print()
    print("CHECK FULL HISTORY:")
    print(f"https://basescan.org/address/{wallet}")

asyncio.run(check())
