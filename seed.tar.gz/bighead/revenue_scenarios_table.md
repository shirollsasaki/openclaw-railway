# Quick Reference: 3-Scenario Revenue Model

## PER-APP PERFORMANCE (When 1 App Goes Viral)

| Metric | Conservative | Mid-Case | Optimistic |
|--------|--------------|----------|------------|
| **Viral Users** | 25,000 | 100,000 | 350,000 |
| **Paid Unlock Rate** | 1.2% | 1.8% | 2.5% |
| **Paid Unlocks** | 300 | 1,800 | 8,750 |
| **One-Time Revenue** | $1,200 | $7,200 | $35,000 |
| **ClawDeploy Converts** | 9 (3%) | 90 (5%) | 700 (8%) |
| **ClawDeploy MRR** | $270 | $2,700 | $21,000 |

---

## MONTHLY RUN RATE (1 in 4 Apps Hits Viral)

| Month | Conservative | Mid-Case | Optimistic |
|-------|--------------|----------|------------|
| **Month 1** | $1,470 | $9,900 | $56,000 |
| **Month 2** | $1,740 | $17,100 | $112,000 |
| **Month 3** | $2,010 | $24,300 | $168,000 |

*Note: Cumulative ClawDeploy MRR builds as more apps hit*

---

## ANNUAL PROJECTIONS (12 Months, 3 Viral Hits)

| Metric | Conservative | Mid-Case | Optimistic |
|--------|--------------|----------|------------|
| **One-Time Revenue** | $3,600 | $21,600 | $105,000 |
| **Avg ClawDeploy MRR** | $405 | $4,050 | $31,500 |
| **Annual ClawDeploy** | $5,000 | $50,000 | $390,000 |
| **TOTAL YEAR 1** | **$8,600** | **$71,600** | **$495,000** |

---

## PATH TO $1M/YEAR

### Option 1: Pure Mid-Case Strategy
- **Need:** 14 mid-case viral hits
- **Apps to build:** 56 (at 1-in-4 success)
- **Timeline:** 14 months (1 app/week)
- **Key driver:** ClawDeploy MRR compounds to $80K+/mo

### Option 2: Mixed Bag (Most Realistic)
- **Need:** 2 optimistic + 1 mid-case hit
- **Apps to build:** 12-20 
- **Timeline:** 6-12 months
- **Key driver:** Land a couple breakout viral apps (350K+ users)

### Option 3: ClawDeploy as Primary Engine
- **Need:** 10 mid-case hits → $81K ClawDeploy MRR
- **Apps to build:** 40 (at 1-in-4 success)
- **Timeline:** 10 months
- **Key driver:** Recurring revenue at scale

---

## KEY ASSUMPTIONS RECAP

### Viral Reach
- **Conservative:** 25K users (small ProductHunt/Reddit hit)
- **Mid:** 100K users (multi-platform viral, sustained growth)
- **Optimistic:** 350K users (mega-viral, press coverage)

### Conversion Benchmarks (Industry Data)
- **Paid unlock:** 1.2-2.5% (similar to face rating apps, personality tests)
- **ClawDeploy:** 3-8% of paid users (depends on messaging & timing)
- **Pricing:** $4 average one-time, $30 ClawDeploy ARPU

### Success Rate
- **1 in 4 apps goes viral** (aggressive but achievable with strong distribution)
- **3 in 4 apps flop** (<2K users, minimal revenue)

---

## DECISION FRAMEWORK

**Go All-In If:**
- First 4 apps yield 1 mid-case hit or better
- Paid unlock conversion ≥ 1.5%
- ClawDeploy conversion ≥ 4%

**Pivot/Adjust If:**
- Hit rate drops to 1-in-8 (halve weekly output, focus on quality)
- Paid conversion < 1% (rework paywall strategy)
- ClawDeploy conversion < 2% (messaging/product-market fit issue)

**Kill Strategy If:**
- No viral hits in first 12 apps (3 months)
- Paid unlock revenue < $500/hit consistently
- ClawDeploy conversions non-existent (<1%)
