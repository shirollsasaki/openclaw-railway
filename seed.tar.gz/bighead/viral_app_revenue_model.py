"""
Viral App Revenue Model
Strategy: 1 viral app/week → $3-5 paywall → funnel to ClawDeploy
Goal: Model scenarios and find path to $1M/year
"""
import pandas as pd
from datetime import datetime

# =============================================================================
# ASSUMPTIONS & BENCHMARKS
# =============================================================================

# Viral App Reach (users who try the app)
VIRAL_REACH = {
    'conservative': 5_000,      # Small viral hit (e.g., niche subreddit, small Twitter thread)
    'mid': 25_000,              # Medium viral (ProductHunt #1, decent Twitter viral)
    'optimistic': 100_000       # Big viral (multiple platforms, influencer pickup)
}

# Conversion Rate: Viral Reach → Paid Unlock
# Benchmark: Similar low-ticket tools (face raters, AI tools, etc.)
# Industry data: 1-5% for impulse purchases, 0.5-2% for conservative
CONVERSION_RATES = {
    'conservative': 0.01,       # 1% (typical for cold traffic)
    'mid': 0.02,                # 2% (good value prop, frictionless payment)
    'optimistic': 0.04          # 4% (excellent product-market fit)
}

# App Success Rate
APP_SUCCESS_RATE = 0.25         # 1 in 4 apps goes viral (Boss assumption)

# Apps per Month
APPS_PER_MONTH = 4              # 1 per week

# Pricing
PAYWALL_PRICE = 4               # $3-5, using $4 mid-point
CLAWDEPLOY_SINGLE = 9           # $9/mo single agent
CLAWDEPLOY_TEAM = 99            # $99/mo full team

# ClawDeploy Funnel Conversion
# From paid app users → ClawDeploy subscription
# Assumption: Users who paid $4 are qualified, but subscription is higher commitment
CLAWDEPLOY_FUNNEL = {
    'to_single_agent': 0.05,    # 5% of paid users try single agent
    'to_full_team': 0.01,       # 1% of paid users go for full team
    'churn_rate_monthly': 0.15  # 15% monthly churn (typical SaaS)
}

# =============================================================================
# SCENARIO MODELING
# =============================================================================

def calculate_monthly_revenue(scenario='mid', months=12):
    """
    Calculate monthly revenue for a given scenario
    
    Args:
        scenario: 'conservative', 'mid', or 'optimistic'
        months: Number of months to project
    
    Returns:
        DataFrame with monthly breakdown
    """
    
    viral_reach = VIRAL_REACH[scenario]
    conversion_rate = CONVERSION_RATES[scenario]
    
    # Per successful app metrics
    paid_unlocks = viral_reach * conversion_rate
    direct_revenue = paid_unlocks * PAYWALL_PRICE
    
    # ClawDeploy conversions from this app
    single_agent_subs = paid_unlocks * CLAWDEPLOY_FUNNEL['to_single_agent']
    team_subs = paid_unlocks * CLAWDEPLOY_FUNNEL['to_full_team']
    
    results = []
    cumulative_single = 0
    cumulative_team = 0
    
    for month in range(1, months + 1):
        # Apps launched this month
        successful_apps = APPS_PER_MONTH * APP_SUCCESS_RATE
        
        # Direct revenue from apps this month
        app_revenue = successful_apps * direct_revenue
        
        # New subscriptions from this month's apps
        new_single = successful_apps * single_agent_subs
        new_team = successful_apps * team_subs
        
        # Add to cumulative (accounting for churn)
        cumulative_single = cumulative_single * (1 - CLAWDEPLOY_FUNNEL['churn_rate_monthly']) + new_single
        cumulative_team = cumulative_team * (1 - CLAWDEPLOY_FUNNEL['churn_rate_monthly']) + new_team
        
        # Monthly recurring revenue from subscriptions
        mrr_single = cumulative_single * CLAWDEPLOY_SINGLE
        mrr_team = cumulative_team * CLAWDEPLOY_TEAM
        mrr_total = mrr_single + mrr_team
        
        # Total monthly revenue
        total_revenue = app_revenue + mrr_total
        
        results.append({
            'Month': month,
            'Successful Apps': successful_apps,
            'Paid Unlocks': successful_apps * paid_unlocks,
            'App Revenue': app_revenue,
            'New Single Agent Subs': new_single,
            'New Team Subs': new_team,
            'Cumulative Single Subs': cumulative_single,
            'Cumulative Team Subs': cumulative_team,
            'MRR Single': mrr_single,
            'MRR Team': mrr_team,
            'Total MRR': mrr_total,
            'Total Monthly Revenue': total_revenue
        })
    
    return pd.DataFrame(results)

def print_scenario_summary(scenario_name, df):
    """Print summary for a scenario"""
    
    print(f"\n{'='*80}")
    print(f"SCENARIO: {scenario_name.upper()}")
    print(f"{'='*80}\n")
    
    # First month
    month_1 = df.iloc[0]
    print(f"Month 1:")
    print(f"  Successful apps: {month_1['Successful Apps']:.1f}")
    print(f"  Paid unlocks: {month_1['Paid Unlocks']:.0f}")
    print(f"  Direct revenue: ${month_1['App Revenue']:,.2f}")
    print(f"  Total revenue: ${month_1['Total Monthly Revenue']:,.2f}")
    print()
    
    # Month 6
    month_6 = df.iloc[5]
    print(f"Month 6:")
    print(f"  App revenue: ${month_6['App Revenue']:,.2f}")
    print(f"  MRR: ${month_6['Total MRR']:,.2f}")
    print(f"  Total revenue: ${month_6['Total Monthly Revenue']:,.2f}")
    print(f"  Active single subs: {month_6['Cumulative Single Subs']:.0f}")
    print(f"  Active team subs: {month_6['Cumulative Team Subs']:.0f}")
    print()
    
    # Month 12
    month_12 = df.iloc[11]
    print(f"Month 12:")
    print(f"  App revenue: ${month_12['App Revenue']:,.2f}")
    print(f"  MRR: ${month_12['Total MRR']:,.2f}")
    print(f"  Total revenue: ${month_12['Total Monthly Revenue']:,.2f}")
    print(f"  Active single subs: {month_12['Cumulative Single Subs']:.0f}")
    print(f"  Active team subs: {month_12['Cumulative Team Subs']:.0f}")
    print()
    
    # Year 1 totals
    total_annual = df['Total Monthly Revenue'].sum()
    avg_monthly = df['Total Monthly Revenue'].mean()
    
    print(f"Year 1 Totals:")
    print(f"  Total revenue: ${total_annual:,.2f}")
    print(f"  Average monthly: ${avg_monthly:,.2f}")
    print(f"  App revenue: ${df['App Revenue'].sum():,.2f}")
    print(f"  Subscription revenue: ${df['Total MRR'].sum():,.2f}")
    print()
    
    # Path to $1M
    if total_annual >= 1_000_000:
        print(f"✅ HITS $1M TARGET (${total_annual:,.2f})")
    else:
        gap = 1_000_000 - total_annual
        gap_pct = (gap / 1_000_000) * 100
        print(f"⚠️  GAP TO $1M: ${gap:,.2f} ({gap_pct:.1f}%)")
        
        # How many more viral apps needed?
        monthly_needed = gap / 12
        apps_needed = monthly_needed / (df.iloc[-1]['Total Monthly Revenue'] / APPS_PER_MONTH / APP_SUCCESS_RATE)
        print(f"   Would need ~{apps_needed:.1f}x more successful apps per month")

def breakeven_analysis():
    """Calculate how many successful apps needed to hit $1M/year"""
    
    print(f"\n{'='*80}")
    print("BREAKEVEN ANALYSIS: Apps Needed for $1M/Year Target")
    print(f"{'='*80}\n")
    
    target = 1_000_000
    
    for scenario in ['conservative', 'mid', 'optimistic']:
        print(f"\n{scenario.upper()} Scenario:")
        print("-" * 40)
        
        # Try different success rates
        for apps_per_month in [1, 2, 4, 8, 12]:
            # Calculate revenue with this many successful apps/month
            viral_reach = VIRAL_REACH[scenario]
            conversion_rate = CONVERSION_RATES[scenario]
            
            paid_unlocks = viral_reach * conversion_rate * apps_per_month
            
            # Month 12 steady state (approximation)
            # App revenue: direct
            monthly_app_revenue = paid_unlocks * PAYWALL_PRICE
            
            # Subscription revenue (steady state with churn)
            # Simplified: assume equilibrium reached
            monthly_new_subs = paid_unlocks * CLAWDEPLOY_FUNNEL['to_single_agent']
            monthly_new_team = paid_unlocks * CLAWDEPLOY_FUNNEL['to_full_team']
            
            # Steady state subs = new_per_month / churn_rate
            steady_single = monthly_new_subs / CLAWDEPLOY_FUNNEL['churn_rate_monthly']
            steady_team = monthly_new_team / CLAWDEPLOY_FUNNEL['churn_rate_monthly']
            
            mrr = steady_single * CLAWDEPLOY_SINGLE + steady_team * CLAWDEPLOY_TEAM
            
            monthly_revenue = monthly_app_revenue + mrr
            annual_revenue = monthly_revenue * 12
            
            status = "✅" if annual_revenue >= target else "❌"
            
            print(f"  {apps_per_month} successful apps/month:")
            print(f"    Monthly revenue: ${monthly_revenue:,.2f}")
            print(f"    Annual revenue: ${annual_revenue:,.2f} {status}")
            
            if annual_revenue >= target:
                # Calculate actual apps needed per month (with 25% success rate)
                apps_launched = apps_per_month / APP_SUCCESS_RATE
                print(f"    → Launch {apps_launched:.1f} apps/month (1 in 4 hits)")
                break
        print()

# =============================================================================
# RUN ANALYSIS
# =============================================================================

if __name__ == "__main__":
    print("\n" + "="*80)
    print("VIRAL APP REVENUE MODEL - ClawDeploy Strategy")
    print("="*80)
    print(f"\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    print("\n" + "="*80)
    print("KEY ASSUMPTIONS")
    print("="*80)
    print(f"\nViral Reach per Successful App:")
    print(f"  Conservative: {VIRAL_REACH['conservative']:,} users")
    print(f"  Mid: {VIRAL_REACH['mid']:,} users")
    print(f"  Optimistic: {VIRAL_REACH['optimistic']:,} users")
    
    print(f"\nConversion Rate (viral reach → paid unlock):")
    print(f"  Conservative: {CONVERSION_RATES['conservative']*100:.1f}%")
    print(f"  Mid: {CONVERSION_RATES['mid']*100:.1f}%")
    print(f"  Optimistic: {CONVERSION_RATES['optimistic']*100:.1f}%")
    
    print(f"\nApp Success Rate: {APP_SUCCESS_RATE*100:.0f}% (1 in 4 apps)")
    print(f"Apps Launched per Month: {APPS_PER_MONTH}")
    print(f"Successful Apps per Month: {APPS_PER_MONTH * APP_SUCCESS_RATE}")
    
    print(f"\nPricing:")
    print(f"  App unlock: ${PAYWALL_PRICE}")
    print(f"  ClawDeploy single: ${CLAWDEPLOY_SINGLE}/mo")
    print(f"  ClawDeploy team: ${CLAWDEPLOY_TEAM}/mo")
    
    print(f"\nClawDeploy Funnel:")
    print(f"  Paid users → single agent: {CLAWDEPLOY_FUNNEL['to_single_agent']*100:.1f}%")
    print(f"  Paid users → team: {CLAWDEPLOY_FUNNEL['to_full_team']*100:.1f}%")
    print(f"  Monthly churn: {CLAWDEPLOY_FUNNEL['churn_rate_monthly']*100:.0f}%")
    
    # Run scenarios
    scenarios = ['conservative', 'mid', 'optimistic']
    results = {}
    
    for scenario in scenarios:
        df = calculate_monthly_revenue(scenario, months=12)
        results[scenario] = df
        print_scenario_summary(scenario, df)
    
    # Breakeven analysis
    breakeven_analysis()
    
    # Save to CSV
    for scenario, df in results.items():
        filename = f"revenue_model_{scenario}.csv"
        df.to_csv(filename, index=False)
        print(f"\n✅ Saved: {filename}")
    
    print("\n" + "="*80)
    print("ANALYSIS COMPLETE")
    print("="*80)
