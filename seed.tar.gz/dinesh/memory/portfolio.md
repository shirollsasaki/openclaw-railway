# Product Portfolio

## 1. Corners.market
- **URL:** https://corners.market
- **What:** Curator-driven marketplace where "corners" (topics/niches) are tradeable coins. Users discover, curate, trade, and get rewarded.
- **Model:** Every corner is a coin you can buy/sell. Holders get rewarded from trading volume. Holdings = governance (upvote, comment, shape content).
- **Ecosystem:** Base chain (crypto-native)
- **Revenue:** Trading fees / token economics
- **Status:** Live, active corners visible on site

## 2. Early.build (early.dev)
- **URL:** https://early.build
- **What:** Platform connecting devs with early access to dev tools + paid project opportunities. Two-sided: devs get early tool access + paid work, companies get dev talent.
- **Model:** B2B (companies pay to access dev talent) + community (devs build portfolios)
- **Revenue:** Company subscriptions / placement fees / sponsored access
- **Status:** Live

## Cross-Leverage Opportunities
- Corners could have an /earlydev or $DEVTOOLS corner
- Early.build devs could be recruited to build for Corners ecosystem
- Creator network (55 people) can drive both platforms
- Shared audience: crypto-native builders and curators
