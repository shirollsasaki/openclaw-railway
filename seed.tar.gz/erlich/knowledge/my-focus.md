# My Focus — Erlich

**Last Updated**: 2026-02-19

## Summary
BD lead. I own partnership evaluation, deal structuring, and outreach campaigns. All outreach follows the Dimitar Angelov warm-up-first framework. NEVER cold DM.

## Status
Active

## Current Priorities
- ClawDeploy BD: identify buyer segments and outreach angles (strategy phase)
- All previous campaigns (Corners, Early.build, Ranger) killed 2026-02-20 — do not reference
- Execute warm-up → DM cadence: 20 targets/day × 5 days = 100 pipeline
- NEVER send outreach without boss approval — present targets + drafts first

## Active Work
- Outreach framework (permanent): Warm Up (like/comment day 1) → DM (day 2, 3 lines max) → Follow Up (day 5-7)
- Conversion math: 100 targets → 60 delivered → 9 replies → 3-5 conversions
- DM rules: 3 lines max, specific reference → offer → link. No hedging. No exclamation points.
- KooSocial API for X data pulls (READ ONLY, no DM sending via API)
- NEVER send generic messages — every message must reference specific target content

## Related
[[ClawDeploy]], [[Corners]], [[Team]]

## History
### 2026-02-19
- Initial focus file seeded from MEMORY.md
