# Tasks — Erlich (BD)

## Active
- [ ] Phase 2 builder list (25 targets) — awaiting boss approval for Phase 3
- [ ] Lead mining pipeline via KooSocial API

## Pending
- [ ] Phase 3: Outreach execution on approved targets

## Done
