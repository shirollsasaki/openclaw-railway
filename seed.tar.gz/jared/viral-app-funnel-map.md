# Viral App → ClawDeploy Conversion Funnel
**Created:** 2026-02-25 | **Owner:** Jared Dunn (CMO)

---

## 1. FULL FUNNEL MAP

```
STAGE 1: DISCOVERY
↓
[Social Virality] → 100,000 impressions/week (TikTok, Twitter, Product Hunt)
    ↓ 5% click-through
    
STAGE 2: ACTIVATION
↓
[5,000 App Visitors] → Land on viral app
    ↓ 40% activate (use core feature)
    
STAGE 3: PAYWALL
↓
[2,000 Active Users] → Hit $3-5 paywall for premium features
    ↓ 3-5% convert (industry standard for impulse-priced apps)
    
STAGE 4: VIRAL APP CUSTOMER
↓
[60-100 Paid Users] → Just paid for the app
    ↓ 100% see ClawDeploy pitch (strategic placement)
    
STAGE 5: CLAWDEPLOY AWARENESS
↓
[60-100 Pitch Views] → "This was built by AI agents in 3 days"
    ↓ 15-25% click through (high intent post-purchase)
    
STAGE 6: CLAWDEPLOY LANDING
↓
[9-25 Landing Page Visits] → clawdeploy.com/built-this
    ↓ 20-30% convert (proof-of-concept is powerful)
    
STAGE 7: CLAWDEPLOY SUBSCRIBER
↓
[2-7 New Subscribers] per viral app launch
    ↓
    Monthly Revenue: $18-63/app (assuming $9/mo plan)
    Annual Value: $198-693/app (assuming $99/yr conversions)
```

**NET RESULT PER APP:**
- **2-7 ClawDeploy subscribers** per viral app
- **Weekly output (4 apps/month):** 8-28 new subscribers/month
- **Monthly recurring revenue:** $72-252/month from viral app funnel alone

---

## 2. PITCH PLACEMENT STRATEGY

### **PRIMARY: Post-Paywall Success Screen (90% weight)**

**Location:** Immediately after successful payment
**Format:** Full-screen interstitial (skippable after 3 sec)

**Visual:**
```
┌─────────────────────────────────────┐
│  ✓ Payment Successful               │
│                                     │
│  🤖 CURIOUS HOW THIS WAS BUILT?    │
│                                     │
│  This app was created by AI agents │
│  in 3 days using ClawDeploy.       │
│                                     │
│  Deploy the same team for $9/mo    │
│                                     │
│  [See How It Works] [Skip]         │
└─────────────────────────────────────┘
```

**Why Post-Paywall:**
- Users just demonstrated willingness to pay
- They're invested in the product (sunk cost effect)
- Peak curiosity moment ("How did they ship this so fast?")
- Non-intrusive to free users (focused funnel)

### **SECONDARY: In-App Footer (10% weight)**

**Location:** Persistent footer on main screens
**Format:** Small badge/link

```
🤖 Built with ClawDeploy in 3 days → [Learn How]
```

**Why Footer:**
- Catches free users who might build (not just buy)
- Low friction, passive exposure
- Developer-curious audience

### **DO NOT USE:**
- ❌ Pre-paywall (distracts from viral app conversion)
- ❌ Aggressive popups (kills app experience)
- ❌ Email sequences (weak for this audience)

---

## 3. CONVERSION HOOK

### **Primary Message (Post-Paywall Screen):**
> "This app was built by AI agents in 3 days. Deploy the same team for $9/mo."

### **Landing Page Headline:**
> "The App You Just Bought? Built by AI Agents in 72 Hours."

### **Subheadline:**
> "ClawDeploy gives you the same AI team that ships viral apps weekly. No code. No hiring. Just deploy."

### **Social Proof Elements:**
1. **Live Build Counter:** "47 apps built this month"
2. **Speed Showcase:** "Average build time: 3.2 days"
3. **Behind-the-Scenes:** Screen recording of agent swarm building THIS specific app
4. **Cost Comparison:** 
   - Traditional dev: $15k + 6 weeks
   - ClawDeploy: $9/mo + 3 days

### **CTA Variants:**
- **High Intent:** "Start Building Now" → Direct to signup
- **Curious:** "See How It Works" → Demo video → Signup
- **Price-Sensitive:** "Start Free Trial" → 7-day trial of $9 plan

---

## 4. CONVERSION ASSUMPTIONS & MATH

### **WEEKLY FUNNEL (1 Viral App Launch)**

| Stage | Volume | Conversion | Reasoning |
|-------|--------|-----------|-----------|
| Social Impressions | 100,000 | - | Assumes moderate virality (1 TikTok hit or PH featured) |
| App Visitors | 5,000 | 5% CTR | Standard social → landing conversion |
| Active Users | 2,000 | 40% activation | Used core feature at least once |
| Paid Users | 60-100 | 3-5% | Impulse pricing ($3-5) in proven app |
| ClawDeploy Pitch Views | 60-100 | 100% | Post-paywall placement |
| Landing Page Visits | 9-25 | 15-25% CTR | High curiosity post-purchase |
| **ClawDeploy Subscribers** | **2-7** | **20-30%** | Proof-of-concept close rate |

### **MONTHLY PROJECTIONS (4 Apps/Month)**

**Conservative Case:**
- 4 apps × 2 subscribers = **8 new ClawDeploy subscribers/month**
- 8 × $9 = **$72 MRR** (if all choose monthly)
- Annual value: 8 × $99 = **$792** (if all choose annual)
- **Blended LTV (70% monthly, 30% annual):** ~$1,440/month in annual value

**Optimistic Case:**
- 4 apps × 7 subscribers = **28 new subscribers/month**
- 28 × $9 = **$252 MRR** (all monthly)
- Annual value: 28 × $99 = **$2,772** (all annual)
- **Blended LTV:** ~$5,040/month in annual value

### **KEY ASSUMPTIONS:**

1. **Viral App Quality:** Apps must be genuinely good (not spam) to maintain credibility
2. **Pricing Sweet Spot:** $3-5 viral app price proves payment willingness without filtering too hard
3. **Post-Paywall Timing:** Users in "just bought" mindset are peak conversion state
4. **Proof > Pitch:** Showing the app they just paid for as proof beats abstract marketing
5. **Speed Differentiation:** "3 days" is the killer metric (vs weeks/months of traditional dev)

### **SENSITIVITY ANALYSIS:**

- **If viral app paywall drops to 2%:** Still 2-4 ClawDeploy subs/app (acceptable)
- **If ClawDeploy conversion drops to 15%:** Still 1-4 subs/app (minimum viable)
- **If app launch cadence increases to 2/week:** 16-56 subs/month (game changer)

---

## 5. STRATEGIC POSITIONING

### **IS THIS THE STRATEGY OR A PARALLEL PLAY?**

**ANSWER: This is a PARALLEL GROWTH ENGINE, NOT the primary GTM.**

### **Rationale:**

#### **PRIMARY GTM (70% focus):**
- **Direct B2B Sales:** Selling ClawDeploy to agencies, indie hackers, startups
- **Why Primary:** Higher ACV ($99/yr upfront), faster path to $1M ARR
- **Target:** 850 annual subs at $99 = $84k, or ~10k monthly subs at $9 = $90k MRR
- **Channel:** Creator network (55 creators), direct outreach, community

#### **PARALLEL ENGINE: Viral App Funnel (30% focus)**
- **Why Parallel:** 
  - Builds brand credibility ("we eat our own dog food")
  - Generates proof-of-concept case studies
  - Creates content pipeline (Monica can cover each launch)
  - Reaches different audience (app consumers vs builders)
  - Revenue is bonus, not the goal

### **STRATEGIC VALUE BEYOND SUBS:**

1. **Social Proof Factory:** Each viral app is a live demo
2. **Content Engine:** Weekly launch content for Monica
3. **SEO/Brand:** "Built with ClawDeploy" backlinks from viral apps
4. **Credibility:** "We ship 1 app/week" is a positioning statement
5. **Learning Loop:** Agent improvements from real builds → better ClawDeploy product

### **RESOURCE ALLOCATION:**

| Activity | Time Investment | Revenue Impact | Strategic Impact |
|----------|----------------|----------------|------------------|
| Viral App Launches | 20% (automated agents) | Low-Medium (10-30 subs/mo) | **High** (proof-of-concept) |
| Direct B2B Sales | 50% (Erlich + Richard) | **High** (faster to $1M) | Medium |
| Creator Network | 20% (partnerships) | Medium (reach multiplier) | **High** (distribution) |
| Content/Community | 10% (Monica + social) | Low (awareness) | **High** (brand) |

---

## 6. IMPLEMENTATION ROADMAP

### **WEEK 1: SETUP**
- [ ] Build `clawdeploy.com/built-this` landing page template
- [ ] Create post-paywall interstitial component (reusable across apps)
- [ ] Draft 3 hook variants for A/B testing
- [ ] Set up tracking (pitch views → landing visits → conversions)

### **WEEK 2-4: LAUNCH & ITERATE**
- [ ] Ship 1 viral app/week with ClawDeploy pitch embedded
- [ ] Track conversion rates at each funnel stage
- [ ] A/B test: "3 days" vs "72 hours" vs "AI agents built this"
- [ ] Collect qualitative feedback from converters

### **MONTH 2: OPTIMIZE**
- [ ] Identify highest-converting app type (utility vs entertainment vs productivity)
- [ ] Double down on winning hook variant
- [ ] Test annual vs monthly plan prominence
- [ ] Consider "app buyer discount" (e.g., $79/yr if purchased within 24 hrs)

---

## 7. SUCCESS METRICS

### **WEEK 1 BENCHMARKS:**
- ≥50 paid viral app users
- ≥10 ClawDeploy landing page visits
- ≥2 ClawDeploy conversions

### **MONTH 1 BENCHMARKS:**
- ≥8 ClawDeploy subscribers from viral funnel
- ≥$72 MRR from this channel
- ≥20% ClawDeploy landing → signup conversion

### **MONTH 3 BENCHMARKS:**
- ≥25 ClawDeploy subscribers (cumulative)
- ≥$225 MRR from viral funnel
- Viral app funnel contributing 10-15% of total ClawDeploy growth

---

## 8. RISKS & MITIGATIONS

| Risk | Impact | Mitigation |
|------|--------|------------|
| Viral apps flop (no users) | No funnel volume | Ship 2/week instead of 1; diversify app types |
| ClawDeploy pitch feels spammy | Brand damage | Post-paywall only; make skippable; focus on "how it's made" curiosity |
| Cannibalization (users buy app instead of ClawDeploy) | Lost revenue | Apps are proof, not competitors; emphasize "build YOUR idea" |
| Low viral app paywall conversion | Weak top-of-funnel | Price test ($2 vs $5); improve app quality; A/B test paywall timing |

---

## FINAL RECOMMENDATION

**Ship this as a PARALLEL engine starting Week 1.**

### **Why Now:**
1. Agents are already building apps → low marginal cost to add pitch
2. Every app launch is marketing content for Monica
3. Proof-of-concept is more credible than landing page copy
4. Compounds over time (more apps = more funnels running in parallel)

### **Why Parallel (Not Primary):**
1. Volume math doesn't get us to $1M ARR fast enough (need direct sales)
2. Value is brand/credibility/proof as much as revenue
3. Different audience (consumers vs builders) = different funnel

### **Key Metric to Watch:**
**ClawDeploy landing page → signup conversion rate.**
- If >25%: This is a goldmine, increase app cadence to 2/week
- If 15-25%: Solid, keep at 1/week
- If <15%: Rethink hook or placement

---

**Next Steps for Boss:**
1. Approve post-paywall placement strategy
2. Confirm landing page URL structure
3. Green-light first viral app with embedded pitch (this week)
4. Set tracking pixel on landing page

**Timeline:** Ready to launch with first viral app by end of week.
